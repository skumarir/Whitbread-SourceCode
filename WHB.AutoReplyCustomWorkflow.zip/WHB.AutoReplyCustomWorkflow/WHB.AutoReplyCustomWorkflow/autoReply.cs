﻿//-----------------------------------------------------------------------
// <copyright file="autoReply.cs" company="Company">
// Copyright (c) Company. All rights reserved.
// </copyright>
// <author>Ranjith&Muthu</author>
//-----------------------------------------------------------------------

using System;
using System.Activities;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Query;

namespace WHB.AutoReplyCustomWorkflow
{
    public sealed class autoReply : CodeActivity
    {
        /// <summary>
        /// Input Argument for getting the informations
        /// </summary>
        [RequiredArgument]
        [Input("Source")]
        [ReferenceTarget("incident")]

        public InArgument<string> sourceCode
        {
            get;
            set;
        }

        [RequiredArgument]
        [Input("HotelCode")]
        [ReferenceTarget("incident")]
        public InArgument<string> hotel
        {
            get;
            set;
        }

        [RequiredArgument]
        [Input("EmailAddress")]
        [ReferenceTarget("incident")]
        public InArgument<string> emailaddress
        {
            get;
            set;
        }

        /// <summary>
        /// Method to send Email with Template to the Customer (Auto Reply)
        /// </summary>
        /// <param name="executionContext">Execution Context</param>
        protected override void Execute(CodeActivityContext executionContext)
        {
            try
            {
                IExecutionContext context = executionContext.GetExtension<IExecutionContext>();
                IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                ITracingService tracer = executionContext.GetExtension<ITracingService>();
                Entity entity = (Entity)context.InputParameters["Target"];
                string source = sourceCode.Get(executionContext);
                string hotelCode = hotel.Get(executionContext);
                string emailAddress = emailaddress.Get(executionContext);
                tracer.Trace("source-" + source);
                tracer.Trace("hotel-" + hotelCode);
                if (emailaddress != null)
                {
                    string brandId = string.Empty;
                    string sourceId = string.Empty;

                    if (hotelCode != string.Empty && hotelCode !=null)
                    {
                        brandId = GetPropertyBrandId(hotelCode, tracer, service);
                        tracer.Trace("brand Id : " + brandId);
                    }

                    if (source == null || source == "" || source == string.Empty)
                        source = "https://premierinn.com";

                    sourceId = GetSourceId(source, tracer, service);
                    tracer.Trace("Source Id : " + sourceId);

                    //if (source != string.Empty && source !=null)
                    //{
                        
                    //}
                    

                    QueryExpression queryExpression = new QueryExpression { EntityName = "whb_caseassignment", ColumnSet = new ColumnSet(new string[] { "whb_templatename", "whb_frommailbox" }) };

                    if (brandId != string.Empty && brandId != "")
                        queryExpression.Criteria.AddCondition("whb_brandid", ConditionOperator.Equal, brandId);
                    else
                        queryExpression.Criteria.AddCondition("whb_brandid", ConditionOperator.Null);

                    if (sourceId != string.Empty)
                        queryExpression.Criteria.AddCondition("whb_sourceid", ConditionOperator.Equal, sourceId);
                    else
                        queryExpression.Criteria.AddCondition("whb_sourceid", ConditionOperator.Null);

                    tracer.Trace("End of query expression");
                    string autoReplyTemplate = string.Empty;
                    try
                    {
                        //Retrieving the case assignment entity record
                        EntityCollection result = service.RetrieveMultiple(queryExpression);
                        tracer.Trace("Count of records-" + result.Entities.Count);
                        if(result.Entities.Count>0)
                                               
                        //foreach (var item in result.Entities)
                        {
                            EntityReference fromMailbox = result.Entities[0].Attributes.Contains("whb_frommailbox") ? result.Entities[0].GetAttributeValue<EntityReference>("whb_frommailbox") : null;
                            tracer.Trace("mailboxId-" + fromMailbox.Id);
                            if (result.Entities[0].Attributes.Contains("whb_templatename"))
                            {
                                tracer.Trace("whb_templatename contains data");
                                autoReplyTemplate = (result.Entities[0].Attributes["whb_templatename"]).ToString();
                                tracer.Trace("templateid-" + autoReplyTemplate);
                            }                           
                            
                            Guid templateid = Guid.Empty;
                            if (autoReplyTemplate != string.Empty)
                            {
                                templateid = new Guid(autoReplyTemplate);
                                if (templateid == null || templateid == Guid.Empty)
                                {
                                    return;
                                }
                                Entity party1 = new Entity("activityparty");
                                party1["addressused"] = emailAddress;
                                Entity party2 = new Entity("activityparty");
                                party2["partyid"] = new EntityReference(fromMailbox.LogicalName,fromMailbox.Id);
                                EntityCollection to = new EntityCollection();
                                to.Entities.Add(party1);
                                //Creating the email message
                                Entity email = new Entity("email");
                                email["to"] = to;
                                email["from"] = new Entity[] { party2 };
                                email["directioncode"] = true;
                                email["whb_isautoreply"] = true;
                                tracer.Trace("caseid-" + entity.Id.ToString());
                                //To send email using the Email Template
                                var emailUsingTemplateReq = new SendEmailFromTemplateRequest
                                {
                                    TemplateId = templateid,
                                    Target = email,
                                    RegardingId = entity.Id,
                                    RegardingType = entity.LogicalName

                                };
                                SendEmailFromTemplateResponse emailUsingTemplateResp = (SendEmailFromTemplateResponse)service.Execute(emailUsingTemplateReq);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        throw new InvalidPluginExecutionException("Error Occured in Auto Reply" + ex.Message);
                    }                    

                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("Error Occured in Auto Reply" + ex.Message);
            }
        }        

        /// <summary>
        /// To get the Source Id
        /// </summary>
        /// <param name="source"></param>
        /// <param name="tracer"></param>
        /// <param name="service"></param>
        /// <returns></returns>
        public string GetSourceId(string source, ITracingService tracer, IOrganizationService service)
        {
            try
            {
                tracer.Trace("Start -- GetSourceId Method.");
                QueryExpression queryExpression = new QueryExpression { EntityName = "whb_source", ColumnSet = new ColumnSet(new string[] { "whb_name" }) };
                queryExpression.Criteria.AddCondition("whb_name", ConditionOperator.Equal, source);
                EntityCollection property = service.RetrieveMultiple(queryExpression);

                foreach (Entity item in property.Entities)
                {
                    tracer.Trace("Source Id : " + item.Id.ToString());
                    return item.Id.ToString();
                }
            }
            catch (Exception ex)
            {
                tracer.Trace("Exception in GetSourceId Method : " + ex.Message);
                throw;
            }

            return "";
        }
        /// <summary>
        /// To get the Brand ID 
        /// </summary>
        /// <param name="hotelCode"></param>
        /// <param name="tracer"></param>
        /// <param name="service"></param>
        /// <returns></returns>
        public string GetPropertyBrandId(string hotelCode, ITracingService tracer, IOrganizationService service)
        {
            try
            {
                tracer.Trace("Start GetPropertyBrandId Method");
                QueryExpression queryExpression = new QueryExpression { EntityName = "whb_property", ColumnSet = new ColumnSet(new string[] { "whb_brandid" }) };
                queryExpression.Criteria.AddCondition("whb_propertycode", ConditionOperator.Equal, hotelCode);
                EntityCollection property = service.RetrieveMultiple(queryExpression);

                foreach (Entity item in property.Entities)
                {
                    tracer.Trace("Property Brand Id : " + ((EntityReference)(item.Attributes["whb_brandid"])).Id.ToString());
                    return ((EntityReference)(item.Attributes["whb_brandid"])).Id.ToString();
                }
            }
            catch (Exception ex)
            {
                tracer.Trace("Exception in GetPropertyBrandId Method : " + ex.Message);
                throw;
            }
            return "";
        }
    }
}
