﻿//-----------------------------------------------------------------------
// <copyright file="ActivityPreventDelete.cs" company="Sprocket Enterprises">
// Copyright (c) Sprocket Enterprises. All rights reserved.
// </copyright>
// <author>Muthu</author>
//-----------------------------------------------------------------------
namespace RestrictingAttachmentDeletion
{
    using System;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Query;

    /// <summary>
    /// Plugin for Preventing Deletion of Attachments in GRE
    /// </summary>
    public class ActivityPreventDelete : IPlugin
    {
        /// <summary>
        /// function for Preventing GRE from Deleting Email Attachment
        /// </summary>
        /// <param name="serviceProvider">Service Provider</param>
        public void Execute(IServiceProvider serviceProvider)
        {        
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                IOrganizationServiceFactory servicefactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = servicefactory.CreateOrganizationService(context.UserId);
                if (context.MessageName.ToLower() == "delete")
                {
                   bool flag = this.CheckUserRole(service, context.InitiatingUserId, tracingService);
                    if (flag == true)
                    {
                        throw new InvalidPluginExecutionException("User Doesnt Have Delete Access");
                    }
                }                
        }

        /// <summary>
        /// Function for Retreiving the Security roles of the Current Looged In User
        /// </summary>
        /// <param name="service">Service</param>
        /// <param name="userId">UserID</param>
        /// <param name="trace">Trace</param>
        /// <returns>Flag</returns>        
        private bool CheckUserRole(IOrganizationService service, Guid userID, ITracingService trace)
        {
            ////Query Expression for getting the Security Role of Logged in User
            bool flag = false;
            QueryExpression queryExpression = new QueryExpression();
            queryExpression.EntityName = "role"; ////role entity name
            ColumnSet cols = new ColumnSet();
            cols.AddColumn("name"); ////We only need role name
            queryExpression.ColumnSet = cols;
            ConditionExpression ce = new ConditionExpression();
            ce.AttributeName = "systemuserid";
            ce.Operator = ConditionOperator.Equal;
            ce.Values.Add(userID);
            ////system roles
            LinkEntity lnkEntityRole = new LinkEntity();
            lnkEntityRole.LinkFromAttributeName = "roleid";
            lnkEntityRole.LinkFromEntityName = "role"; ////FROM
            lnkEntityRole.LinkToEntityName = "systemuserroles";
            lnkEntityRole.LinkToAttributeName = "roleid";
            ////system users
            LinkEntity lnkEntitySystemusers = new LinkEntity();
            lnkEntitySystemusers.LinkFromEntityName = "systemuserroles";
            lnkEntitySystemusers.LinkFromAttributeName = "systemuserid";
            lnkEntitySystemusers.LinkToEntityName = "systemuser";
            lnkEntitySystemusers.LinkToAttributeName = "systemuserid";
            lnkEntitySystemusers.LinkCriteria = new FilterExpression();
            lnkEntitySystemusers.LinkCriteria.Conditions.Add(ce);
            lnkEntityRole.LinkEntities.Add(lnkEntitySystemusers);
            queryExpression.LinkEntities.Add(lnkEntityRole);
            EntityCollection entColRoles = service.RetrieveMultiple(queryExpression);
            trace.Trace(entColRoles.Entities.Count.ToString());
            if (entColRoles != null && entColRoles.Entities.Count > 0)
            {               
                foreach (Entity _entity in entColRoles.Entities)
                {
                    trace.Trace(_entity.Attributes["name"].ToString().ToLower());
                   
                    if (_entity.Attributes["name"].ToString().ToLower() == "guest relation advisor")
                    {
                        flag = true;
                    }
                }
            }

            return flag;
        }              
    }
}
