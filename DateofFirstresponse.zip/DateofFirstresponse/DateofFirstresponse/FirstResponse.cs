﻿// -------------------
////<copyright file="FirstResponse.cs" company="CTS">
////Copyright (c) Sprocket Enterprises. All rights reserved.
////</copyright>
//---------------
namespace DateofFirstresponse
{
    using Microsoft.Xrm.Sdk;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Microsoft.Xrm.Sdk.Query;
    public class FirstResponse : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory organizationServiceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService organizationService = organizationServiceFactory.CreateOrganizationService(context.UserId);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            ///stamping dateof response while sending an email
            if (context.MessageName.ToLower() == "send")
            {

                if (context.InputParameters.Contains("EmailId") && context.InputParameters["EmailId"] is Guid)
                {
                    Guid email = (Guid)context.InputParameters["EmailId"];

                    ColumnSet emailcols = new ColumnSet(new String[] { "regardingobjectid", "directioncode", "whb_isautoreply", "subject" });
                    var emailentity = organizationService.Retrieve("email", email, emailcols);
                    if (emailentity.Attributes.Contains("regardingobjectid"))
                    {
                        EntityReference regardingid = emailentity.GetAttributeValue<EntityReference>("regardingobjectid");
                        if (regardingid.LogicalName.ToLower() == "incident")
                        {
                            String subject = string.Empty;
                            ColumnSet cols = new ColumnSet(new String[] { "whb_dateoffirstresponse", "statuscode" });
                            Entity caseid = organizationService.Retrieve(regardingid.LogicalName, regardingid.Id, cols);
                            DateTime dateofresponse = caseid.GetAttributeValue<DateTime>("whb_dateoffirstresponse");
                            bool directioncode = emailentity.GetAttributeValue<bool>("directioncode");
                            bool isautoreply = emailentity.GetAttributeValue<bool>("whb_isautoreply");
                            int statuscode = caseid.Attributes.Contains("statuscode") ? caseid.GetAttributeValue<OptionSetValue>("statuscode").Value : -1;
                            tracingService.Trace(statuscode.ToString());
                            if (emailentity.Attributes.Contains("subject"))
                            {
                                subject = emailentity.GetAttributeValue<String>("subject");
                            }

                            if (dateofresponse == DateTime.MinValue && directioncode == true && isautoreply == false && statuscode != 5 && statuscode != 6)
                            {
                                caseid.Attributes["whb_dateoffirstresponse"] = DateTime.UtcNow;
                                organizationService.Update(caseid);
                            }
                            else
                            {
                                return;
                            }

                        }
                    }
                }


            }
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                try
                {

                    Entity activity = (Entity)context.InputParameters["Target"];
                    if (context.MessageName.ToLower() == "create")
                    {

                        if (activity.Contains("regardingobjectid"))
                        {
                            EntityReference regardingid = activity.GetAttributeValue<EntityReference>("regardingobjectid");
                            if (regardingid.LogicalName.ToLower() == "incident" && activity.LogicalName.ToString() == "phonecall")
                            {

                                ColumnSet cols = new ColumnSet(new String[] { "whb_dateoffirstresponse" });
                                Entity caseid = organizationService.Retrieve(regardingid.LogicalName, regardingid.Id, cols);
                                DateTime dateofresponse = caseid.GetAttributeValue<DateTime>("whb_dateoffirstresponse");
                                bool directioncode = activity.GetAttributeValue<bool>("directioncode");
                                if (dateofresponse == DateTime.MinValue && directioncode == true)
                                {
                                    caseid.Attributes["whb_dateoffirstresponse"] = DateTime.UtcNow;
                                    organizationService.Update(caseid);
                                }
                                else
                                {
                                    return;
                                }

                            }

                            else if (regardingid.LogicalName.ToLower() == "incident" && activity.LogicalName.ToString() == "whb_socialmedia")
                            {
                                ColumnSet cols = new ColumnSet(new String[] { "whb_dateoffirstresponse" });
                                Entity caseid = organizationService.Retrieve(regardingid.LogicalName, regardingid.Id, cols);
                                DateTime dateofresponse = caseid.GetAttributeValue<DateTime>("whb_dateoffirstresponse");
                                int directioncode = activity.GetAttributeValue<OptionSetValue>("whb_direction").Value;
                                if (dateofresponse == DateTime.MinValue && directioncode == 2)
                                {
                                    caseid.Attributes["whb_dateoffirstresponse"] = DateTime.UtcNow;
                                    organizationService.Update(caseid);
                                }
                                else
                                {
                                    return;
                                }
                            }

                        }
                    }
                }
                catch (Exception ex) { throw new InvalidPluginExecutionException("Exception in FirstResponsePlugin" + ex.Message); }

            }
        }
    }
}
