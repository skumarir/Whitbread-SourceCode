﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.ObjectModel;

/// <summary>
/// This class/plugin is used to check the user's skill set before the user is added to the team.
/// </summary>
public class CheckUserSkillSet : IPlugin
{
    public void Execute(IServiceProvider serviceProvider)
    {
        IPluginExecutionContext Context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
        IOrganizationServiceFactory organizationServiceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
        IOrganizationService organizationService = organizationServiceFactory.CreateOrganizationService(Context.UserId);
        ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
        string teamName = string.Empty;
        bool validateFlag = false;


        if (Context.InputParameters.Contains("Target") && ((DataCollection<string, object>)Context.InputParameters)["Target"] is EntityReference)
        {
            try
            {
                EntityReference target = (EntityReference)((DataCollection<string, object>)Context.InputParameters)["Target"];
                if (Context.MessageName == "Associate" && target.LogicalName == "team")
                {
                    Relationship relationShip = (Relationship)((DataCollection<string, object>)Context.InputParameters)["Relationship"];
                    EntityReferenceCollection relatedentities = (EntityReferenceCollection)((DataCollection<string, object>)Context.InputParameters)["RelatedEntities"];
                    foreach (EntityReference item in relatedentities)
                    {
                        if (item.LogicalName == "systemuser" && relationShip.SchemaName == "teammembership_association")
                        {
                            Guid userId = item.Id;
                            Guid teamId = target.Id;
                            EntityCollection ec = GetTeamDetails(organizationService, teamId);
                            if (ec.Entities.Count == 1)
                            {
                                teamName = (string)((DataCollection<string, object>)((Collection<Entity>)ec.Entities)[0].Attributes)["name"];
                                if(!string.IsNullOrEmpty(teamName))
                                {
                                    teamName = teamName.ToLower();
                                }
                                validateFlag = (bool)((DataCollection<string, object>)((Collection<Entity>)ec.Entities)[0].Attributes)["whb_validateteam"];
                            }

                            string entity1 = "whb_skillset";

                            string entity2 = "systemuser";

                            string relationshipEntityName = "whb_systemuser_whb_skillset_user";

                            QueryExpression queryExpression = new QueryExpression(entity1);

                            queryExpression.ColumnSet = new ColumnSet(true);

                            LinkEntity linkEntity1 = new LinkEntity(entity1, relationshipEntityName, "whb_skillsetid", "whb_skillsetid", Microsoft.Xrm.Sdk.Query.JoinOperator.Inner);

                            LinkEntity linkEntity2 = new LinkEntity(relationshipEntityName, entity2, "systemuserid", "systemuserid", Microsoft.Xrm.Sdk.Query.JoinOperator.Inner);

                            linkEntity1.LinkEntities.Add(linkEntity2);

                            queryExpression.LinkEntities.Add(linkEntity1);

                            linkEntity2.LinkCriteria = new FilterExpression();

                            linkEntity2.LinkCriteria.AddCondition(new ConditionExpression("systemuserid", ConditionOperator.Equal, userId));

                            EntityCollection collection = organizationService.RetrieveMultiple(queryExpression);

                            if (collection.Entities.Count == 0 & validateFlag)
                            {
                                string userName = this.getUsername(organizationService, userId);
                                throw new InvalidPluginExecutionException("The user " + userName + " does not have the requied skill set to be added to team, Please configure the user and his respective skills in Skill set entity");
                            }

                            if (collection.Entities.Count > 0 & validateFlag)
                            {
                                bool notEqualFlag = false;
                                string skillSetName = string.Empty;

                                for (int i = 0; i < collection.Entities.Count; i++)
                                {
                                    skillSetName = collection.Entities[i].Attributes["whb_name"].ToString();
                                    if(!string.IsNullOrEmpty(skillSetName))
                                    {
                                        skillSetName = skillSetName.ToLower();
                                    }
                                    //if (skillSetName == teamName)
                                    //{
                                    //    notEqualFlag = true;
                                    //    break;
                                    //}


                                    //extra code added to validate 4 Managerment Teams with management Skill Set - start
                                    bool teamSkillSetConfigFlag = getTeamSkillSetConfig(organizationService, skillSetName, teamName, userId);
                                    if(teamSkillSetConfigFlag)
                                    {
                                        notEqualFlag = true;
                                        break;
                                    }
                                    //else if (skillSetName == managementSkillSet && (teamName == managerApprovalTeamName || teamName == mmanagerEscalationTeamname || teamName == leisureVoucherTeamName || teamName == complimentsTeamName))
                                    //{
                                    //    notEqualFlag = true;
                                    //    break;
                                    //}
                                    //extra code added to validate 4 Managerment Teams with management Skill Set - end
                                }

                                if (!notEqualFlag)
                                {
                                    string userName = this.getUsername(organizationService, userId);
                                    throw new InvalidPluginExecutionException("The user " + userName + " does not have the requied skill set to be added to team, Please configure the user and his respective skills in Skill set entity or Please check the Customizations Entity for Team Skillset Configuration");
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }

    /// <summary>
    /// This method is used to get team details
    /// </summary>
    /// <param name="_service"> CRM Organization Service Details</param>
    /// <param name="Id"> Team GUID</param>
    /// <returns> returns the query expression which contacts details w.r.t. Team</returns>
    public EntityCollection GetTeamDetails(IOrganizationService _service, Guid Id)
    {
        QueryExpression queryExpression2 = new QueryExpression();
        queryExpression2.EntityName = "team";
        queryExpression2.ColumnSet = new ColumnSet("name", "whb_validateteam");
        //QueryExpression queryExpression = queryExpression2;
        queryExpression2.Criteria.AddCondition("teamid", ConditionOperator.Equal, Id);
        return _service.RetrieveMultiple(queryExpression2);
    }

    /// <summary>
    /// The method is used to get the user name 
    /// </summary>
    /// <param name="_service">CRM Organization Service Details</param>
    /// <param name="Id">User GUID</param>
    /// <returns> returns the name of the user</returns>
    public string getUsername(IOrganizationService _service, Guid Id)
    {
        string userName = string.Empty;
        QueryExpression queryExpression2 = new QueryExpression();
        queryExpression2.EntityName = "systemuser";
        queryExpression2.ColumnSet = new ColumnSet("fullname");
        //QueryExpression queryExpression = queryExpression2;
        queryExpression2.Criteria.AddCondition("systemuserid", ConditionOperator.Equal, Id);
        EntityCollection result = _service.RetrieveMultiple(queryExpression2);
        if (result.Entities.Count > 0)
        {
            userName = (string)((DataCollection<string, object>)((Collection<Entity>)result.Entities)[0].Attributes)["fullname"];
        }
        return userName;
    }

    public bool getTeamSkillSetConfig(IOrganizationService _service, string skillName, string teamName, Guid userId)
    {
        string teamSkillConfigName = "Team SkillSet Configuration";
        bool configFlag = false;
        QueryExpression queryExpression2 = new QueryExpression();
        queryExpression2.EntityName = "whb_customizations";
        queryExpression2.ColumnSet = new ColumnSet("whb_teamskillsetconfig");
        queryExpression2.Criteria.AddCondition("whb_name", ConditionOperator.Equal, teamSkillConfigName);
        EntityCollection ec =  _service.RetrieveMultiple(queryExpression2);
        
        if (ec.Entities.Count > 0)
        {
            string description = ec.Entities[0].GetAttributeValue<string>("whb_teamskillsetconfig");
            string skillSet = string.Empty;

            if (!string.IsNullOrEmpty(description))
            {
                description = description.ToLower();
                string[] skillSetTeamConfig = description.Split('|');
                string[] skillteams;
                string[] teams;
                string skillSetName = string.Empty;

                for (int i = 0; i < skillSetTeamConfig.Length; i++)
                {
                    if (!string.IsNullOrEmpty(skillSetTeamConfig[i]))
                    {
                        skillteams = skillSetTeamConfig[i].Split(':');
                        skillSetName = skillteams[0];
                        skillSetName = skillSetName.Trim();

                        for (int m = 1; m < skillteams.Length; m++)
                        {
                            if (!string.IsNullOrEmpty(skillteams[m]))
                            {
                                teams = skillteams[m].Split(',');
                                for (int n = 0; n < teams.Length; n++)
                                {
                                    teams[n] = teams[n].Trim();
                                    if (skillSetName == skillName && teamName == teams[n])
                                    {
                                        configFlag = true;
                                        return configFlag;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            else
            {
                throw new InvalidPluginExecutionException("There is no Configuration done in Customization Entity to match a Skillset with multiple teams, Kindly create a record in Customizations Entity with record name 'Team SkillSet Configuration', provide a proper value in field 'Skill Set Team Config'. Example value format: Skillset:Teams1,Teams2,Teams3 and then try again");
            }

        }

        else if(ec.Entities.Count == 0)
        {
            throw new InvalidPluginExecutionException("There is no Configuration done in Customization Entity to match a Skillset with multiple teams, Kindly create a record in Customizations Entity with record name 'Team SkillSet Configuration', provide a proper value in field 'Skill Set Team Config'. Example value format: Skillset:Teams1,Teams2,Teams3 and then try again");
        }

        return configFlag;
    }
   

}
