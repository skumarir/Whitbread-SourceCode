﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace autoCasecreationPlugin_FP
{
    public class MailXmlData
    {
        //private string send_Date;
        public string Send_Date
        {
            get; set;
        }

        //private string send_Time;
        public string Send_Time
        {
            get; set;
        }

        //private string brand;
        public string Brand
        {
            get; set;
        }

        //private string submission_Type;
        public string Submission_Type
        {
            get; set;
        }

        //private string submission_Date;
        public string Submission_Date
        {
            get; set;
        }

        //private string submission_Time;
        public string Submission_Time
        {
            get; set;
        }

        //private string title;
        public string Title
        {
            get; set;
        }

        //private string firstName;
        public string FirstName
        {
            get; set;
        }

        //private string lastName;
        public string LastName
        {
            get; set;
        }

        //private string houseNo;
        public string HouseNo
        {
            get; set;
        }

        //private string addressLine1;
        public string AddressLine1
        {
            get; set;
        }

        //private string addressLine2;
        public string AddressLine2
        {
            get; set;
        }

        //private string town;
        public string Town
        {
            get; set;
        }

        //private string country;
        public string Country
        {
            get; set;
        }

        //private string postcode;
        public string Postcode
        {
            get; set;
        }

        //private string mobile;
        public string Mobile
        {
            get; set;
        }

        //private string telephone;
        public string Telephone
        {
            get; set;
        }

        //private bool byPost;
        public bool ByPost
        {
            get; set;
        }

        //private bool byEmail;
        public bool ByEmail
        {
            get; set;
        }
        //private bool byEmail;
        public string Emailaddress
        {
            get; set;
        }
        //private bool bySMS;
        public bool BySMS
        {
            get; set;
        }

        //private bool byOther;
        public bool ByOther
        {
            get; set;
        }

        //private bool loyaltyMember;
        public bool LoyaltyMember
        {
            get; set;
        }

        //private string rewardCardNumber;
        public string RewardCardNumber
        {
            get; set;
        }

        //private string natureOfEnquiry;
        public string NatureOfEnquiry
        {
            get; set;
        }

        //private string restaurantVisited;
        public string RestaurantVisited
        {
            get; set;
        }

        //private string dateOfVisit;
        public string DateOfVisit
        {
            get; set;
        }

        //private string typeOfVisit;
        public string TypeOfVisit
        {
            get; set;
        }

        //private string topic;
        public string Topic
        {
            get; set;
        }

        //private string checkNumber;
        public string CheckNumber
        {
            get; set;
        }
        //private string comment;
        public string Comment
        {
            get; set;
        }


    }
}

