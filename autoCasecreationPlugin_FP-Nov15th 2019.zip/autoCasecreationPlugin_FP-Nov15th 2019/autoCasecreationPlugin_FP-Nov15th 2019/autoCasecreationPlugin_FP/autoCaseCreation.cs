﻿using Microsoft.Xrm.Sdk;
using System;
using Microsoft.Xrm.Sdk.Query;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Globalization;
using System.Net;
using System.IO;

namespace autoCasecreationPlugin_FP
{
    public class autoCaseCreation : IPlugin 
    {
        
        Helper _helper = new Helper();
        MailXmlData mailData = new MailXmlData();
        string APIUserName = "";
        string APIPassword = "";
        string SOAPRequest = "";
        string reservationSearch = "";
        string guestHistoryQuery = "";
        string guestHistorySearch = "";
        string historyRecordDetailQuery = "";
        string feedBackfeedbackRecordQuery = "";
        string guestHistoryNumberResult = "";
        string IncomingEmailRestrictionBART = "";
        bool contactExistsInBART = false;
        Guid newlyCreatedContact = Guid.Empty;
        string lastName = "";
        string firstName = "";
        string emailAddress = "";
        Guid contactIsNewlyCreated = Guid.Empty;
        bool restrictedEmail = false;
        bool isOldContact = false;
        int buisnessarea = -1;
        Guid contactId = Guid.Empty;
        EntityReference team = null;
        int emailtype = -1;
        int loyality = -1;
        string queueEmailaddress = "";
        EntityReference contact = null;
        EntityReference parentCase = null;
        EntityReference teamId = null; EntityReference childCaseTeamId = null; EntityReference dummyPropertyId = null;
        string subject = string.Empty, sender = string.Empty, description = string.Empty; EntityReference privacyTeamId = null;
        Guid incidentId = Guid.Empty; EntityReference account = null; string businessareaName = string.Empty; EntityReference currency = null;
        bool isccemail = false; bool isbccemail = false; Entity queueid = null; int toEmailcount = 0;
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext _context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            IOrganizationServiceFactory _serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));

            IOrganizationService _service = _serviceFactory.CreateOrganizationService(_context.UserId);

            ITracingService _tracer = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            if (_context.InputParameters.Contains("Target") && _context.InputParameters["Target"] is Entity)
            {
                try
                {
                    Entity entity = (Entity)_context.InputParameters["Target"];
                    if (entity.LogicalName == "email") // Email Entity
                    {
                        if (_context.MessageName.ToLower() == "create") // Create Message
                        {
                            EntityReference regardingObject = entity.Attributes.Contains("regardingobjectid") ? entity.GetAttributeValue<EntityReference>("regardingobjectid") : null;
                            Boolean direction = (Boolean)entity.Attributes["directioncode"];
                            if (direction == false) // Email Direction is incoming
                            {
                                EntityCollection to = entity.Attributes.Contains("to") ? ((EntityCollection)entity.Attributes["to"]) : null;
                                EntityCollection cc = entity.Attributes.Contains("cc") ? ((EntityCollection)entity.Attributes["cc"]) : null;
                                EntityCollection bcc = entity.Attributes.Contains("bcc") ? ((EntityCollection)entity.Attributes["bcc"]) : null;
                                if (bcc != null)
                                    _tracer.Trace("BCC entity collection count:" + bcc.Entities.Count.ToString());
                                else
                                    _tracer.Trace("BCC entity collection count is null");

                                //Start of - Logic to retrieve bcc 
                                Entity emailtest = _service.Retrieve("email", entity.Id, new ColumnSet(true));
                                EntityCollection bcctest = emailtest.GetAttributeValue<EntityCollection>("bcc");
                                //End of logic 
                                Entity teamObj = null; 
                                description = entity.Attributes.Contains("description") ? entity.GetAttributeValue<string>("description") : string.Empty;
                                sender = entity.Attributes.Contains("sender") ? entity.GetAttributeValue<string>("sender") : string.Empty;
                                subject = entity.Attributes.Contains("subject") ? entity.GetAttributeValue<string>("subject") : string.Empty;
                                _tracer.Trace("Subject : " + subject);
                                _tracer.Trace("Sender-" + sender.ToString());

                                //if (to != null && to[0].LogicalName == "activityparty")
                                if (to != null || cc != null || bcctest != null)
                                {
                                    //if (to[0].Contains("partyid"))
                                    //{
                                    //EntityReference topartyid = (EntityReference)to[0]["partyid"];
                                    //  _tracer.Trace("t" + topartyid.LogicalName);
                                    // if (topartyid.LogicalName == "queue")
                                            if (to != null)
                                            {
                                               teamObj = fetchpartyteamobject(_service, to, _tracer);
                                               toEmailcount = to.Entities.Count;
                                               _tracer.Trace("To Email Count : " + toEmailcount);
                                            }
                                            else if (cc != null)
                                            {
                                                teamObj = fetchpartyteamobject(_service, cc, _tracer);
                                                if (teamObj != null)
                                                {
                                                    isccemail = true;
                                                }
                                            }
                                            else if (bcctest != null)
                                            {
                                                teamObj = fetchpartyteamobject(_service, bcctest, _tracer);
                                                if (teamObj != null)
                                                {
                                                    isbccemail = true;
                                                }
                                            }
                                    //_tracer.Trace("Test");
                                    //_tracer.Trace("id" + topartyid.Id.ToString());
                                    //Entity queueid = _service.Retrieve(topartyid.LogicalName, topartyid.Id, new ColumnSet("whb_type", "emailaddress", "whb_loyaltymailbox", "whb_webformmailbox"));
                                    // _tracer.Trace("QueueID-"+queueid.Id.ToString());                                            
                                    // queueEmailaddress = queueid.Contains("emailaddress") ? queueid.GetAttributeValue<string>("emailaddress") : string.Empty;
                                    //Entity teamObj = _helper.GetCombinationRecord(_service, queueEmailaddress, _tracer);
                                    //_tracer.Trace("teamobj"+teamObj.Id);

                                    if (teamObj==null)
                                            {
                                                if (cc != null && to != null)
                                                {
                                                    teamObj = fetchpartyteamobject(_service, cc, _tracer);
                                                    if (teamObj == null)
                                                    {
                                                        return;
                                                    }
                                                    else
                                                    {
                                                       isccemail = true;
                                                    }
                                                }
                                                else if (bcctest != null && to != null && cc != null)
                                                {
                                                    teamObj = fetchpartyteamobject(_service, bcctest, _tracer);
                                                    if (teamObj == null)
                                                    {
                                                        return;
                                                    }
                                                    else
                                                    {
                                                        isbccemail = true;
                                                    }
                                                }
                                                else
                                                {
                                                    return;
                                                }
                                            }
                                            teamId = teamObj.Attributes.Contains("whb_emailcasecreationteam") ? teamObj.GetAttributeValue<EntityReference>("whb_emailcasecreationteam") : null;
                                            //_tracer.Trace("team id-"+teamId.Id);
                                            childCaseTeamId = teamObj.Attributes.Contains("whb_childcaseteam") ? teamObj.GetAttributeValue<EntityReference>("whb_childcaseteam") : null;
                                            //_tracer.Trace("child team id-" + childCaseTeamId.Id);
                                            dummyPropertyId = teamObj.Attributes.Contains("whb_property") ? teamObj.GetAttributeValue<EntityReference>("whb_property") : null;
                                            //_tracer.Trace("Dummy Property-" + dummyPropertyId.Id);
                                            privacyTeamId = teamObj.Attributes.Contains("whb_privacyteam") ? teamObj.GetAttributeValue<EntityReference>("whb_privacyteam") : null;
                                            
                                            if (dummyPropertyId != null)
                                            {
                                                Entity functionalArea = _helper.getFunctionalAreaforDummyProperty(_service, dummyPropertyId, _tracer);
                                                if (functionalArea.Attributes.Contains("as.whb_name") && functionalArea.Attributes["as.whb_name"] != null)
                                                {
                                                    businessareaName = (string)((AliasedValue)functionalArea["as.whb_name"]).Value;
                                                    _tracer.Trace("Business Area name-" + businessareaName);
                                                }
                                                if (functionalArea.Attributes.Contains("as.whb_businessareavalue") && functionalArea.Attributes["as.whb_businessareavalue"] != null)
                                                {
                                                    buisnessarea = (int)((AliasedValue)functionalArea["as.whb_businessareavalue"]).Value;
                                                    _tracer.Trace("Business Area Value-" + buisnessarea);
                                                }
                                                currency = functionalArea.Attributes.Contains("whb_currencyid") ? functionalArea.GetAttributeValue<EntityReference>("whb_currencyid") : null;
                                                //_tracer.Trace("Currency-" + currency.Id.ToString());
                                            }

                                            
                                            _tracer.Trace("Loyalty-" + queueid.GetAttributeValue<Boolean>("whb_loyaltymailbox").ToString());
                                            _tracer.Trace("Webform-" + queueid.GetAttributeValue<Boolean>("whb_webformmailbox").ToString());

                                            if (queueid.GetAttributeValue<Boolean>("whb_loyaltymailbox") == true )
                                            {                                                
                                                loyality = 1;
                                            }
                                            else if (queueid.GetAttributeValue<Boolean>("whb_webformmailbox") == true)
                                            {
                                                emailtype = 6;
                                                Xmlretrieve(description, _service, _tracer, entity);
                                            }
                                        //}
                                    //}
                                }
                                

                                #region Get From Address

                                EntityCollection from = ((EntityCollection)entity.Attributes["from"]);
                                if (from != null && from[0].LogicalName == "activityparty")
                                {
                                    if (from[0].Contains("partyid"))
                                    {
                                        EntityReference partyid = (EntityReference)from[0]["partyid"];
                                        if (partyid.LogicalName == "contact")//if (partyid.LogicalName == "contact")
                                        {
                                            _tracer.Trace("Existing Contact");
                                            contactId = partyid.Id;
                                            newlyCreatedContact = contactId; // global variable  
                                            string contactLogicalName = partyid.LogicalName;
                                            contact = new EntityReference(contactLogicalName, contactId);
                                            if (buisnessarea == 1)
                                            {
                                                // When Business area is premier inn bart call will happen
                                                bartcall(_service, _tracer, entity);

                                            }
                                            ///not reqyuired
                                            else if (buisnessarea == 2)
                                            {
                                                // retrieving contact info to update in webform section
                                                retreivingcontactinfo(_service,_tracer);
                                            }
                                        }
                                        else if (partyid.LogicalName == "systemuser") // If email received against system user
                                        {
                                            _tracer.Trace("Existing User");
                                            Guid systemuserId = partyid.Id;
                                            string systemuserName = partyid.LogicalName;
                                            Entity systemuser = _helper.GetSystemUserbyAttribute(_service, systemuserName, "systemuserid", systemuserId.ToString(), new string[] { "firstname", "lastname", "internalemailaddress" });
                                            if (systemuser != null)
                                            {
                                                _tracer.Trace(systemuser.LogicalName.ToString());
                                                firstName = systemuser.Attributes.Contains("firstname") ? systemuser.GetAttributeValue<string>("firstname") : string.Empty;
                                                lastName = systemuser.Attributes.Contains("lastname") ? systemuser.GetAttributeValue<string>("lastname") : string.Empty;
                                                emailAddress = systemuser.Attributes.Contains("internalemailaddress") ? systemuser.GetAttributeValue<string>("internalemailaddress") : string.Empty;
                                            }
                                        }
                                    }
                                }

                                #endregion

                                #region Regarding Case

                                if (regardingObject != null && regardingObject.LogicalName == "incident") // Regarding contains Case
                                {
                                    checkingforchildcase(_service, regardingObject,entity, _tracer);
                                }
                                #endregion

                                #region New Case 

                                else if (emailtype != 6)/// email type check not required change it only to else
                                {
                                    checkingfornewcase(_service, regardingObject, entity, _tracer);
                                }

                                #endregion
                            }
                        }
                    }

                }
                catch (Exception ex)
                {
                    //throw new InvalidPluginExecutionException("An error occured in Autocasecreation plugin, please contact your system administrator. " + ex.Message);
                    _tracer.Trace("An error occured, please contact your system administrator. " + ex.Message);

                }
            }
        }
        /// <summary>
        /// Below function is used for handling when new email comes to CRM
        /// </summary>
        /// <param name="_service"></param>
        /// <param name="regardingObject"></param>
        /// <param name="entity"></param>
        /// <param name="_tracer"></param>
        public void checkingfornewcase(IOrganizationService _service, EntityReference regardingObject, Entity entity, ITracingService _tracer)
        {
            try
            {
                _tracer.Trace("New Case Creation");
                if (contact != null)
                {
                    account = _helper.GetCompany(_service, contact, _tracer); // Retrieve contact company information.
                    _tracer.Trace("Existing Contact");
                    CreateCase(_service, contact, account, sender, parentCase, description, subject, entity, sender, _tracer, buisnessarea, loyality, teamId, childCaseTeamId, dummyPropertyId);
                }
                else
                {
                    // if Email is received by communication partner (Except User, Contact) we need to check same email address present in contact or not
                    QueryExpression queryExpression = new QueryExpression { EntityName = "contact", ColumnSet = new ColumnSet(new string[] { "contactid", "firstname", "lastname", "emailaddress1" }) };
                    queryExpression.Criteria.AddCondition("statecode", ConditionOperator.NotEqual, 1);
                    queryExpression.Criteria.AddCondition("emailaddress1", ConditionOperator.Equal, sender.ToString());
                    EntityCollection result = _service.RetrieveMultiple(queryExpression);
                    if (result.Entities.Count == 1)
                    {
                        Guid contactId = (Guid)result.Entities[0].Attributes["contactid"];
                        firstName = result.Entities[0].Attributes.Contains("firstname") ? result.Entities[0].GetAttributeValue<string>("firstname") : string.Empty;
                        lastName = result.Entities[0].Attributes.Contains("lastname") ? result.Entities[0].GetAttributeValue<string>("lastname") : string.Empty;
                        emailAddress = sender.ToString();
                        contact = new EntityReference("contact", contactId);
                        if (contact != null)
                            CreateCase(_service, contact, account, sender, parentCase, description, subject, entity, sender, _tracer, buisnessarea, loyality, teamId, childCaseTeamId, dummyPropertyId);
                    }
                    else if (result.Entities.Count != 1)
                    {
                        _tracer.Trace("New Contact");
                        contact = _helper.GetDummyContact(_service, _tracer);
                        if (contact != null)
                            CreateCase(_service, contact, account, sender, parentCase, description, subject, entity, sender, _tracer, buisnessarea, loyality, teamId, childCaseTeamId, dummyPropertyId);
                    }
                }
            }
            catch (Exception) { throw; }
        }
        /// <summary>
        /// Below function is used for handling emails when it comes to existing case
        /// </summary>
        /// <param name="_service"></param>
        /// <param name="regardingObject"></param>
        /// <param name="entity"></param>
        /// <param name="_tracer"></param>
        public void checkingforchildcase(IOrganizationService _service,EntityReference regardingObject,Entity entity,ITracingService _tracer)
        {
            try
            {

                _tracer.Trace(" objcject" + regardingObject.Id);

                Entity regardingCase = _service.Retrieve(regardingObject.LogicalName, regardingObject.Id, new ColumnSet("incidentid", "statuscode", "statecode", "parentcaseid"));

                int stateCode = regardingCase.Attributes.Contains("statecode") ? regardingCase.GetAttributeValue<OptionSetValue>("statecode").Value : -1;
                int statusCode = regardingCase.Attributes.Contains("statuscode") ? regardingCase.GetAttributeValue<OptionSetValue>("statuscode").Value : -1;
                parentCase = regardingCase.Attributes.Contains("parentcaseid") ? regardingCase.GetAttributeValue<EntityReference>("parentcaseid") : null;
                if (stateCode == 1 || stateCode == 2) // Regarding case has been resolved or cancled
                {
                    _tracer.Trace("Regarding Case has been resolved");
                    if (parentCase == null)
                        parentCase = regardingObject;

                    if (contact != null)
                    {
                        _tracer.Trace("Existing Contact");
                        account = _helper.GetCompany(_service, contact, _tracer);
                        CreateCase(_service, contact, account, sender, parentCase, description, subject, entity, sender, _tracer, buisnessarea, loyality, teamId, childCaseTeamId, dummyPropertyId);
                    }
                    else
                    {
                        _tracer.Trace("New Contact");
                        contact = _helper.GetDummyContact(_service, _tracer);
                        if (contact != null)
                            CreateCase(_service, contact, account, sender, parentCase, description, subject, entity, sender, _tracer, buisnessarea, loyality, teamId, childCaseTeamId, dummyPropertyId);
                    }
                }
                else // Regarding case is open
                {
                    string lblWhitbread = "whitbread.com";
                    string lblPremierInn = "premierinn.com";
                    string lblWorldline = "worldline.com";


                    if (statusCode == 130570009 && sender != null && !string.IsNullOrEmpty(sender) && (!sender.ToLower().EndsWith(lblWhitbread) || !sender.ToLower().EndsWith(lblPremierInn))) //case status == Awaiting Customer Feedback
                    {
                        UpdateCase(_service, regardingObject.Id, true, statusCode);
                    }

                    else if ((statusCode == 130570000 && sender != null && !string.IsNullOrEmpty(sender)) && (sender.ToLower().EndsWith(lblWhitbread) || sender.ToLower().EndsWith(lblPremierInn))) //case status == Awaiting internal communication
                    {
                        UpdateCase(_service, regardingObject.Id, false, statusCode);
                    }

                    else if ((statusCode == 130570002 && sender != null && !string.IsNullOrEmpty(sender)) && (sender.ToLower().EndsWith(lblWhitbread) || sender.ToLower().EndsWith(lblPremierInn))) //case status == Awaiting Site Feedback
                    {
                        UpdateCase(_service, regardingObject.Id, false, statusCode);
                    }

                    else if ((statusCode == 130570011 && sender != null && !string.IsNullOrEmpty(sender)) && sender.ToLower().EndsWith(lblWorldline)) //case status == Awaiting External Communication
                    {
                        UpdateCase(_service, regardingObject.Id, false, statusCode);
                    }

                    else if ((statusCode == 130570000 || statusCode == 130570002 || statusCode == 130570011) && sender != null && !string.IsNullOrEmpty(sender) && (!sender.ToLower().EndsWith(lblWhitbread) || !sender.ToLower().EndsWith(lblPremierInn))) // case status = Awaiting internal communication or Awaiting Site Feedback and External Customers
                    {
                        UpdateCase(_service, regardingObject.Id, true, 130570009);
                    }
                }

            }
            catch (Exception) { throw; }
        }
        /// <summary>
        /// Retrieving contactinfo for updating in webform section in case for restaurant
        /// </summary>
        /// <param name="_service"></param>
        /// <param name="_tracer"></param>
        public void retreivingcontactinfo(IOrganizationService _service,ITracingService _tracer)
        {
            try {

                ColumnSet cols = new ColumnSet(new String[] { "lastname", "firstname", "createdon", "modifiedon", "emailaddress1" });
                // Retrieve Contact information
                var contactEntity = _service.Retrieve("contact", contactId, cols);
                if (contactEntity != null)
                {


                    if (contactEntity.Attributes.Contains("lastname"))
                    {
                        lastName = contactEntity.Attributes["lastname"].ToString();
                        _tracer.Trace("Last Name :" + lastName);
                    }
                    if (contactEntity.Attributes.Contains("firstname"))
                    {
                        firstName = contactEntity.Attributes["firstname"].ToString();
                        _tracer.Trace("First Name :" + firstName);
                    }
                    if (contactEntity.Attributes.Contains("emailaddress1"))
                    {
                        emailAddress = contactEntity.Attributes["emailaddress1"].ToString();
                        _tracer.Trace("Email Address :" + emailAddress);
                    }
                }
            }
            catch (Exception) { throw; }

        }
            
        /// <summary>
        /// Business Area = Premier INN
        /// </summary>
        /// <param name="_service"></param>
        /// <param name="_tracer"></param>
        /// <param name="entity"></param>
        public void bartcall(IOrganizationService _service,ITracingService _tracer,Entity entity)
        {
            try
            {
                GetCustomizations(_service);
                ColumnSet cols = new ColumnSet(new String[] { "lastname", "firstname", "createdon", "modifiedon", "emailaddress1" });
                // Retrieve Contact information
                var contactEntity = _service.Retrieve("contact", contactId, cols);

                if (contactEntity != null)
                {
                    DateTime createdOn;

                    if (contactEntity.Attributes.Contains("lastname"))
                    {
                        lastName = contactEntity.Attributes["lastname"].ToString();
                        _tracer.Trace("Last Name :" + lastName);
                    }
                    if (contactEntity.Attributes.Contains("firstname"))
                    {
                        firstName = contactEntity.Attributes["firstname"].ToString();
                        _tracer.Trace("First Name :" + firstName);
                    }
                    if (contactEntity.Attributes.Contains("emailaddress1"))
                    {
                        emailAddress = contactEntity.Attributes["emailaddress1"].ToString();
                        _tracer.Trace("Email Address :" + emailAddress);
                    }
                    createdOn = Convert.ToDateTime(contactEntity.Attributes["createdon"]);
                    DateTime emailReceivedOn = Convert.ToDateTime(entity.Attributes["createdon"]);

                    _tracer.Trace("Contact Created On : " + createdOn.ToString());
                    _tracer.Trace("Email Created On : " + emailReceivedOn.ToString());

                    // check the from emai related to resolver emails
                    if (IncomingEmailRestrictionBART != "")
                    {
                        _tracer.Trace(IncomingEmailRestrictionBART.ToString());
                        string[] emailExten;
                        emailExten = IncomingEmailRestrictionBART.Split(',');
                        string emailVerify = emailAddress.Split('@')[1].ToString();
                        _tracer.Trace(emailVerify);
                        foreach (var item in emailExten)
                        {
                            _tracer.Trace(item);
                            if (emailVerify == item)
                            {
                                _tracer.Trace("Incoming email domain is exist in resolver domain");
                                restrictedEmail = true; // if the contact coming form resolver email then tag dummy contact.
                                contact = _helper.GetDummyContactForResolver(_service, _tracer, emailVerify);//GetDummyContact(_service, _tracer);
                                if (contact != null)
                                {
                                    _tracer.Trace("Resolver conatct" + contact.Name);
                                    contactIsNewlyCreated = contactEntity.Id;
                                    Entity activityParty = new Entity("activityparty");
                                    activityParty["partyid"] = contact;
                                    entity.Attributes["from"] = new Entity[] { activityParty };

                                    Entity partyDraft = new Entity("email", entity.Id);
                                    partyDraft["statecode"] = new OptionSetValue(0); //Status
                                    partyDraft["statuscode"] = new OptionSetValue(1); //Status reason
                                    _service.Update(partyDraft);
                                    _service.Update(entity);
                                    Entity party = new Entity("email", entity.Id);
                                    party["statecode"] = new OptionSetValue(1); //Status
                                    party["statuscode"] = new OptionSetValue(4); //Status reason
                                    _service.Update(party);
                                }
                            }
                        }
                    }
                    if (restrictedEmail == false)
                    {
                        TimeSpan ts = emailReceivedOn - createdOn; // Difference between Email created on and Contact Created on.
                        int differenceInMinutes = ts.Minutes;
                        double differenceInSeconds = ts.TotalSeconds;
                        _tracer.Trace("Time Difference in Second :" + differenceInSeconds.ToString());
                        if (differenceInSeconds < 10)
                        {
                            _tracer.Trace("Newly Created Contact");
                            isOldContact = false;
                            contactIsNewlyCreated = contactId;
                            XmlDocument webResponse = null;
                            webResponse = GetContactDetails(lastName, emailAddress, firstName);
                            ReadContactResponse(webResponse, _service, contactId);
                        }
                        else
                            isOldContact = true;
                    }
                    _tracer.Trace("contactExistsInBART" + contactExistsInBART.ToString());
                    _tracer.Trace("isOldContact" + isOldContact.ToString());
                    _tracer.Trace("restrictedEmail" + restrictedEmail.ToString());
                    if (contactExistsInBART == false && isOldContact == false && restrictedEmail == false)
                    {
                        _tracer.Trace("Get DummyContact");
                        contact = _helper.GetDummyContact(_service, _tracer);
                        if (contact != null)
                        {
                            Entity activityParty = new Entity("activityparty");
                            activityParty["partyid"] = contact;
                            entity.Attributes["from"] = new Entity[] { activityParty };

                            Entity partyDraft = new Entity("email", entity.Id);
                            partyDraft["statecode"] = new OptionSetValue(0); //Status
                            partyDraft["statuscode"] = new OptionSetValue(1); //Status reason
                            _service.Update(partyDraft);
                            _service.Update(entity);
                            Entity party = new Entity("email", entity.Id);
                            party["statecode"] = new OptionSetValue(1); //Status
                            party["statuscode"] = new OptionSetValue(4); //Status reason
                            _service.Update(party);
                        }
                    }

                }
            }
            catch (Exception ex) { throw; }
            

        }
        

        /// <summary>
        /// New or Child case creation
        /// </summary>
        /// <param name="_service"></param>
        /// <param name="contact"></param>
        /// <param name="sender"></param>
        /// <param name="parentCase"></param>
        /// <param name="description"></param>
        /// <param name="email"></param>
        /// <param name="_tracer"></param>
        public void CreateCase(IOrganizationService _service, EntityReference contact, EntityReference account, string sender, EntityReference parentCase, string description, string subject, Entity email, string senderEmail, ITracingService _tracer, int buisnessarea, int loyality, EntityReference teamId, EntityReference childCaseTeamId, EntityReference dummyPropertyId)
        {
            try
            {
                #region Case Creation

                _tracer.Trace("Case Creation");

                //EntityReference parentOwner = null;
                EntityReference closedBy = null;
                Guid caseId = Guid.Empty;
                Entity incident = new Entity("incident");
                // if (contactExistsInBART == false && isOldContact == false && restrictedEmail == false)
                // {
                if (firstName != string.Empty && firstName != "")
                    incident["whb_wffirstname"] = firstName;
                if (lastName != string.Empty && lastName != "")
                    incident["whb_wflastname"] = lastName;
                if (emailAddress != string.Empty && emailAddress != "")
                    incident["whb_wfemailaddress"] = emailAddress;
                // }

                _tracer.Trace("Subject 2 :" + subject.ToString() + "--");
                if (subject != string.Empty)
                    incident["title"] = subject;
                else
                    incident["title"] = "Email";
                _tracer.Trace("1");

                if (account != null)
                    incident["whb_company"] = new EntityReference(account.LogicalName, account.Id);
                _tracer.Trace("2");

                if (description != string.Empty)
                {
                    string descrp = _helper.StripHTML(description);
                    incident["whb_summary"] = descrp.Trim();
                }
                _tracer.Trace("3");

                incident["whb_date1stcontactreceived"] = DateTime.Now;
                incident["whb_contacttype"] = new OptionSetValue(130570002);

                if (dummyPropertyId != null)
                {
                    incident["whb_property"] = new EntityReference(dummyPropertyId.LogicalName, dummyPropertyId.Id);
                }

                if (queueEmailaddress != string.Empty)
                {
                    incident["whb_wfsource"] = queueEmailaddress;
                }
                _tracer.Trace("4");

                if (buisnessarea != -1)
                    incident["whb_businessareavalue"] = buisnessarea;

                if(businessareaName!=string.Empty)
                {
                    incident["whb_businessarea_fp"] = businessareaName;
                }
                if(currency!=null)
                {
                    incident["transactioncurrencyid"] = new EntityReference(currency.LogicalName, currency.Id);
                }
                if(isccemail)
                {
                    incident["whb_casegremailcc"] = Convert.ToBoolean(isccemail);
                }
                incident["whb_caseemailtocount"] = Convert.ToInt32(toEmailcount);

                if (senderEmail != string.Empty)
                    incident["whb_emailsender"] = senderEmail;
                int exec = -1, escalated = -1;
                //int resolutionCode = -1;
                bool assignChildCasetoTeam = false;
                _tracer.Trace("5");


                if (parentCase != null)
                {
                    _tracer.Trace("6");

                    #region Set Parent Case
                    incident["whb_childcaseflag"] = true;
                    incident["parentcaseid"] = new EntityReference(parentCase.LogicalName, parentCase.Id);
                    Entity pc = _helper.GetEntitybyAttribute(_service, parentCase.LogicalName, "incidentid", parentCase.Id.ToString(), new string[] { "whb_resolutioncode_fp", "whb_escalated", "whb_contacttype", "whb_reservation", "prioritycode", "whb_dateofincident", "whb_teammembernotified", "whb_reasonteammembernotnotified", "whb_teammemberresponseaction", "whb_feedbackcard", "whb_complimentrybreakfast", "whb_primarycategory", "whb_primarysubcategory", "whb_secondarycategory", "whb_secondarysubcategory", "whb_tertiarycategory", "whb_tertiarysubcategory", "whb_contact", "whb_property", "whb_outcomedetail", "whb_primaryfeedbackdetail", "whb_secondaryfeedbackdetail", "whb_checknumber_r", "whb_businessareavalue", "whb_businessarea_fp", "whb_guestpromisegiven", "whb_closedby" });
                    if (pc != null)
                    {
                        _tracer.Trace("7");

                        _tracer.Trace(pc.LogicalName.ToString());
                        EntityReference reservation = pc.Attributes.Contains("whb_reservation") ? pc.GetAttributeValue<EntityReference>("whb_reservation") : null;
                        EntityReference primaryCategory = pc.Attributes.Contains("whb_primarycategory") ? pc.GetAttributeValue<EntityReference>("whb_primarycategory") : null;
                        EntityReference primarySubCategory = pc.Attributes.Contains("whb_primarysubcategory") ? pc.GetAttributeValue<EntityReference>("whb_primarysubcategory") : null;
                        EntityReference secondaryCategory = pc.Attributes.Contains("whb_secondarycategory") ? pc.GetAttributeValue<EntityReference>("whb_secondarycategory") : null;
                        EntityReference secondarySubCategory = pc.Attributes.Contains("whb_secondarysubcategory") ? pc.GetAttributeValue<EntityReference>("whb_secondarysubcategory") : null;
                        EntityReference tertiaryCategory = pc.Attributes.Contains("whb_tertiarycategory") ? pc.GetAttributeValue<EntityReference>("whb_tertiarycategory") : null;
                        EntityReference tertiarySubCategory = pc.Attributes.Contains("whb_tertiarysubcategory") ? pc.GetAttributeValue<EntityReference>("whb_tertiarysubcategory") : null;
                        EntityReference property = pc.Attributes.Contains("whb_property") ? pc.GetAttributeValue<EntityReference>("whb_property") : null;
                        EntityReference parentContact = pc.Attributes.Contains("whb_contact") ? pc.GetAttributeValue<EntityReference>("whb_contact") : null;
                        EntityReference outcomedetail = pc.Attributes.Contains("whb_outcomedetail") ? pc.GetAttributeValue<EntityReference>("whb_outcomedetail") : null;
                        EntityReference primaryFeedbackDetail = pc.Attributes.Contains("whb_primaryfeedbackdetail") ? pc.GetAttributeValue<EntityReference>("whb_primaryfeedbackdetail") : null;
                        EntityReference secondaryFeedbackDetail = pc.Attributes.Contains("whb_secondaryfeedbackdetail") ? pc.GetAttributeValue<EntityReference>("whb_secondaryfeedbackdetail") : null;
                        EntityReference resolutionCodeRecord = pc.Attributes.Contains("whb_resolutioncode_fp") ? pc.GetAttributeValue<EntityReference>("whb_resolutioncode_fp") : null;
                        Boolean guestpromisegiven = pc.Attributes.Contains("whb_guestpromisegiven") ? pc.GetAttributeValue<Boolean>("whb_guestpromisegiven") : false;
                        string checknumber = pc.Attributes.Contains("whb_checknumber_r") ? pc.GetAttributeValue<string>("whb_checknumber_r") : string.Empty;
                        int businessAreaValue = pc.Attributes.Contains("whb_businessareavalue") ? pc.GetAttributeValue<int>("whb_businessareavalue") : -1;
                        string businessAreaName = pc.Attributes.Contains("whb_businessarea_fp") ? pc.GetAttributeValue<string>("whb_businessarea_fp") : string.Empty;
                        //resolutionCode = pc.Attributes.Contains("whb_resolutioncode") ? pc.GetAttributeValue<OptionSetValue>("whb_resolutioncode").Value : -1;
                        int priority = pc.Attributes.Contains("prioritycode") ? pc.GetAttributeValue<OptionSetValue>("prioritycode").Value : -1;
                        exec = pc.Attributes.Contains("whb_contacttype") ? pc.GetAttributeValue<OptionSetValue>("whb_contacttype").Value : -1;
                        escalated = pc.Attributes.Contains("whb_escalated") ? pc.GetAttributeValue<OptionSetValue>("whb_escalated").Value : -1;
                        Boolean tmn = pc.Attributes.Contains("whb_teammembernotified") ? pc.GetAttributeValue<Boolean>("whb_teammembernotified") : false;
                        Boolean cbf = pc.Attributes.Contains("whb_complimentrybreakfast") ? pc.GetAttributeValue<Boolean>("whb_complimentrybreakfast") : false;
                        Boolean fc = pc.Attributes.Contains("whb_feedbackcard") ? pc.GetAttributeValue<Boolean>("whb_feedbackcard") : false;
                        string rtmnn = pc.Attributes.Contains("whb_reasonteammembernotnotified") ? pc.GetAttributeValue<string>("whb_reasonteammembernotnotified") : string.Empty;
                        string tmra = pc.Attributes.Contains("whb_teammemberresponseaction") ? pc.GetAttributeValue<string>("whb_teammemberresponseaction") : string.Empty;
                        DateTime dateOfIncident = pc.Attributes.Contains("whb_dateofincident") ? pc.GetAttributeValue<DateTime>("whb_dateofincident") : DateTime.MinValue;
                        //parentOwner = pc.Attributes.Contains("ownerid") ? pc.GetAttributeValue<EntityReference>("ownerid") : null;
                        closedBy = pc.Attributes.Contains("whb_closedby") ? pc.GetAttributeValue<EntityReference>("whb_closedby") : null;
                        _tracer.Trace("8");

                        if (exec == 130570010 || escalated == 2)
                        {
                            EntityReference team = _helper.GetTeambyAttribute(ref _service, "team", "whb_assignmenttype", 5, new string[] { "name", "teamid", "whb_assignmenttype" });
                            if (team != null)
                            {                                
                                incident["ownerid"] = new EntityReference(team.LogicalName, team.Id);                                
                            }
                        }
                        else if (exec != 130570010 && parentCase != null)
                        {
                            _tracer.Trace("testing1");
                            ColumnSet columnSet = new ColumnSet("isdisabled");
                            Entity user = (Entity)_service.Retrieve("systemuser", closedBy.Id, columnSet);
                            bool status = user.GetAttributeValue<Boolean>("isdisabled");
                            if (status == false && !queueEmailaddress.ToLower().Contains("pi.accessible"))
                            {
                                _tracer.Trace("Parent case closed" + user.Id);
                                Entity rc = (Entity)_service.Retrieve("whb_resolutioncode", resolutionCodeRecord.Id, new ColumnSet("whb_assignchildcasetoteam"));
                                assignChildCasetoTeam = rc.Attributes.Contains("whb_assignchildcasetoteam") ? rc.GetAttributeValue<Boolean>("whb_assignchildcasetoteam") : false;
                                _tracer.Trace("Assign child case to Team-" + assignChildCasetoTeam);

                                if (assignChildCasetoTeam==true) 
                                {
                                    _tracer.Trace("testing 4");
                                    incident["ownerid"] = new EntityReference(childCaseTeamId.LogicalName, childCaseTeamId.Id);
                                }

                                else
                                {
                                    incident["ownerid"] = new EntityReference(closedBy.LogicalName, closedBy.Id);
                                }                              

                            }

                            else if (queueEmailaddress.ToLower().Contains("pi.accessible") || queueEmailaddress.ToLower().Contains("escalations"))
                            {
                                incident["ownerid"] = new EntityReference(teamId.LogicalName, teamId.Id);
                            }
                            
                            else
                            {
                                _tracer.Trace("testing 3");
                                incident["ownerid"] = new EntityReference(childCaseTeamId.LogicalName, childCaseTeamId.Id);
                            }             
                            
                        }
                        _tracer.Trace("9");


                        if (parentContact != null)
                        {
                            _tracer.Trace(parentCase.LogicalName.ToString());
                            incident["whb_contact"] = new EntityReference(parentContact.LogicalName, parentContact.Id);
                            incident["customerid"] = new EntityReference(parentContact.LogicalName, parentContact.Id);
                        }
                        if (property != null)
                        {
                            incident["whb_property"] = new EntityReference(property.LogicalName, property.Id);
                        }
                        if (reservation != null)
                        {
                            incident["whb_reservation"] = new EntityReference(reservation.LogicalName, reservation.Id);
                        }
                        if (primaryCategory != null)
                        {
                            incident["whb_primarycategory"] = new EntityReference(primaryCategory.LogicalName, primaryCategory.Id);
                        }
                        if (primarySubCategory != null)
                        {
                            incident["whb_primarysubcategory"] = new EntityReference(primarySubCategory.LogicalName, primarySubCategory.Id);
                        }
                        if (secondaryCategory != null)
                        {
                            incident["whb_secondarycategory"] = new EntityReference(secondaryCategory.LogicalName, secondaryCategory.Id);
                        }
                        if (secondarySubCategory != null)
                        {
                            incident["whb_secondarysubcategory"] = new EntityReference(secondarySubCategory.LogicalName, secondarySubCategory.Id);
                        }
                        if (tertiaryCategory != null)
                        {
                            incident["whb_tertiarycategory"] = new EntityReference(tertiaryCategory.LogicalName, tertiaryCategory.Id);
                        }
                        if (tertiarySubCategory != null)
                        {
                            incident["whb_tertiarysubcategory"] = new EntityReference(tertiarySubCategory.LogicalName, tertiarySubCategory.Id);
                        }
                        
                        if (businessAreaValue != -1)
                        {
                            _tracer.Trace("Parent Business Area Value-" + businessAreaValue);
                            incident["whb_businessareavalue"] = businessAreaValue;
                        }
                        if (businessAreaName != string.Empty)
                        {
                            _tracer.Trace("Parent Business Area Name-" + businessAreaName);
                            incident["whb_businessarea_fp"] = businessAreaName;
                        }
                        
                        if (priority != -1)
                        {
                            incident["prioritycode"] = new OptionSetValue(priority);
                        }
                        
                        if (rtmnn != string.Empty)
                        {
                            incident["whb_reasonteammembernotnotified"] = rtmnn;
                        }
                        
                        if (tmra != string.Empty)
                        {
                            incident["whb_teammemberresponseaction"] = tmra;
                        }

                        if (dateOfIncident != DateTime.MinValue)
                        {                            
                            incident["whb_dateofincident"] = dateOfIncident;
                        }
                        
                        if (outcomedetail != null && outcomedetail.Id != Guid.Empty)
                        {
                            incident["whb_outcomedetail"] = new EntityReference(outcomedetail.LogicalName, outcomedetail.Id);
                            _tracer.Trace("outcome detail-" + outcomedetail.Id);
                        }

                        if (primaryFeedbackDetail != null)
                        {
                            incident["whb_primaryfeedbackdetail"] = new EntityReference(primaryFeedbackDetail.LogicalName, primaryFeedbackDetail.Id);
                            _tracer.Trace("primaryFeedbackDetail-" + primaryFeedbackDetail.Id);

                        }

                        if (secondaryFeedbackDetail != null)
                        {
                            incident["whb_secondaryfeedbackdetail"] = new EntityReference(secondaryFeedbackDetail.LogicalName, secondaryFeedbackDetail.Id);
                            _tracer.Trace("secondaryFeedbackDetail-" + secondaryFeedbackDetail.Id);

                        }

                        if (checknumber != string.Empty)
                        {
                            incident["whb_checknumber_r"] = checknumber;
                            _tracer.Trace("checknumber-" + checknumber);

                        }

                        incident["whb_guestpromisegiven"] = guestpromisegiven;
                        incident["whb_teammembernotified"] = tmn;
                        incident["whb_complimentrybreakfast"] = cbf;
                        incident["whb_feedbackcard"] = fc;
                        _tracer.Trace("10");

                    }
                   #endregion
                }
                

                else
                {
                    if (contact != null)
                    {
                        _tracer.Trace("11");

                        incident["whb_contact"] = new EntityReference("contact", contact.Id);
                        incident["customerid"] = new EntityReference("contact", contact.Id);
                    }

                    if (loyality == 1)
                    {
                        _tracer.Trace("12");

                        //Query Expression for getting category if it is loyality case

                        QueryExpression query = new QueryExpression();
                        query.EntityName = "whb_category";
                        query.ColumnSet = new ColumnSet("whb_name");
                        query.Criteria.AddCondition("whb_name", ConditionOperator.Equal, "Restaurant Loyalty");
                        EntityCollection category = _service.RetrieveMultiple(query);
                        if (category.Entities.Count > 0)
                        {
                            incident["whb_primarycategory"] = new EntityReference(category.Entities[0].LogicalName, category.Entities[0].Id);
                        }
                    }
                    _tracer.Trace("13");

                    //incident["ownerid"] = new EntityReference(teamId.LogicalName,teamId.Id);
                    _tracer.Trace("14");
                    incident["ownerid"] = new EntityReference(teamId.LogicalName, teamId.Id);

                }

                _tracer.Trace("15");                
                caseId = _service.Create(incident);
                _tracer.Trace("Case ID: " + caseId.ToString());


                #endregion

                if (caseId != Guid.Empty)
                {
                    #region Update email regarding with case
                    if (caseId != Guid.Empty)
                    {
                        _tracer.Trace("Case Exist");
                        EntityReference MainCaseEntityRef = new EntityReference("incident", new Guid(caseId.ToString()));

                        _tracer.Trace("Inside function");
                        Entity partyDraft = new Entity("email", email.Id);
                        partyDraft["statecode"] = new OptionSetValue(0); //Status
                        partyDraft["statuscode"] = new OptionSetValue(1); //Status reason
                        partyDraft["regardingobjectid"] = MainCaseEntityRef;


                        _service.Update(partyDraft);
                        Entity party = new Entity("email", email.Id);
                        party["statecode"] = new OptionSetValue(1); //Status
                        party["statuscode"] = new OptionSetValue(4); //Status reason
                        _service.Update(party);             


                    }
                    _tracer.Trace("Email Updated");
                    #endregion
                }

                // delete contact not exists in BART
                if (contactExistsInBART == false && isOldContact == false && restrictedEmail == false && newlyCreatedContact != Guid.Empty && buisnessarea == 1)
                {
                    bool casecount = contactassociation(newlyCreatedContact, _service);
                    bool contactcount = customerassociation(newlyCreatedContact, _service);
                    if (casecount == false && contactcount == false)
                    {
                        _service.Delete("contact", newlyCreatedContact);
                    }


                }


                // delete contact
                // contact is related to the resolver

                if (restrictedEmail == true && newlyCreatedContact != Guid.Empty && buisnessarea == 1)
                {
                    bool casecount = contactassociation(newlyCreatedContact, _service);

                    bool contactcount = customerassociation(newlyCreatedContact, _service);
                    if (casecount == false && contactcount == false)
                    {
                        _service.Delete("contact", newlyCreatedContact);
                    }

                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("An error occured while creating case, please contact your system administrator. " + ex.Message);
                //_tracer.Trace("An error occured in Email to case, please contact your system administrator. " + ex.Message);
            }
        }
        /// <summary>
        /// To check contact associated with case or not
        /// </summary>
        public bool contactassociation(Guid newlyCreatedContact, IOrganizationService _service)
        {
            bool noofcases = false;
            //query expression for checking contact associated with case
            QueryExpression query = new QueryExpression();
            query.EntityName = "incident";
            query.ColumnSet = new ColumnSet("customerid");
            query.Criteria.AddCondition("customerid", ConditionOperator.Equal, newlyCreatedContact.ToString());

            EntityCollection casecollection = _service.RetrieveMultiple(query);
            if (casecollection.Entities.Count > 0)
            {

                noofcases = true;
            }
            return noofcases;
        }
        /// <summary>
        /// To check contact associated with case or not
        /// </summary>
        public bool customerassociation(Guid newlyCreatedContact, IOrganizationService _service)
        {
            bool noofcases = false;
            //query expression for checking contact associated with case
            QueryExpression query = new QueryExpression();
            query.EntityName = "incident";
            query.ColumnSet = new ColumnSet("customerid");
            query.Criteria.AddCondition("whb_contact", ConditionOperator.Equal, newlyCreatedContact.ToString());

            EntityCollection casecollection = _service.RetrieveMultiple(query);
            if (casecollection.Entities.Count > 0)
            {

                noofcases = true;
            }
            return noofcases;
        }
        /// <summary>
        /// Retreiving XMl from Email
        /// </summary>
        /// <param name="description"></param>
        public void Xmlretrieve(string description, IOrganizationService _service, ITracingService _tracer, Entity email)
        {
            description = _helper.StripHTML(description);
            _tracer.Trace("description" + description);
            if (description != string.Empty)
                description = description.Remove(description.LastIndexOf("</CustomerRequest>") + "</CustomerRequest>".Length).Remove(0, description.IndexOf("<CustomerRequest>"));
            description = description.Replace("&", "&amp;");
            string commentretrieve = description;
            int startcomment = commentretrieve.IndexOf("<Comment>") + "<Comment>".Length;
            int endcomment = (commentretrieve.IndexOf("</Comment>") - (commentretrieve.IndexOf("<Comment>") + "<Comment>".Length));
            string comment = commentretrieve.Substring(startcomment, endcomment);
            _tracer.Trace("comment" + comment);
            int startnode = description.IndexOf("<Comment>");
            int endnode = description.IndexOf("</Comment>");
            description = description.Remove(description.IndexOf("<Comment>"), (description.LastIndexOf("</Comment>") - (description.IndexOf("<Comment>")) + "</Comment>".Length));
            _tracer.Trace("descriptiontest" + description);
            XmlDocument xmldoc = new XmlDocument();

            xmldoc.LoadXml(description);

            XmlNode xnList1 = xmldoc.SelectSingleNode("CustomerRequest");

            XmlNode xnList2 = xmldoc.SelectSingleNode("CustomerRequest/CustomerDetail");
            if (xnList1.SelectSingleNode("Send_Date") != null)
            {
                mailData.Send_Date = xnList1["Send_Date"].InnerText;
                string dt = DateTime.ParseExact(mailData.Send_Date, "yyyyMMdd", CultureInfo.InvariantCulture).ToString("yyyy/MM/dd");
            }
            if (xnList1.SelectSingleNode("Send_Time") != null)
            {
                mailData.Send_Time = xnList1["Send_Time"].InnerText;
                string time = DateTime.Parse(mailData.Send_Time).ToString("HH:mm:ss");
            }
            if (xnList1.SelectSingleNode("Brand") != null)
            {
                mailData.Brand = xnList1["Brand"].InnerText;
            }
            if (xnList1.SelectSingleNode("Submission_Type") != null)
            {
                mailData.Submission_Type = xnList1["Submission_Type"].InnerText;
            }
            if (xnList1.SelectSingleNode("Submission_Date") != null)
            {
                mailData.Submission_Date = xnList1["Submission_Date"].InnerText;
            }
            if (xnList1.SelectSingleNode("Submission_Time") != null)
            {
                mailData.Submission_Date = xnList1["Submission_Time"].InnerText;
            }
            if (xnList2.SelectSingleNode("Title") != null)
            {
                mailData.Title = xnList2["Title"].InnerText;
            }
            if (xnList2.SelectSingleNode("FirstName") != null)
            {
                mailData.FirstName = xnList2["FirstName"].InnerText;
            }
            if (xnList2.SelectSingleNode("LastName") != null)
            {
                mailData.LastName = xnList2["LastName"].InnerText;
            }
            if (xnList2.SelectSingleNode("HouseNo") != null)
            {
                mailData.HouseNo = xnList2["HouseNo"].InnerText;
            }
            if (xnList2.SelectSingleNode("AddressLine1") != null)
            {
                mailData.AddressLine1 = xnList2["AddressLine1"].InnerText;
            }
            if (xnList2.SelectSingleNode("AddressLine2") != null)
            {
                mailData.AddressLine2 = xnList2["AddressLine2"].InnerText;
            }
            if (xnList2.SelectSingleNode("Town") != null)
            {
                mailData.Town = xnList2["Town"].InnerText;
            }
            if (xnList2.SelectSingleNode("Country") != null)
            {
                mailData.Country = xnList2["Country"].InnerText;
            }
            if (xnList2.SelectSingleNode("Postcode") != null)
            {
                mailData.Postcode = xnList2["Postcode"].InnerText;
            }
            if (xnList2.SelectSingleNode("Mobile") != null)
            {
                mailData.Mobile = xnList2["Mobile"].InnerText;
            }
            if (xnList2.SelectSingleNode("EmailAddress") != null)
            {
                mailData.Emailaddress = xnList2["EmailAddress"].InnerText;
            }
            if (xnList2.SelectSingleNode("ByPost") != null)
            {
                mailData.ByPost = Convert.ToBoolean(Convert.ToInt16(xnList2["ByPost"].InnerText));
            }
            if (xnList2.SelectSingleNode("ByEmail") != null)
            {
                mailData.ByEmail = Convert.ToBoolean(Convert.ToInt16(xnList2["ByEmail"].InnerText));
            }
            if (xnList2.SelectSingleNode("BySMS") != null)
            {
                mailData.BySMS = Convert.ToBoolean(Convert.ToInt16(xnList2["BySMS"].InnerText));
            }
            if (xnList2.SelectSingleNode("ByOther") != null)
            {
                mailData.ByOther = Convert.ToBoolean(Convert.ToInt16(xnList2["ByOther"].InnerText));
            }
            if (xnList2.SelectSingleNode("LoyaltyMember") != null)
            {
                if (xnList2["LoyaltyMember"].InnerText == "N")
                {
                    mailData.LoyaltyMember = false;
                }
                else
                {
                    mailData.LoyaltyMember = true;
                }
            }
            if (xnList2.SelectSingleNode("RewardCardNumber") != null)
            {
                mailData.RewardCardNumber = xnList2["RewardCardNumber"].InnerText;
            }

            if (xnList2.SelectSingleNode("NatureOfEnquiry") != null)
            {
                mailData.NatureOfEnquiry = xnList2["NatureOfEnquiry"].InnerText;
            }
            if (xnList2.SelectSingleNode("RestaurantVisited") != null)
            {
                mailData.RestaurantVisited = xnList2["RestaurantVisited"].InnerText;
            }
            if (xnList2.SelectSingleNode("DateOfVisit") != null)
            {
                mailData.DateOfVisit = xnList2["DateOfVisit"].InnerText;
            }
            if (xnList2.SelectSingleNode("TypeOfVisit") != null)
            {
                mailData.TypeOfVisit = xnList2["TypeOfVisit"].InnerText;
            }
            if (xnList2.SelectSingleNode("Topic") != null)
            {
                mailData.Topic = xnList2["Topic"].InnerText;
            }
            if (xnList2.SelectSingleNode("CheckNumber") != null)
            {
                mailData.CheckNumber = xnList2["CheckNumber"].InnerText;
            }
            if (comment != string.Empty)
            {
                mailData.Comment = comment;
            }
            // mailData.Comment = xnList2["Comment"].InnerText;
            if (xnList2.SelectSingleNode("Telephone") != null)
            {
                mailData.Telephone = xnList2["Telephone"].InnerText;
            }

            // DateTime completedate = DateTime.Parse(mydt);
            createcaseforresxml(mailData, _service, _tracer, email);
        }


        /// <summary>
        /// To retrieve the values from XML which is sent in email body
        /// </summary>
        /// <param name="mailData"></param>
        /// <param name="_service"></param>
        /// <param name="_tracer"></param>
        /// <param name="email"></param>
        public void createcaseforresxml(MailXmlData mailData, IOrganizationService _service, ITracingService _tracer, Entity email)
        {
            string contactemail = string.Empty;
            if (mailData.Emailaddress != string.Empty)
            {
                contactemail = mailData.Emailaddress.Replace(" ", string.Empty);
            }

            _tracer.Trace(contactemail);
            Guid caseId = Guid.Empty;
            Entity incident = new Entity("incident");
            //getting the contact creation
            QueryExpression contactretrieve = new QueryExpression();
            contactretrieve.EntityName = "contact";
            contactretrieve.ColumnSet = new ColumnSet("emailaddress1");
            contactretrieve.Criteria.AddCondition("emailaddress1", ConditionOperator.Equal, contactemail);
            EntityCollection contact = _service.RetrieveMultiple(contactretrieve);
            _tracer.Trace(contact.Entities.Count.ToString());
            if (contact.Entities.Count > 0)
                contactId = contact.Entities[0].Id;
            else
                contactId = createcontactres(mailData, _service, _tracer);
            if (contactId != Guid.Empty)
            {
                incident.Attributes["whb_contact"] = new EntityReference("contact", contactId);
                incident.Attributes["customerid"] = new EntityReference("contact", contactId);
            }
            _tracer.Trace("001");

            if (mailData.Title != string.Empty)
                incident.Attributes["whb_wftitle"] = mailData.Title;
            _tracer.Trace("002");

            if (mailData.FirstName != string.Empty)
                incident.Attributes["whb_wffirstname"] = mailData.FirstName;
            if (mailData.LastName != string.Empty)
                incident.Attributes["whb_wflastname"] = mailData.LastName;
            _tracer.Trace("003");

            int reasonforcontact = _helper.reasonforcontact(mailData.NatureOfEnquiry);
            if (reasonforcontact != -1)
            {
                incident.Attributes["whb_reasonforcontact"] = new OptionSetValue(reasonforcontact);
            }
            _tracer.Trace("004");

            if (mailData.Topic != string.Empty)
            {
                incident.Attributes["whb_webformcategory"] = mailData.Topic;
                incident.Attributes["whb_wfreasonforfeedback"] = mailData.Topic;
            }
            _tracer.Trace("005");

            incident.Attributes["whb_wfhotelname"] = mailData.RestaurantVisited;
            _tracer.Trace("006");
            
            if (mailData.Comment != string.Empty)
                incident.Attributes["whb_summary"] = mailData.Comment;
            _tracer.Trace("007");


            if (mailData.DateOfVisit != string.Empty)
            {
                incident.Attributes["whb_dateofincident"] = Convert.ToDateTime(DateTime.ParseExact(mailData.DateOfVisit, "yyyyMMdd", CultureInfo.InvariantCulture).ToString("MM/dd/yyyy"));
                incident.Attributes["whb_wfdateofstayifapplicable"] = Convert.ToDateTime(DateTime.ParseExact(mailData.DateOfVisit, "yyyyMMdd", CultureInfo.InvariantCulture).ToString("MM/dd/yyyy"));
            }

            _tracer.Trace("008");

            if (mailData.TypeOfVisit != string.Empty)
            {
                int timevisit = _helper.timevisited(mailData.TypeOfVisit);

                incident.Attributes["whb_visitcategory"] = new OptionSetValue(timevisit);
                incident.Attributes["whb_wftypeofvisit"] = mailData.TypeOfVisit;
            }
            _tracer.Trace("009");

            if (mailData.CheckNumber != string.Empty)
            {
                incident.Attributes["whb_checknumber_r"] = mailData.CheckNumber;
                incident.Attributes["whb_wfchecknumber"] = mailData.CheckNumber;
            }
            _tracer.Trace("010");

            if (mailData.HouseNo != string.Empty)
                incident.Attributes["whb_wfaddressline1"] = mailData.HouseNo;
            if (mailData.AddressLine1 != string.Empty)
                incident.Attributes["whb_wfaddressline2"] = mailData.AddressLine1;
            if (mailData.AddressLine2 != string.Empty)
                incident.Attributes["whb_wfaddressline3"] = mailData.AddressLine2;
            if (mailData.Town != string.Empty)
                incident.Attributes["whb_wftowncity"] = mailData.Town;
            if (mailData.Country != string.Empty)
                incident.Attributes["whb_wfcountry"] = mailData.Country;
            if (mailData.Postcode != string.Empty)
                incident.Attributes["whb_wfpostcode"] = mailData.Postcode;
            if (mailData.Emailaddress != string.Empty)
                incident.Attributes["whb_wfemailaddress"] = mailData.Emailaddress;
            if (mailData.Mobile != string.Empty)
                incident.Attributes["whb_wfcontactnumber"] = mailData.Mobile;
            if (mailData.Telephone != string.Empty)
                incident.Attributes["whb_wftelephonenumber"] = mailData.Telephone;
            if (queueEmailaddress != string.Empty)
            {
                incident["whb_wfsource"] = queueEmailaddress;
            }
            _tracer.Trace("011");

            incident.Attributes["title"] = "Feedback Form";
            _tracer.Trace("012");
            incident.Attributes["whb_contacttype"] = new OptionSetValue(130570009);
            //incident["whb_emailsender"] = mailData.Emailaddress.Replace(" ", string.Empty);
            incident["whb_emailsender"] = mailData.Emailaddress.Trim();            
            _tracer.Trace("013");            
            caseId = _service.Create(incident);
            _tracer.Trace("case created");

            //email["regardingobjectid"] = new EntityReference("incident",caseId);
            Entity partyDraft = new Entity("email", email.Id);
            partyDraft["statecode"] = new OptionSetValue(0); //Status
            partyDraft["statuscode"] = new OptionSetValue(1); //Status reason
            partyDraft["regardingobjectid"] = new EntityReference("incident", caseId);
            _service.Update(partyDraft);
            partyDraft["statecode"] = new OptionSetValue(1); //Status
            partyDraft["statuscode"] = new OptionSetValue(4); //Status reason
            _tracer.Trace("case updated");
            _service.Update(partyDraft);

        }
        /// <summary>
        /// To update the Case
        /// </summary>
        /// <param name="_service"></param>
        /// <param name="caseId"></param>
        /// <param name="intExtFlag"></param>
        /// <param name="statuscode"></param>
        public void UpdateCase(IOrganizationService _service, Guid caseId, bool intExtFlag, int statuscode)
        {
            try
            {
                Entity incident = new Entity("incident");

                if (intExtFlag == true && statuscode == 130570009)
                {
                    incident["statuscode"] = new OptionSetValue(130570003); // Update case to Customer Feedback Received
                }
                else if (intExtFlag == false && statuscode == 130570000)
                {
                    incident["statuscode"] = new OptionSetValue(130570004); // Update case to Internal Communication Received
                }
                else if (intExtFlag == false && statuscode == 130570011)
                {
                    incident["statuscode"] = new OptionSetValue(130570012); // update case to External Communication received
                }
                else if (intExtFlag == false && statuscode == 130570002)
                {
                    incident["statuscode"] = new OptionSetValue(130570007); // Update case to site Feed Back  Received
                }

                incident["incidentid"] = caseId;
                _service.Update(incident);

                // delete contact not exists in BART
                // delete contact not exists in BART
                if (contactExistsInBART == false && isOldContact == false && restrictedEmail == false && newlyCreatedContact != Guid.Empty && buisnessarea == 1)
                {
                    bool casecount = contactassociation(newlyCreatedContact, _service);
                    bool contactcount = customerassociation(newlyCreatedContact, _service);
                    if (casecount == false && contactcount == false)
                    {
                        _service.Delete("contact", newlyCreatedContact);
                    }
                }

                if (restrictedEmail == true && newlyCreatedContact != Guid.Empty && buisnessarea == 1)
                {
                    bool casecount = contactassociation(newlyCreatedContact, _service);

                    bool contactcount = customerassociation(newlyCreatedContact, _service);
                    if (casecount == false && contactcount == false)
                    {
                        _service.Delete("contact", newlyCreatedContact);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("An error occured while creating case, please contact your system administrator. " + ex.Message);

            }
        }
        /// <summary>
        /// To create contact if not exisiting for Restaurant
        /// </summary>
        /// <param name="mailData"></param>
        /// <param name="_service"></param>
        /// <param name="_tracer"></param>
        /// <returns></returns>
        public Guid createcontactres(MailXmlData mailData, IOrganizationService _service, ITracingService _tracer)
        {
            try
            {
                _tracer.Trace("new contact");
                Entity contact = new Entity("contact");
                if (mailData.Title != "")
                {
                    int titleValue = _helper.ContactTitle(mailData.Title);
                    if (titleValue != 12)
                        contact.Attributes["whb_title1"] = new OptionSetValue(titleValue);

                }

                if (mailData.FirstName != "")
                    contact.Attributes["firstname"] = mailData.FirstName;
                if (mailData.LastName != "")
                    contact.Attributes["lastname"] = mailData.LastName;


                if (mailData.HouseNo != "")
                    contact.Attributes["address1_line1"] = mailData.HouseNo;
                if (mailData.AddressLine1 != "")
                    contact.Attributes["address1_line2"] = mailData.AddressLine1;
                if (mailData.AddressLine2 != "")
                    contact.Attributes["address1_line3"] = mailData.AddressLine2;

                //contact.Attributes["address1_line3"] = mailData.Town;
                contact.Attributes["address1_country"] = mailData.Country;
                if (mailData.Postcode != "")
                    contact.Attributes["address1_postalcode"] = mailData.Postcode;
                contact.Attributes["mobilephone"] = mailData.Mobile;
                if (mailData.Telephone != "")
                    contact.Attributes["telephone1"] = mailData.Telephone;
                if (mailData.Town != "")
                    contact.Attributes["address1_city"] = mailData.Town;

                if (mailData.Emailaddress != "")
                    contact.Attributes["emailaddress1"] = mailData.Emailaddress.Replace(" ", string.Empty);
                    
                contactId = _service.Create(contact);
                return contactId;
            }
            catch (Exception ex) { throw new InvalidPluginExecutionException(ex.Message); }

            // return Guid.Empty;
        }


        public void GetCustomizations(IOrganizationService _service)
        {
            try
            {
                QueryExpression queryExpression = new QueryExpression { EntityName = "whb_customizations", ColumnSet = new ColumnSet(new string[] { "whb_description", "whb_name" }) };

                object lstValues = new object[] { "APIPassword", "APIUserName", "GuestHistoryQuery", "GuestHistorySearch", "HistoryRecordDetailQuery", "ReservationSearch", "WSDLService", "FeedBackSearch" };
                queryExpression.Criteria.AddCondition("whb_name", ConditionOperator.In, new object[] { "APIPassword", "APIUserName", "GuestHistoryQuery", "GuestHistorySearch", "HistoryRecordDetailQuery", "ReservationSearch", "WSDLService", "FeedBackSearch", "IncomingEmailRestrictionBART" });
                EntityCollection customizations = _service.RetrieveMultiple(queryExpression);
                if (customizations.Entities.Count > 0)
                {
                    foreach (Entity item in customizations.Entities)
                    {
                        string configDescription = item.Attributes["whb_description"].ToString(); // results.value[i]["whb_description"];
                        string configName = item.Attributes["whb_name"].ToString(); ;// results.value[i]["whb_name"];

                        if (configName == "APIPassword")
                        {
                            APIPassword = configDescription;
                        }

                        if (configName == "APIUserName")
                        {
                            APIUserName = configDescription;
                        }

                        if (configName == "GuestHistoryQuery")
                        {
                            guestHistoryQuery = configDescription;
                        }

                        if (configName == "GuestHistorySearch")
                        {
                            guestHistorySearch = configDescription;
                        }

                        if (configName == "HistoryRecordDetailQuery")
                        {
                            historyRecordDetailQuery = configDescription;
                        }

                        if (configName == "ReservationSearch")
                        {
                            reservationSearch = configDescription;
                        }

                        if (configName == "WSDLService")
                        {
                            SOAPRequest = configDescription;
                        }

                        if (configName == "FeedBackSearch")
                        {
                            feedBackfeedbackRecordQuery = configDescription;
                        }

                        if (configName == "IncomingEmailRestrictionBART")
                        {
                            IncomingEmailRestrictionBART = configDescription;
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                //_tracer.Trace(ex.Message);
            }
        }

        public XmlDocument GetContactDetails(string surname, string emailAddress, string firstname)
        {
            try
            {
                var requestData = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:cas=\"http://caseman.oracle.com\"><soapenv:Header><Login><username>" + APIUserName + "</username><password>" + APIPassword + "</password></Login></soapenv:Header><soapenv:Body>";
                requestData += "<cas:guestHistorySearch><cas:request>";
                requestData += "<cas:surname>" + surname + "</cas:surname>";
                requestData += "<cas:firstName>" + firstname + "</cas:firstName>";
                requestData += "<cas:postcode></cas:postcode>";
                requestData += "<cas:addressLine1></cas:addressLine1>";
                requestData += "<cas:telephone></cas:telephone>";
                requestData += "<cas:companyName></cas:companyName>";
                requestData += "<cas:guestHistoryNumber></cas:guestHistoryNumber>";
                requestData += "<cas:email>" + emailAddress + "</cas:email>";
                requestData += "</cas:request></cas:guestHistorySearch>";
                requestData += "</soapenv:Body></soapenv:Envelope>";

                XmlDocument webResponse = FormRequest(SOAPRequest, guestHistorySearch, requestData);

                return webResponse;
            }
            catch (Exception ex)
            {

            }

            return null;
        }

        public XmlDocument FormRequest(string SOAPRequest, string SOAPAction, string requestedData)
        {
            try
            {
                HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(SOAPRequest);
                webRequest.Headers.Add("SOAPAction", SOAPAction);
                webRequest.ContentType = "text/xml;charset=\"utf-8\"";
                webRequest.Accept = "text/xml";
                webRequest.Method = "POST";
                webRequest.Timeout = System.Threading.Timeout.Infinite;
                var bytes = System.Text.Encoding.ASCII.GetBytes(requestedData);
                webRequest.ContentLength = bytes.Length;
                Stream str = webRequest.GetRequestStream();
                StreamWriter strwriter = new StreamWriter(str, Encoding.ASCII);
                strwriter.Write(requestedData.ToString());
                strwriter.Close();

                HttpWebResponse res = (HttpWebResponse)webRequest.GetResponse();
                StreamReader rdr = new StreamReader(res.GetResponseStream());
                string result = rdr.ReadToEnd();

                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(result);

                return xmlDoc;
            }
            catch (Exception ex)
            {

                //throw;
            }

            return null;
        }

        public void ReadContactResponse(XmlDocument xmlResponse, IOrganizationService _service, Guid contactId)
        {

            string firstname = "";
            string lastname = "";
            string address1_line1 = "";
            string address1_line2 = "";
            string address1_line3 = "";
            string address1_country = "";
            string address1_postalcode = "";
            string mobilephone = "";
            string telephone1 = "";
            string emailaddress1 = "";
            string addressType = "";
            string companyName = "";
            string companyCode = "";
            string postalCode = "";
            try
            {
                XmlNodeList guestHistorySearchResult = xmlResponse.GetElementsByTagName("guest");

                // If we get only one guest for the search, get the guest hisoty number
                // If we get more guests, stop processing next steps
                if (guestHistorySearchResult.Count == 1)
                {
                    foreach (XmlNode guestNodeList in guestHistorySearchResult)// Guest Details
                    {
                        // we can creat a guest here 
                        foreach (XmlNode guestNodeItems in guestNodeList.ChildNodes)// Guest Details
                        {
                            if (guestNodeItems.Name == "historyNumber")
                                guestHistoryNumberResult = guestNodeItems.InnerText;

                            XmlDocument webResponse = GetGuestHisotryQueriyDetails(guestHistoryNumberResult);

                            XmlNodeList guestHistoryQueryResult = webResponse.GetElementsByTagName("guestDetails");

                            foreach (XmlNode guestHistory in guestHistoryQueryResult)
                            {
                                foreach (XmlNode guestHistoryChildNodes in guestHistory.ChildNodes)
                                {
                                    if (guestHistoryChildNodes.Name == "firstName")
                                        firstname = guestHistoryChildNodes.InnerText;
                                    if (guestHistoryChildNodes.Name == "lastName")
                                        lastname = guestHistoryChildNodes.InnerText;

                                    contactExistsInBART = true;

                                    if (guestHistoryChildNodes.Name == "homeAddress")
                                    {
                                        foreach (XmlNode businessAddressNode in guestHistoryChildNodes.ChildNodes)
                                        {
                                            if (businessAddressNode.Name == "postCode")
                                                postalCode = businessAddressNode.InnerText;
                                            if (businessAddressNode.Name == "addressLine1")
                                                address1_line1 = businessAddressNode.InnerText;
                                            if (businessAddressNode.Name == "addressLine2")
                                                address1_line2 = businessAddressNode.InnerText;
                                            if (businessAddressNode.Name == "addressLine3")
                                                address1_line3 = businessAddressNode.InnerText;
                                            if (businessAddressNode.Name == "countryCode")
                                                address1_country = businessAddressNode.InnerText;
                                            if (businessAddressNode.Name == "postCode")
                                                address1_postalcode = businessAddressNode.InnerText;
                                            if (businessAddressNode.Name == "emailId")
                                                emailaddress1 = businessAddressNode.InnerText;

                                            if (businessAddressNode.Name == "telephoneNumbers")
                                            {
                                                foreach (XmlNode telephoneNumbers in businessAddressNode.ChildNodes)
                                                {
                                                    foreach (XmlNode telephoneNode in telephoneNumbers.ChildNodes)
                                                    {
                                                        if (telephoneNode.Name == "telephoneNumber" && telephoneNumbers.FirstChild.InnerText == "MOBILE")
                                                            mobilephone = telephoneNode.InnerText;
                                                    }

                                                    foreach (XmlNode telephoneNode in telephoneNumbers.ChildNodes)
                                                    {
                                                        if (telephoneNode.Name == "telephoneNumber" && telephoneNumbers.FirstChild.InnerText != "MOBILE")
                                                            telephone1 = telephoneNode.InnerText;
                                                    }
                                                }
                                            }

                                            if (businessAddressNode.Name == "companyName")
                                                companyName = businessAddressNode.InnerText;
                                            if (businessAddressNode.Name == "companyId")
                                                companyCode = businessAddressNode.InnerText;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw;
            }
            if (contactExistsInBART == true)
                CrateContactEntity(firstname, lastname, address1_line1, address1_line2, address1_line3, address1_country,
                        postalCode, mobilephone, telephone1, emailaddress1, addressType, companyName, companyCode, _service, contactId);
        }

        public void CrateContactEntity(string firstname, string lastname, string addressLine1, string addressLine2, string addressLine3, string countryCode,
         string postCode, string mobileNumber, string telephoneNumber, string emailAddress, string addressType, string companyName, string companyCode, IOrganizationService _service, Guid contactId)
        {
            try
            {
                Entity contact = new Entity("contact");
                contact.Attributes["whb_guesthistorynumber"] = guestHistoryNumberResult;
                //contact.Attributes["firstname"] = firstname;
                //contact.Attributes["lastname"] = lastname;
                contact.Attributes["address1_line1"] = addressLine1;
                contact.Attributes["address1_line2"] = addressLine2;
                contact.Attributes["address1_line3"] = addressLine3;
                contact.Attributes["address1_country"] = countryCode;
                contact.Attributes["address1_postalcode"] = postCode;
                contact.Attributes["mobilephone"] = mobileNumber;
                contact.Attributes["telephone1"] = telephoneNumber;
                //contact.Attributes["emailaddress1"] = emailAddress;
                contact.Attributes["whb_addresstype"] = new OptionSetValue(Convert.ToInt32(1));

                contact.Id = contactId;
                _service.Update(contact);

            }
            catch (Exception ex)
            {

            }
        }

        public XmlDocument GetGuestHisotryQueriyDetails(string guestHistoryNumber)
        {
            try
            {
                var requestData = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:cas=\"http://caseman.oracle.com\"><soapenv:Header><Login><username>" + APIUserName + "</username><password>" + APIPassword + "</password></Login></soapenv:Header><soapenv:Body>";
                requestData += "<cas:guestHistoryQuery><cas:request>";
                requestData += "<cas:guestHistoryNumber>" + guestHistoryNumber + "</cas:guestHistoryNumber>";
                requestData += "</cas:request></cas:guestHistoryQuery>";
                requestData += "</soapenv:Body></soapenv:Envelope>";

                XmlDocument webResponse = FormRequest(SOAPRequest, guestHistoryQuery, requestData);
                return webResponse;

            }
            catch (Exception ex)
            {

            }

            return null;
        }

        /// <summary>
        /// Below function for fetching paryID email related details and fetch the queue details
        /// </summary>
        /// <param name="_service"></param>
        /// <param name="toorcc"></param>
        /// <param name="_tracer"></param>
        public Entity fetchpartyteamobject(IOrganizationService _service, EntityCollection toorcc, ITracingService _tracer)
        {
            Entity teamObj = null;
            try
            {
                if (toorcc != null && toorcc.Entities.Count > 0)
                {
                    for (var i = 0; i < toorcc.Entities.Count; i++)
                    {
                        if (toorcc[i].LogicalName == "activityparty" && toorcc[i].Contains("partyid"))
                        {
                            EntityReference partyid = (EntityReference)toorcc[i]["partyid"];
                            _tracer.Trace("t" + partyid.LogicalName);
                            if (partyid.LogicalName == "queue")
                            {
                                _tracer.Trace("Partyid" + partyid.Id.ToString());
                                queueid = _service.Retrieve(partyid.LogicalName, partyid.Id, new ColumnSet("whb_type", "emailaddress", "whb_loyaltymailbox", "whb_webformmailbox"));
                                _tracer.Trace("QueueID-" + queueid.Id.ToString());
                                queueEmailaddress = queueid.Contains("emailaddress") ? queueid.GetAttributeValue<string>("emailaddress") : string.Empty;
                                teamObj = _helper.GetCombinationRecord(_service, queueEmailaddress, _tracer);
                                if (teamObj != null)
                                {
                                    _tracer.Trace("teamobj" + teamObj.Id);
                                     break;
                                }
                            }
                        }
                     }
                    return teamObj;
                }
                else
                {
                    return teamObj;
                }

            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

    }
}

