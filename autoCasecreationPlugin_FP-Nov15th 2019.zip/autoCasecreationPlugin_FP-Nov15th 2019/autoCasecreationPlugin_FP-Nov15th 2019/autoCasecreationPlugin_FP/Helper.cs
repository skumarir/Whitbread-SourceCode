﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace autoCasecreationPlugin_FP
{
    public class Helper
    {
        /// <summary>
        /// Get Entity record by passing any attribute value.
        /// </summary>
        /// <param name="_service"></param>
        /// <param name="entityName"></param>
        /// <param name="attributeName"></param>
        /// <param name="attributeValue"></param>
        /// <param name="arrColumns"></param>
        /// <returns></returns>
        public Entity GetEntitybyAttribute(IOrganizationService _service, string entityName, string attributeName, string attributeValue, string[] arrColumns)
        {
            Entity entRec = null;
            try
            {
                ConditionExpression condRec = new ConditionExpression(attributeName, ConditionOperator.Equal, attributeValue);
                ConditionExpression condRec1 = new ConditionExpression("statecode", ConditionOperator.NotEqual, 0);
                FilterExpression filtRec = new FilterExpression(LogicalOperator.And);
                filtRec.Conditions.AddRange(condRec, condRec1);
                QueryExpression queryRec = new QueryExpression(entityName);
                queryRec.Criteria = filtRec;
                queryRec.ColumnSet = new ColumnSet(arrColumns);
                EntityCollection colRec = _service.RetrieveMultiple(queryRec);
                if (colRec != null && colRec.Entities.Count > 0)
                {
                    entRec = colRec.Entities[0];
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return entRec;
        }

        public Entity GetSystemUserbyAttribute(IOrganizationService _service, string entityName, string attributeName, string attributeValue, string[] arrColumns)
        {
            Entity entRec = null;
            try
            {
                ConditionExpression condRec = new ConditionExpression(attributeName, ConditionOperator.Equal, attributeValue);
                // ConditionExpression condRec1 = new ConditionExpression("statecode", ConditionOperator.NotEqual, 0);
                FilterExpression filtRec = new FilterExpression(LogicalOperator.And);
                filtRec.Conditions.AddRange(condRec);
                QueryExpression queryRec = new QueryExpression(entityName);
                queryRec.Criteria = filtRec;
                queryRec.ColumnSet = new ColumnSet(arrColumns);
                EntityCollection colRec = _service.RetrieveMultiple(queryRec);
                if (colRec != null && colRec.Entities.Count > 0)
                {
                    entRec = colRec.Entities[0];
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return entRec;
        }

        /// <summary>
        /// Get Dummycontact from contact
        /// </summary>
        /// <param name="_service"></param>
        /// <param name="_tracer"></param>
        /// <returns></returns>
        public EntityReference GetDummyContact(IOrganizationService _service, ITracingService _tracer)
        {
            EntityReference dummyContact = null;
            QueryExpression queryExpression = new QueryExpression { EntityName = "contact", ColumnSet = new ColumnSet(new string[] { "contactid" }) };
            queryExpression.Criteria.AddCondition("statecode", ConditionOperator.NotEqual, 1);
            queryExpression.Criteria.AddCondition("fullname", ConditionOperator.Equal, "Dummy Contact");
            EntityCollection result = _service.RetrieveMultiple(queryExpression);
            if (result.Entities.Count == 1)
            {
                Guid contactId = (Guid)result.Entities[0].Attributes["contactid"];
                dummyContact = new EntityReference("contact", contactId);
            }
            return dummyContact;
        }

        public EntityReference GetDummyContactForResolver(IOrganizationService _service, ITracingService _tracer, string lastname)
        {
            EntityReference dummyContact = null;
            QueryExpression queryExpression = new QueryExpression { EntityName = "contact", ColumnSet = new ColumnSet(new string[] { "contactid" }) };
            queryExpression.Criteria.AddCondition("fullname", ConditionOperator.Equal, "Resolver DummyContact");
            EntityCollection result = _service.RetrieveMultiple(queryExpression);
            if (result.Entities.Count > 0)
            {
                Guid contactId = (Guid)result.Entities[0].Attributes["contactid"];
                dummyContact = new EntityReference("contact", contactId);
            }
            return dummyContact;
        }
        /// <summary>
        /// to get the combination record
        /// </summary>
        /// <param name="_service"></param>
        /// <param name="queueEmailaddress"></param>
        /// <param name="_tracer"></param>
        /// <returns></returns>
        public Entity GetCombinationRecord(IOrganizationService _service, string queueEmailaddress, ITracingService _tracer)
        {
            _tracer.Trace("Start -- GetTeamId Method.");
            string sourceId = string.Empty;
            if (queueEmailaddress != string.Empty)
            {
                sourceId = GetSourceId(_service, queueEmailaddress, _tracer);
            }
            QueryExpression queryExpression = new QueryExpression { EntityName = "whb_caseassignment", ColumnSet = new ColumnSet(new string[] { "whb_emailcasecreationteam", "whb_childcaseteam", "whb_property" }) };

            if (sourceId != string.Empty)
            {
                queryExpression.Criteria.AddCondition("whb_sourceid", ConditionOperator.Equal, sourceId);
                queryExpression.Criteria.AddCondition("whb_brandid", ConditionOperator.Null);
            }
                //string teamId = string.Empty;

                try
            {
                EntityCollection result = _service.RetrieveMultiple(queryExpression);
                //_tracer.Trace("Retrieve records -- GetTeamId Method.");
                foreach (var item in result.Entities)
                {
                    //teamId = ((EntityReference)(item.Attributes["whb_emailcasecreationteam"])).Id.ToString();
                    _tracer.Trace("item");
                    return item;
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in GetTeamId Method : " + ex.Message);
                throw;
            }

            return null;
        }
        /// <summary>
        /// to get the source record
        /// </summary>
        /// <param name="_service"></param>
        /// <param name="queueEmailaddress"></param>
        /// <param name="_tracer"></param>
        /// <returns></returns>
        public string GetSourceId(IOrganizationService _service, string queueEmailaddress, ITracingService _tracer)
        {
            try
            {
                _tracer.Trace("Start -- GetSourceId Method.");
                QueryExpression queryExpression = new QueryExpression { EntityName = "whb_source", ColumnSet = new ColumnSet(new string[] { "whb_name" }) };
                queryExpression.Criteria.AddCondition("whb_name", ConditionOperator.Equal, queueEmailaddress);
                EntityCollection ecSource = _service.RetrieveMultiple(queryExpression);

                foreach (Entity item in ecSource.Entities)
                {
                    _tracer.Trace("Source Id : " + item.Id.ToString());
                    return item.Id.ToString();
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in GetSourceId Method : " + ex.Message);
                throw;
            }

            return "";
        }

        /// <summary>
        /// To get the Functional Area record (Getting currency, Business Area Value and Business Area from Functional Area)
        /// </summary>
        /// <param name="_service"></param>
        /// <param name="dummyPropertyId"></param>
        /// <param name="_tracer"></param>
        /// <returns></returns>
        public Entity getFunctionalAreaforDummyProperty(IOrganizationService _service, EntityReference dummyPropertyId, ITracingService _tracer)
        {
            try
            {
                _tracer.Trace("inside getFunctionalAreaforDummyProperty method");

                var fetch = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                              <entity name='whb_brand'>
                                <attribute name='whb_brandid' />
                                <attribute name='whb_name' />
                                <attribute name='whb_currencyid' />
                                <attribute name='whb_businessareaid' />
                                <order attribute='whb_name' descending='false' />
                                <link-entity name='whb_property' from='whb_brandid' to='whb_brandid' link-type='inner' alias='ah'>
                                  <filter type='and'>
                                    <condition attribute='whb_propertyid' operator='eq' value='" + dummyPropertyId.Id + "'/>" + @"
                                  </filter>
                                </link-entity>
                                <link-entity name='whb_businessarea' from='whb_businessareaid' to='whb_businessareaid' visible='false' link-type='outer' alias='as'>
                                  <attribute name='whb_name' />
                                  <attribute name='whb_businessareavalue' />
                                </link-entity>
                              </entity>
                            </fetch>";
                _tracer.Trace("after fetch");
                EntityCollection ecFA = _service.RetrieveMultiple(new FetchExpression(fetch));
                foreach (Entity eFA in ecFA.Entities)
                {
                    _tracer.Trace("Functional Area-" + eFA.Id, ToString());
                    return eFA;
                }
                return null;

            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in getFunctionalAreaforDummyProperty Method : " + ex.Message);
                throw;
            }
            //return null;
        }

        
        /// <summary>
        /// Get Company from Contact Record 
        /// </summary>
        /// <param name="_service"></param>
        /// <param name="contact"></param>
        /// <param name="_tracer"></param>
        /// <returns></returns>
        public EntityReference GetCompany(IOrganizationService _service, EntityReference contact, ITracingService _tracer)
        {
            EntityReference company = null;
            QueryExpression queryExpression = new QueryExpression { EntityName = "contact", ColumnSet = new ColumnSet(new string[] { "contactid", "parentcustomerid" }) };
            queryExpression.Criteria.AddCondition("statecode", ConditionOperator.NotEqual, 1);
            queryExpression.Criteria.AddCondition("contactid", ConditionOperator.Equal, contact.Id);
            EntityCollection result = _service.RetrieveMultiple(queryExpression);
            if (result.Entities.Count == 1)
            {
                company = result.Entities[0].Contains("parentcustomerid") ? result.Entities[0].GetAttributeValue<EntityReference>("parentcustomerid") : null;
            }
            return company;
        }

        /// <summary>
        /// Get Conntact by Email Address
        /// </summary>
        /// <param name="_service"></param>
        /// <param name="sender"></param>
        /// <param name="_tracer"></param>
        /// <returns></returns>
        public EntityReference GetContactBySender(IOrganizationService _service, string sender, ITracingService _tracer)
        {
            EntityReference contact = null;
            QueryExpression queryExpression = new QueryExpression { EntityName = "contact", ColumnSet = new ColumnSet(new string[] { "contactid" }) };
            queryExpression.Criteria.AddCondition("statecode", ConditionOperator.NotEqual, 1);
            queryExpression.Criteria.AddCondition("emailaddress1", ConditionOperator.Equal, sender);
            EntityCollection result = _service.RetrieveMultiple(queryExpression);
            if (result.Entities.Count == 1)
            {
                Guid contactId = (Guid)result.Entities[0].Attributes["contactid"];
                contact = new EntityReference("contact", contactId);
            }
            return contact;
        }

        /// <summary>
        /// Get Team record by Attribute Value
        /// </summary>
        /// <param name="_service"></param>
        /// <param name="entityName"></param>
        /// <param name="attributeName"></param>
        /// <param name="attributeValue"></param>
        /// <param name="arrColumns"></param>
        /// <returns></returns>
        public EntityReference GetTeambyAttribute(ref IOrganizationService _service, string entityName, string attributeName, int attributeValue, string[] arrColumns)
        {
            EntityReference entRec = null;
            try
            {
                ConditionExpression condRec = new ConditionExpression(attributeName, ConditionOperator.Equal, attributeValue);
                FilterExpression filtRec = new FilterExpression(LogicalOperator.And);
                filtRec.Conditions.AddRange(condRec);
                QueryExpression queryRec = new QueryExpression(entityName);
                queryRec.Criteria = filtRec;
                queryRec.ColumnSet = new ColumnSet(arrColumns);
                EntityCollection colRec = _service.RetrieveMultiple(queryRec);
                if (colRec != null && colRec.Entities.Count > 0)
                {
                    entRec = colRec.Entities[0].ToEntityReference();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return entRec;
        }

        /// <summary>
        /// Getting contacttitle
        /// </summary>
        /// <param name="title"></param>
        /// <returns></returns>
        public int ContactTitle(string title)
        {


            if (title == "")
                return 12;

            if ("mr" == title.ToLower())
                return 0;
            else if ("mrs" == title.ToLower())
                return 1;
            else if ("ms" == title.ToLower())
                return 2;
            else if ("miss" == title.ToLower())
                return 3;
            else if ("master" == title.ToLower())
                return 4;
            else if ("dr" == title.ToLower())
                return 5;
            else if ("lord" == title.ToLower())
                return 6;
            else if ("lady" == title.ToLower())
                return 7;
            else if ("sir" == title.ToLower())
                return 8;
            else if ("col" == title.ToLower())
                return 9;
            else if ("prof" == title.ToLower())
                return 10;
            else if ("rev" == title.ToLower())
                return 11;
            else
                return 12;



        }
        /// <summary>
        /// getting Reason for contact
        /// </summary>
        /// <param name="reasonforcontact"></param>
        /// <returns></returns>
        public int reasonforcontact(string enquiry)
        {
            if (string.IsNullOrEmpty(enquiry))
                return -1;
            else if ("compliment" == enquiry.ToLower())
                return 2;
            else if (enquiry.ToLower() == "query")
                return 4;
            else if (enquiry.ToLower() == "feedback" || enquiry.ToLower() == "complaint")
                return 3;
            else
                return -1;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="timevisited"></param>
        /// <returns></returns>
        public int timevisited(string timevisited)
        {
            if (timevisited == "")
                return -1;
            else if (timevisited.ToLower() == "breakfast")
                return 130570004;
            else if (timevisited.ToLower() == "lunch")
                return 130570006;
            else if (timevisited.ToLower() == "dinner")
                return 130570003;
            else if (timevisited.ToLower() == "other")
                return 130570005;
            else
                return -1;
        }
        public Guid restaurant(string res, IOrganizationService _service, ITracingService _Tracer)
        {

            if (res == "")
                return Guid.Empty;
            QueryExpression query = new QueryExpression();
            query.EntityName = "whb_property";
            query.Criteria.AddCondition("whb_restauranthousenumberoraclenumber", ConditionOperator.Equal, res);
            EntityCollection property = _service.RetrieveMultiple(query);
            _Tracer.Trace("count" + property.Entities.Count);
            if (property.Entities.Count == 1)
                return property.Entities[0].Id;
            else
                return Guid.Empty;
        }
        /// <summary>
        /// Removing HTML tags from Email Body 
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public string StripHTML(string source)
        {

            string result;

            // Remove HTML Development formatting
            // Replace line breaks with space
            // because browsers inserts space
            result = source.Replace("\r", " ");
            // Replace line breaks with space
            // because browsers inserts space
            result = result.Replace("\n", " ");
            // Remove step-formatting
            result = result.Replace("\t", string.Empty);
            // Remove repeating spaces because browsers ignore them
            result = System.Text.RegularExpressions.Regex.Replace(result,
                                                                  @"( )+", " ");

            // Remove the header (prepare first by clearing attributes)
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"<( )*head([^>])*>", "<head>",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"(<( )*(/)( )*head( )*>)", "</head>",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     "(<head>).*(</head>)", string.Empty,
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);

            // remove all scripts (prepare first by clearing attributes)
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"<( )*script([^>])*>", "<script>",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"(<( )*(/)( )*script( )*>)", "</script>",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            //result = System.Text.RegularExpressions.Regex.Replace(result,
            //         @"(<script>)([^(<script>\.</script>)])*(</script>)",
            //         string.Empty,
            //         System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"(<script>).*(</script>)", string.Empty,
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);

            // remove all styles (prepare first by clearing attributes)
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"<( )*style([^>])*>", "<style>",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"(<( )*(/)( )*style( )*>)", "</style>",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     "(<style>).*(</style>)", string.Empty,
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);

            // insert tabs in spaces of <td> tags
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"<( )*td([^>])*>", "\t",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);

            // insert line breaks in places of <BR> and <LI> tags
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"<( )*br( )*>", "\r",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"<( )*li( )*>", "\r",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);

            // insert line paragraphs (double line breaks) in place
            // if <P>, <DIV> and <TR> tags
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"<( )*div([^>])*>", "\r\r",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"<( )*tr([^>])*>", "\r\r",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"<( )*p([^>])*>", "\r\r",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);

            // Remove remaining tags like <a>, links, images,
            // comments etc - anything that's enclosed inside < >
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"<[^>]*>", string.Empty,
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);

            // replace special characters:
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @" ", " ",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);

            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"&bull;", " * ",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);

            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"&lsaquo;", "<",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"&rsaquo;", ">",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"&trade;", "(tm)",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"&frasl;", "/",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"&lt;", "<",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"&gt;", ">",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"&copy;", "(c)",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"&reg;", "(r)",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"&amp;", "&",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            // Remove all others. More can be added, see
            // http://hotwired.lycos.com/webmonkey/reference/special_characters/
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     @"&(.{2,6});", string.Empty,
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);

            // for testing
            //System.Text.RegularExpressions.Regex.Replace(result,
            //       this.txtRegex.Text,string.Empty,
            //       System.Text.RegularExpressions.RegexOptions.IgnoreCase);

            // make line breaking consistent
            result = result.Replace("\n", "\r");

            // Remove extra line breaks and tabs:
            // replace over 2 breaks with 2 and over 4 tabs with 4.
            // Prepare first to remove any whitespaces in between
            // the escaped characters and remove redundant tabs in between line breaks
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     "(\r)( )+(\r)", "\r\r",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     "(\t)( )+(\t)", "\t\t",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     "(\t)( )+(\r)", "\t\r",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     "(\r)( )+(\t)", "\r\t",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            // Remove redundant tabs
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     "(\r)(\t)+(\r)", "\r\r",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            // Remove multiple tabs following a line break with just one tab
            result = System.Text.RegularExpressions.Regex.Replace(result,
                     "(\r)(\t)+", "\r\t",
                     System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            // Initial replacement target string for line breaks
            string breaks = "\r\r\r";
            // Initial replacement target string for tabs
            string tabs = "\t\t\t\t\t";
            for (int index = 0; index < result.Length; index++)
            {
                result = result.Replace(breaks, "\r\r");
                result = result.Replace(tabs, "\t\t\t\t");
                breaks = breaks + "\r";
                tabs = tabs + "\t";
            }

            // That's it.
            return result;
        }


        public void CaseAssignment(IOrganizationService _service, Guid userId, ITracingService _tracer)
        {
            try
            {
                int count = GetActiveCases(_service, userId);
                _tracer.Trace("Active cases availale with user {0}", count);
                if (count < 1)
                {
                    EntityReference targetCase = GetTargetCase(_service, userId, _tracer);
                    if (targetCase != null)
                    {
                        _tracer.Trace("Active cases reference {0}", targetCase.Id);
                        EntityReference assignee = new EntityReference("systemuser", userId);
                        if (targetCase != null && assignee != null)
                        {
                            Assignment(_service, targetCase, assignee);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("An error occured, please contact your system administrator. " + ex.Message);
            }
        }

        public int GetActiveCases(IOrganizationService _service, Guid userId)
        {
            string reasons = string.Empty;
            List<string> split = new List<string>();
            QueryExpression queryExpression = new QueryExpression { EntityName = "whb_customizations", ColumnSet = new ColumnSet(new string[] { "whb_casestatusreason" }) };
            queryExpression.Criteria.AddCondition("whb_name", ConditionOperator.Equal, "Case Status Reason");
            EntityCollection result = _service.RetrieveMultiple(queryExpression);
            if (result.Entities.Count == 1)
            {
                reasons = result.Entities[0].Contains("whb_casestatusreason") ? result.Entities[0].GetAttributeValue<string>("whb_casestatusreason") : string.Empty;
                if (reasons != string.Empty)
                {
                    split = reasons.Split(',').ToList();

                }
            }

            string query = string.Empty;

            foreach (var item in split)
            {
                query = query + string.Format("<condition attribute = 'statuscode' operator= 'eq' value =" + "'{0}'/>", item);
            }


            var fetchXML1 = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='incident'>
                                <attribute name='incidentid' />
                                <attribute name='ticketnumber' />
                                <order attribute='title' descending='false' />
                                <filter type='and'>
                                  <filter type='and'>
                                    <condition attribute='statecode' operator='eq' value='0' />
                                    <filter type='or'>" + query + @"</filter>
                                    <condition attribute='ownerid' operator='eq' value='" + userId.ToString() + "' />" + @"
                                  </filter>
                                </filter>
                              </entity>
                            </fetch>";
            //  var fetchXML = fetchXML1 + query + fetchXML2;

            return _service.RetrieveMultiple(new FetchExpression(fetchXML1)).Entities.Count();
        }

        public EntityReference GetTargetCase(IOrganizationService _service, Guid userId, ITracingService trace)
        {
            EntityReference targetRecord = null;
            var fetchXML = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                              <entity name='incident'>
                                <attribute name='title' />
                                <attribute name='createdon' />
                                <attribute name='incidentid' />
                                <attribute name='caseorigincode' />
                                <attribute name='whb_priority' />
                                <order attribute='whb_priority' descending='false' />
                                <order attribute='createdon' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                </filter>
                                <link-entity name='team' from='teamid' to='owningteam' link-type='inner' alias='ae'>
                                  <filter type='and'>
                                    <condition attribute='whb_isautoassignmentapplicable' operator='eq' value='1' />
                                  </filter>
                                  <link-entity name='teammembership' from='teamid' to='teamid' visible='false' intersect='true'>
                                    <link-entity name='systemuser' from='systemuserid' to='systemuserid' alias='af'>
                                      <filter type='and'>
                                        <condition attribute='systemuserid' operator='eq' value='" + userId.ToString() + "' />" + @"
                                      </filter>
                                    </link-entity>
                                  </link-entity>
                                </link-entity>
                              </entity>
                            </fetch>";
            EntityCollection result = _service.RetrieveMultiple(new FetchExpression(fetchXML));
            trace.Trace("Reterived Team Owned Records & Record Countis{0}", result.Entities.Count);
            if (result.Entities.Count > 0)
            {

                Guid Id = result.Entities[0].Attributes.Contains("incidentid") ? result.Entities[0].GetAttributeValue<Guid>("incidentid") : Guid.Empty;
                targetRecord = new EntityReference("incident", Id);
            }

            return targetRecord;
        }

        public void Assignment(IOrganizationService _service, EntityReference targetCase, EntityReference assignee)
        {
            if (targetCase != null && assignee != null)
            {
                Entity incident = new Entity("incident");
                incident.Id = targetCase.Id;
                incident["ownerid"] = assignee;
                _service.Update(incident);
            }

        }

        public Boolean IsAutoApprovalAvailable(IOrganizationService _service, Guid Id, ITracingService _tracer)
        {
            Boolean IsAvailable = false;
            QueryExpression queryExpression = new QueryExpression { EntityName = "team", ColumnSet = new ColumnSet(new string[] { "teamid", "whb_isautoassignmentapplicable" }) };
            queryExpression.Criteria.AddCondition("teamid", ConditionOperator.Equal, Id);
            EntityCollection result = _service.RetrieveMultiple(queryExpression);
            if (result.Entities.Count == 1)
            {
                IsAvailable = result.Entities[0].Contains("whb_isautoassignmentapplicable") ? result.Entities[0].GetAttributeValue<Boolean>("whb_isautoassignmentapplicable") : false;
            }
            return IsAvailable;
        }
                
    }
}
