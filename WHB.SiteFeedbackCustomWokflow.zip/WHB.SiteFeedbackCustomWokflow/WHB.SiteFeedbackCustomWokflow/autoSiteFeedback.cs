﻿//-----------------------------------------------------------------------
// <copyright file="autoSiteFeedback.cs" company="Company">
// Copyright (c) Company. All rights reserved.
// </copyright>
// <author>Ranjith</author>
//-----------------------------------------------------------------------

using System;
using System.Activities;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Query;

namespace WHB.SiteFeedbackCustomWokflow
{
    public sealed class autoSiteFeedback : CodeActivity
    {

        /// <summary>
        /// Input Argument for getting the informations
        /// </summary> 

        [RequiredArgument]
        [Input("Operation Manager")]
        [ReferenceTarget("whb_propertymanager")]
        public InArgument<EntityReference> operationmanager
        {
            get;
            set;
        }

        [RequiredArgument]
        [Input("from")]
        [ReferenceTarget("queue")]
        public InArgument<EntityReference> queue
        {
            get;
            set;
        }

        [RequiredArgument]
        [Input("Source")]
        [ReferenceTarget("incident")]

        public InArgument<string> sourceCode
        {
            get;
            set;
        }


        [RequiredArgument]
        [Input("Property")]
        [ReferenceTarget("whb_property")]
        public InArgument<EntityReference> Property
        {
            get;
            set;
        }

        /// <summary>
        /// Method for sending the Email to Operaion Manager 
        /// </summary>
        /// <param name="executionContext"> </param>
        protected override void Execute(CodeActivityContext executionContext)
        {
            try
            {                              
                IExecutionContext context = executionContext.GetExtension<IExecutionContext>();
                IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                ITracingService tracer = executionContext.GetExtension<ITracingService>();
                string source = sourceCode.Get(executionContext);
                EntityReference property = Property.Get(executionContext);
                EntityReference from = queue.Get(executionContext);
                EntityReference opmgrmail = operationmanager.Get(executionContext);
                Entity entity = (Entity)context.InputParameters["Target"];
                tracer.Trace("Source : " + source);
                tracer.Trace("Hotel : " + property.Id);

                EntityReference brandID = null;
                string sourceId = string.Empty;

                if (property != null && property.Id != Guid.Empty )
                {
                    //brandId = property.KeyAttributes.Contains("whb_brandid") ? property.KeyAttributes.<EntityReference>("whb_sitefeedbacktemplate") :null;

                    brandID = GetPropertyBrandId(property, tracer, service);
                    tracer.Trace("brand Id : " + brandID.Id);
                }

                if (source != string.Empty && source != null)
                {
                    sourceId = GetSourceId(source, tracer, service);
                    tracer.Trace("Source Id : " + sourceId);
                }

                //if (brandId != null && brandId != string.Empty)
                //{
                Guid BrandID = brandID.Id;
                Guid SourceID = new Guid(sourceId);
                tracer.Trace("brandid-" + BrandID);
                //Getting the Template from the Combianation Entity
                Guid templateid = GetCombinationrecord(SourceID, BrandID, service, tracer);
                tracer.Trace("templateid-" + templateid.ToString());
                if (templateid == null || templateid == Guid.Empty)
                {
                    return;
                }
                Entity party1 = new Entity("activityparty");
                party1["partyid"] = new EntityReference(opmgrmail.LogicalName, opmgrmail.Id);
                Entity party2 = new Entity("activityparty");
                party2["partyid"] = new EntityReference(from.LogicalName, from.Id);
                //Creating the email message
                Entity email = new Entity("email");
                email["to"] = new Entity[] { party1 };
                email["from"] = new Entity[] { party2 };
                email["directioncode"] = true;
                email["whb_isautoreply"] = true;
                tracer.Trace("caseid-" + entity.Id.ToString());
                //to send email using the Email Template
                var emailUsingTemplateReq = new SendEmailFromTemplateRequest
                {
                    TemplateId = templateid,
                    Target = email,
                    RegardingId = entity.Id,
                    RegardingType = entity.LogicalName

                };
                SendEmailFromTemplateResponse emailUsingTemplateResp = (SendEmailFromTemplateResponse)service.Execute(emailUsingTemplateReq);

               // }
                
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("Error Occured in Auto Site Feedback" + ex.Message);
            }
        }
        /// <summary>
        /// To get the source 
        /// </summary>
        /// <param name="source"></param>
        /// <param name="tracer"></param>
        /// <param name="service"></param>
        /// <returns></returns>
        public string GetSourceId(string source, ITracingService tracer, IOrganizationService service)
        {
            try
            {
                tracer.Trace("Start -- GetSourceId Method.");
                QueryExpression queryExpression = new QueryExpression { EntityName = "whb_source", ColumnSet = new ColumnSet(new string[] { "whb_name" }) };
                queryExpression.Criteria.AddCondition("whb_name", ConditionOperator.Equal, source);
                EntityCollection property = service.RetrieveMultiple(queryExpression);

                foreach (Entity item in property.Entities)
                {
                    tracer.Trace("Source Id : " + item.Id.ToString());
                    return item.Id.ToString();
                }
            }
            catch (Exception ex)
            {
                tracer.Trace("Exception in GetSourceId Method : " + ex.Message);
                throw;
            }

            return "";
        }
        /// <summary>
        /// To get the Brand using Hotel name
        /// </summary>
        /// <param name="hotel"></param>
        /// <param name="tracer"></param>
        /// <param name="service"></param>
        /// <returns></returns>
        public EntityReference GetPropertyBrandId(EntityReference property, ITracingService tracer, IOrganizationService service)
        {
            try
            {
                Entity prop = service.Retrieve(property.LogicalName, property.Id, new ColumnSet("whb_brandid"));

                EntityReference Brandid = prop.Contains("whb_brandid") ? prop.GetAttributeValue<EntityReference>("whb_brandid") : null;

                return Brandid;
                //tracer.Trace("Start GetPropertyBrandId Method");
                //QueryExpression queryExpression = new QueryExpression { EntityName = "whb_property", ColumnSet = new ColumnSet(new string[] { "whb_brandid" }) };
                //queryExpression.Criteria.AddCondition("whb_propertycode", ConditionOperator.Equal, hotel);
                //EntityCollection property = service.RetrieveMultiple(queryExpression);

                //foreach (Entity item in property.Entities)
                //{
                //    tracer.Trace("Property Brand Id : " + ((EntityReference)(item.Attributes["whb_brandid"])).Id.ToString());
                //    return ((EntityReference)(item.Attributes["whb_brandid"])).Id.ToString();
                //}
            }
            catch (Exception ex)
            {
                tracer.Trace("Exception in GetPropertyBrandId Method : " + ex.Message);
                throw;
            }
            
        }

        /// <summary>
        /// Getting the Name of the Email Template from the Combination Entity
        /// </summary>
        /// <param name="source"></param>
        /// <param name="BrandID"></param>
        /// <param name="service"></param>
        /// <param name="tracer"></param>
        /// <returns></returns>
        private Guid GetCombinationrecord(Guid SourceID, Guid BrandID, IOrganizationService service, ITracingService tracer)
        {
            try
            {
                tracer.Trace("sourceid-" + SourceID);
                Guid templateid = Guid.Empty;
                QueryExpression query = new QueryExpression();
                query.EntityName = "whb_caseassignment";
                query.ColumnSet = new ColumnSet("whb_sourceid", "whb_sitefeedbacktemplate", "whb_brandid");
                //query.Criteria.AddCondition("whb_sourceid", ConditionOperator.Equal, SourceID.ToString());
                //query.Criteria.AddCondition("whb_brandid", ConditionOperator.Equal, BrandID.ToString());

                if (BrandID != Guid.Empty)
                    query.Criteria.AddCondition("whb_brandid", ConditionOperator.Equal, BrandID);
                else
                    query.Criteria.AddCondition("whb_brandid", ConditionOperator.Null);

                if (SourceID != Guid.Empty)
                    query.Criteria.AddCondition("whb_sourceid", ConditionOperator.Equal, SourceID);
                else
                    query.Criteria.AddCondition("whb_sourceid", ConditionOperator.Null);

                EntityCollection combinationrecord = service.RetrieveMultiple(query);
                if (combinationrecord.Entities.Count > 0)
                {
                    string siteFeedbackTemplate = combinationrecord.Entities[0].Contains("whb_sitefeedbacktemplate") ? combinationrecord.Entities[0].GetAttributeValue<string>("whb_sitefeedbacktemplate") : string.Empty;
                    if (siteFeedbackTemplate != string.Empty)
                    {
                        templateid = new Guid(siteFeedbackTemplate);
                    }
                }
                return templateid;

            }
            catch { throw; }
        }
    }
}
