﻿using Microsoft.Xrm.Sdk;
using System;

/// <summary>
/// This class/plugin is used to associate DPA and Case record when a case is created from DPA Form
/// </summary>
public class CaseDpaAssociation : IPlugin
{
    public void Execute(IServiceProvider serviceProvider)
    {
        IPluginExecutionContext Context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
        IOrganizationServiceFactory organizationServiceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
        IOrganizationService organizationService = organizationServiceFactory.CreateOrganizationService(Context.UserId);
        ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

        if (Context.InputParameters.Contains("Target") && Context.InputParameters["Target"] is Entity)
        {
            try
            {
                Entity entity = (Entity)Context.InputParameters["Target"];

                if (Context.MessageName == "Create" && entity.LogicalName == "incident")
                {
                    if (entity.Attributes.Contains("whb_dparecordguid"))
                    {
                        Guid dpaGuid = new Guid(entity.Attributes["whb_dparecordguid"].ToString());
                        if (dpaGuid != Guid.Empty && dpaGuid != null)
                        {
                            Guid caseId = entity.Id;
                            Entity dpa = new Entity("whb_dpacheck");
                            dpa.Id = dpaGuid;
                            dpa["whb_case"] = new EntityReference(entity.LogicalName, caseId);
                            organizationService.Update(dpa);

                            //The below code is done to set DPA check flag in Case
                            entity["whb_dpacheckdone"] = true;
                            organizationService.Update(entity);

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}