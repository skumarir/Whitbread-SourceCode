﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Diagnostics;
namespace DataErasure
{
    class Helper
    {
        /// <summary>
        /// This method will delete the contact if no cases are associated with it
        /// </summary>
        /// <param name="service">CRM Service Parameter</param>
        /// <param name="contactId">Contact GUID</param>
        /// <param name="tracingService">tracing Service</param>
        public void ContactDeletion(IOrganizationService service, Guid contactId, ITracingService tracingService)
        {
            QueryExpression query = new QueryExpression("incident");
            query.Criteria.AddCondition("whb_contact", ConditionOperator.Equal, contactId);
            EntityCollection incidents = service.RetrieveMultiple(query);
            if (incidents.Entities.Count == 0)
            {
                tracingService.Trace("No Cases associated with this contact");
                service.Delete("contact", contactId);
                tracingService.Trace("Contact Deleted successfully");
            }
        }

        /// <summary>
        /// This method calls multiple sub methods which helps in Reactivating the case, Erasing the Customer Data, Deleting All case related activities except Case Closure, Updating Case fields and VOC data. Finally close the case back
        /// </summary>
        /// <param name="service">CRM Service Parameter</param>
        /// <param name="stateCode">Case State Code</param>
        /// <param name="statusCode">Case Status Code</param>
        /// <param name="caseId">Case GUID</param>
        public void CallMultipleMethods(IOrganizationService service, int stateCode, int statusCode, Guid caseId,  ITracingService tracingService)
        {
            tracingService.Trace("Before Reactivating");
            ReactivatorCloseCase(service, 0, 1, caseId); //open the case so that we can update the case customer details to data erasure
            tracingService.Trace("Reactivation Successful");
            EraseContactDataInCase(service, caseId,tracingService); // Erase the customer data in case entity
            tracingService.Trace("Erasure Successful");
            closeCase(service, caseId);
            tracingService.Trace("Closure Successful");
        }

        /// <summary>
        /// This method is used to Reactivate the closed case 
        /// </summary>
        /// <param name="service">CRM Service Parameter</param>
        /// <param name="stateCode">Case State Code</param>
        /// <param name="statusCode">Case Status Code</param>
        /// <param name="caseId">Case GUID</param>
        public void ReactivatorCloseCase(IOrganizationService service, int stateCode, int statusCode, Guid caseId)
        {
            SetStateRequest state = new SetStateRequest();
            // Set the Request Object's Properties
            state.State = new OptionSetValue(stateCode);
            state.Status = new OptionSetValue(statusCode);
            // Point the Request to the case whose state is being changed
            state.EntityMoniker = new EntityReference("incident", caseId);
            // Execute the Request
            SetStateResponse stateSet = (SetStateResponse)service.Execute(state);
        }

        /// <summary>
        /// This method is used to Erase Customer Details
        /// </summary>
        /// <param name="service">CRM Service Parameter</param>
        /// <param name="caseId">Case GUID</param>
        public void EraseContactDataInCase(IOrganizationService service, Guid caseId, ITracingService tracingService)
        {
            Entity incident = new Entity();
            // Service, lookupentityname,lookup record name,primary field of lookup entity
            incident["whb_guestname"] = GetReferenceforEntity(service, "whb_stays", "GDPR Erasure", "whb_name");
            incident["whb_contact"] = GetReferenceforEntity(service, "contact", "GDPR Erasure", "fullname");
            incident["customerid"] = GetReferenceforEntity(service, "contact", "GDPR Erasure", "fullname");
            incident["whb_wffirstname"] = "GDPR Erasure";
            incident["whb_wflastname"] = "GDPR Erasure";
            incident["whb_wfpostcode"] = "GDPR Erasure";
            incident["whb_wfemailaddress"] = "GDPR Erasure";
            incident["whb_wfcontactnumber"] = "GDPR Erasure";
            incident["whb_summary"] = "GDPR Erasure";
            incident["title"] = "GDPR Erasure";
            incident.Id = caseId;
            incident.LogicalName = "incident";
            service.Update(incident);

            tracingService.Trace("Case Erasure Successful");

            string gsFieldName = getdataRetentionperiod(service);
            string gsEntityName = getGRSurveyEntityName(service);
            string gsCaseIdName = getGRSurveyCaseSchemaName(service);

            if (!string.IsNullOrEmpty(gsFieldName) && !string.IsNullOrEmpty(gsEntityName) && !string.IsNullOrEmpty(gsCaseIdName))
            {
                EntityCollection vocDetails = GetVocDetails(service, gsEntityName, caseId, gsCaseIdName, gsFieldName);
                foreach (Entity caseVoc in vocDetails.Entities)
                {
                    if(caseVoc.Attributes.Contains(gsFieldName) && !string.IsNullOrEmpty(caseVoc.Attributes[gsFieldName].ToString()))
                    //if (!string.IsNullOrEmpty(caseVoc.Attributes[gsFieldName].ToString()))
                    {
                        Entity voc = new Entity();
                        voc[gsFieldName] = "GDPR Erasure";
                        voc.Id = caseVoc.Id;
                        voc.LogicalName = caseVoc.LogicalName;
                        service.Update(voc);
                    }
                }

                tracingService.Trace("Guest Relation satisfactory Survey Erasure Successful");
            }


            EntityCollection surveyResponseDetails = GetSurveyResponseDetails(service, "msdyn_surveyresponse", caseId, "msdyn_case");
            foreach (Entity surveyItem in surveyResponseDetails.Entities)
            {
                EntityCollection questionResponseDetails = GetQuestionResponseDetails(service, "msdyn_questionresponse", surveyItem.Id, "msdyn_surveyresponseid", "msdyn_questionid");
                foreach (Entity questionItem in questionResponseDetails.Entities)
                {
                    if(questionItem.Attributes.Contains("msdyn_valueasstring") && !string.IsNullOrEmpty(questionItem.Attributes["msdyn_valueasstring"].ToString()))
                    //if (!string.IsNullOrEmpty(questionItem.Attributes["msdyn_valueasstring"].ToString()))
                    {
                        Entity questionResponse = new Entity();
                        questionResponse["msdyn_valueasstring"] = "GDPR Erasure";
                        questionResponse.Id = questionItem.Id;
                        questionResponse.LogicalName = questionItem.LogicalName;
                        service.Update(questionResponse);
                    }
                }
                tracingService.Trace("VOC Erasure Successful");
            }



            if (caseId != null && caseId != Guid.Empty)
            {
                deleteAllCaseActivities(service, caseId, tracingService); // deleting all activities 
                tracingService.Trace("Activities Erasure Successful");
            }
        }

        /// <summary>
        /// This method is used to close the opened case
        /// </summary>
        /// <param name="service">CRM Service Parameter</param>
        /// <param name="caseId">Case GUID</param>
        public void closeCase(IOrganizationService service, Guid caseId)
        {
            Entity caseResolution = new Entity("incidentresolution");
            caseResolution["incidentid"] = new EntityReference("incident", caseId);
            caseResolution["subject"] = "Case Resolved";
            CloseIncidentRequest close = new CloseIncidentRequest();
            close.IncidentResolution = caseResolution;
            close.RequestName = "CloseIncident";
            close.Status = new OptionSetValue(5);
            CloseIncidentResponse closeCase = (CloseIncidentResponse)service.Execute(close);
        }

        /// <summary>
        /// This is a generalized method that returns entity collection based on schema and entity name that we pass
        /// </summary>
        /// <param name="service">CRM Service Parameter</param>
        /// <param name="entityname">Name of the Entity </param>
        /// <param name="recordName">Record name or the Filter that is used</param>
        /// <param name="fieldSchema">Name of the field which your are using filter</param>
        /// <returns>Returns an entity collection</returns>
        public EntityReference GetReferenceforEntity(IOrganizationService service, string entityname, string recordName, string fieldSchema)
        {
            QueryExpression query = new QueryExpression();
            query.EntityName = entityname;
            query.Criteria.AddCondition(fieldSchema, ConditionOperator.Equal, recordName);
            EntityCollection records = service.RetrieveMultiple(query);
            EntityReference reference = records.Entities[0].ToEntityReference();
            return reference;
        }

        /// <summary>
        /// This is method returns entity collection related to VOC based on schema and entity name that we pass
        /// </summary>
        /// <param name="service">CRM Service Parameter</param>
        /// <param name="entityname">Name of the Entity </param>
        /// <param name="recordName">Record name or the Filter that is used</param>
        /// <param name="fieldSchema">Name of the field which your are using filter</param>
        /// <returns>returns the entity collection w.r.t VOC</returns>
        public EntityCollection GetVocDetails(IOrganizationService service, string entityname, Guid recordName, string fieldSchema, string fieldToRetrive)
        {
            QueryExpression query = new QueryExpression();
            query.EntityName = entityname;
            query.ColumnSet = new ColumnSet(fieldToRetrive);
            query.Criteria.AddCondition(fieldSchema, ConditionOperator.Equal, recordName);
            EntityCollection records = service.RetrieveMultiple(query);
            return records;
        }

        /// <summary>
        /// This method is used to get the Survey Response details related to case, we update the other field to GDPR Erasure
        /// </summary>
        /// <param name="service">CRM Service Parameter</param>
        /// <param name="entityname">Name of the Entity </param>
        /// <param name="recordName">Record name or the Filter that is used</param>
        /// <param name="fieldSchema">Name of the field which your are using filter</param>
        /// <returns>returns the entity collection w.r.t Survey</returns>
        public EntityCollection GetSurveyResponseDetails(IOrganizationService service, string entityname, Guid recordName, string fieldSchema)
        {
            QueryExpression query = new QueryExpression();
            query.EntityName = entityname;
            //query.ColumnSet = new ColumnSet("msdyn_valueasstring");
            query.Criteria.AddCondition(fieldSchema, ConditionOperator.Equal, recordName);
            EntityCollection records = service.RetrieveMultiple(query);
            return records;
        }

        /// <summary>
        /// This method is used to get the Question Response details related to case, we update the other field to GDPR Erasure
        /// </summary>
        /// <param name="service">CRM Service Parameter</param>
        /// <param name="entityname">Name of the Entity </param>
        /// <param name="recordName1">Record name or the Filter that is used</param>
        /// <param name="fieldSchema1">Name of the field which your are using filter</param>
        /// <param name="fieldSchema2">Name of the field which your are using filter</param>
        /// <returns>returns the entity collection w.r.t Questions</returns>
        public EntityCollection GetQuestionResponseDetails(IOrganizationService service, string entityname, Guid recordName1, string fieldSchema1, string fieldSchema2)
        {
            EntityCollection records = new EntityCollection();
            EntityCollection ec = GetOtherRecordGuid(service);
            foreach (Entity question in ec.Entities)
            {
                QueryExpression query = new QueryExpression();
                query.EntityName = entityname;
                query.ColumnSet = new ColumnSet("msdyn_valueasstring");
                query.Criteria.AddCondition(fieldSchema1, ConditionOperator.Equal, recordName1);
                query.Criteria.AddCondition(fieldSchema2, ConditionOperator.Equal, question.Id); // need to get the guid of other and replace herer
                records = service.RetrieveMultiple(query);
            }
            return records;
        }

        /// <summary>
        /// This method is used to get the GUID of record names 'other' from question entity 
        /// </summary>
        /// <param name="service">CRM Service Parameter</param>
        /// <returns>returns the entity collection w.r.t Questions</returns>
        public EntityCollection GetOtherRecordGuid(IOrganizationService service)
        {
            QueryExpression query = new QueryExpression();
            query.EntityName = "msdyn_question";
            query.Criteria.AddCondition("msdyn_name", ConditionOperator.Equal, "other");
            EntityCollection ec = service.RetrieveMultiple(query);
            return ec;
        }

        /// <summary>
        /// This method deletes all activities related to case except case resolved
        /// </summary>
        /// <param name="service">CRM Service Parameter</param>
        /// <param name="caseId">Case GUID</param>
        public int deleteAllCaseActivities(IOrganizationService service, Guid caseId, ITracingService tracingService)
        {
            int deletedActivitiesCounter = 0;

            string getAllActivitesExceptCaseResolved = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='activitypointer'>
                                                            <attribute name='activitytypecode' />
                                                            <attribute name='subject' />
                                                            <attribute name='statecode' />
                                                            <attribute name='prioritycode' />
                                                            <attribute name='modifiedon' />
                                                            <attribute name='activityid' />
                                                            <attribute name='instancetypecode' />
                                                            <attribute name='community' />
                                                            <order attribute='modifiedon' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='regardingobjectid' operator='eq' uiname='sasac' uitype='incident' value='{" + caseId + @"}' />
                                                              <filter type='or'>
                                                                <condition attribute='activitytypecode' operator='ne' value='4206' />
                                                                <condition attribute='statecode' operator='ne' value='1' />
                                                              </filter>
                                                            </filter>
                                                          </entity>
                                                        </fetch>";


            tracingService.Trace("Before trace - " + service.ToString());
            var response = service.RetrieveMultiple(new FetchExpression(getAllActivitesExceptCaseResolved));
            tracingService.Trace("after trace"+ response.Entities.ToString());
            try
            {
                foreach (var entity in response.Entities)
                {
                    tracingService.Trace("Inside foreach");
                    service.Delete(entity["activitytypecode"].ToString(), entity.Id);
                    tracingService.Trace("activity deleted mind you foreach");
                    deletedActivitiesCounter++;
                }
            }
            catch (Exception ex)
            {
                // Get stack trace for the exception with source file information
                var st = new StackTrace(ex, true);
                // Get the top stack frame
                var frame = st.GetFrame(0);
                // Get the line number from the stack frame
                var line = frame.GetFileLineNumber();
                throw new InvalidPluginExecutionException("Function : getAllActivities()" + " -- Error Line number: " + line + " Erase Case data : " + ex.Message);
            }
            return deletedActivitiesCounter;
        }

        /// <summary>
        /// This Method is used to retrive the datat Retention period from Customizations entity
        /// </summary>
        /// <param name="service">CRM Service Parameter</param>
        /// <returns>returns an integer value</returns>
        public string getdataRetentionperiod(IOrganizationService service)
        {
            string retentionString = "Data Retention Period";
            int dataRetentionPeriod = 0;
            string grSurveyName = string.Empty;
            retentionString = retentionString.ToLower();
            QueryExpression query = new QueryExpression();
            query.EntityName = "whb_customizations";
            query.ColumnSet = new ColumnSet("whb_dataretentionperiod", "whb_grsatisfactoryotherfieldname");
            query.Criteria.AddCondition("whb_name", ConditionOperator.Equal, retentionString);
            EntityCollection ec = service.RetrieveMultiple(query);
            if (ec != null && ec.Entities.Count > 0)
            {
                dataRetentionPeriod = Convert.ToInt32(ec[0].Attributes["whb_dataretentionperiod"]);
                grSurveyName = ec[0].Attributes["whb_grsatisfactoryotherfieldname"].ToString();
            }
            return grSurveyName;
        }

        public string getGRSurveyEntityName(IOrganizationService service)
        {
            string retentionString = "Data Retention Period";
            retentionString = retentionString.ToLower();
            string gsEntityName = string.Empty;
            QueryExpression query = new QueryExpression();
            query.EntityName = "whb_customizations";
            query.ColumnSet = new ColumnSet("whb_guestrelationsatisfactorysurveyname");
            query.Criteria.AddCondition("whb_name", ConditionOperator.Equal, retentionString);
            EntityCollection ec = service.RetrieveMultiple(query);
            if (ec != null && ec.Entities.Count > 0)
            {
                gsEntityName = ec[0].Attributes["whb_guestrelationsatisfactorysurveyname"].ToString();
            }
            return gsEntityName;
        }

        public string getGRSurveyCaseSchemaName(IOrganizationService service)
        {
            string retentionString = "Data Retention Period";
            retentionString = retentionString.ToLower();
            string gsCaseIdSchemaName = string.Empty;
            QueryExpression query = new QueryExpression();
            query.EntityName = "whb_customizations";
            query.ColumnSet = new ColumnSet("whb_gssurveycaseidschemaname");
            query.Criteria.AddCondition("whb_name", ConditionOperator.Equal, retentionString);
            EntityCollection ec = service.RetrieveMultiple(query);
            if (ec != null && ec.Entities.Count > 0)
            {
                gsCaseIdSchemaName = ec[0].Attributes["whb_gssurveycaseidschemaname"].ToString();
            }
            return gsCaseIdSchemaName;
        }

        public void createScheduledRetentionrecordForFutureDeletion(IOrganizationService service, Guid caseId, Guid contactId, string casenumber,DateTime caseClosedDate, ITracingService tracingService)
        {
            try
            {
                Entity scheduledErasure = new Entity("whb_scheduledcaseerasure");
                scheduledErasure["name"] = casenumber;
                scheduledErasure["whb_caseid"] = caseId;
                scheduledErasure["whb_contactid"] = contactId;
                scheduledErasure["whb_scheduleddateoferasure"] = caseClosedDate;
                var erasureId = service.Create(scheduledErasure);
                tracingService.Trace("Scheduling Record Created Successfully   ****************  " + erasureId);
            }
            catch(Exception ex)
            {
                // Get stack trace for the exception with source file information
                var st = new StackTrace(ex, true);
                // Get the top stack frame
                var frame = st.GetFrame(0);
                // Get the line number from the stack frame
                var line = frame.GetFileLineNumber();
                throw new InvalidPluginExecutionException("Function : createScheduledRetentionrecordForFutureDeletion()" + " -- Error Line number: " + line + " Erase Case data : " + ex.Message);
            }
        }

        public DateTime AddMonthstoCaseClosure(DateTime dt,int retentionMonths)
        {
            dt = dt.AddMonths(retentionMonths);
            return dt;
        }

        public void updateCaseErasureFlag(IOrganizationService service, Guid caseId)
        {
            Entity incident = new Entity();
            incident["whb_enablefordataerasure"] = true;
            incident.Id = caseId;
            incident.LogicalName = "incident";
            service.Update(incident);
        }
    }
}
