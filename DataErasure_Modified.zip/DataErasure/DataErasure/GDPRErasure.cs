﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Diagnostics;

namespace DataErasure
{
    //// Action will Be Triggered on Click of Data Erasure Button
    public class GDPRErasure : IPlugin
    {
        /// <summary>
        /// Action for Data Erasure the Contact
        /// </summary>
        /// <param name="serviceProvider"></param>
        
       
        public int deletedActivitiesCounter = 0;

        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory organizationServiceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = organizationServiceFactory.CreateOrganizationService(new Guid?(context.UserId));
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            try
            {
                Helper _helper = new Helper();
                tracingService.Trace("Before If Condition");
                if (context.MessageName == "whb_CaseDataErasureProcess" && context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference)
                {
                    EntityCollection target = (EntityCollection)context.InputParameters["caseObj"];

                    if (target != null)
                    {
                        tracingService.Trace("Inside if");
                        //int dataRetentionPeriod = _helper.getdataRetentionperiod(service); // keep this outside the loop sinse it is called only once 

                        foreach (Entity entity in target.Entities)
                        {
                            tracingService.Trace("Inside for each");

                            DateTime currentDateTime = DateTime.UtcNow;
                            Guid contactId = Guid.Empty;
                            string caseNumber = string.Empty;
                            Guid resolutionCodeId = Guid.Empty;
                            tracingService.Trace(entity.Id.ToString()); 
                            Entity incident = service.Retrieve("incident", entity.Id, new ColumnSet("whb_contact", "ticketnumber", "whb_resolutioncode_fp"));
                            tracingService.Trace(incident.ToString());
                            if (incident != null)
                            {
                                contactId = incident.GetAttributeValue<EntityReference>("whb_contact").Id;
                                tracingService.Trace(contactId.ToString());
                                caseNumber = incident.GetAttributeValue<string>("ticketnumber").ToString();
                                tracingService.Trace(caseNumber.ToString());
                                resolutionCodeId = incident.GetAttributeValue<EntityReference>("whb_resolutioncode_fp").Id;
                                tracingService.Trace(contactId.ToString());
                                tracingService.Trace(resolutionCodeId.ToString());
                            }

                            int stateCode = entity.Attributes.Contains("statecode") ? entity.GetAttributeValue<OptionSetValue>("statecode").Value : -1;
                            tracingService.Trace(stateCode.ToString());

                            int statusCode = entity.Attributes.Contains("statuscode") ? entity.GetAttributeValue<OptionSetValue>("statuscode").Value : -1;
                            tracingService.Trace(statusCode.ToString());
                            DateTime caseClosedDate = entity.Attributes.Contains("whb_closeddatetime") ? entity.GetAttributeValue<DateTime>("whb_closeddatetime") : DateTime.MinValue;
                            tracingService.Trace(caseClosedDate.ToString());

                            tracingService.Trace(resolutionCodeId.ToString());

                            Entity resolutionCodeEntity = service.Retrieve("whb_resolutioncode", resolutionCodeId, new ColumnSet("whb_resolutioncode_fp", "whb_validatedataretentionperiod"));
                            tracingService.Trace(resolutionCodeEntity.ToString());
                            bool dataRetentionPeriodFlag = resolutionCodeEntity.Attributes.Contains("whb_validatedataretentionperiod") ? resolutionCodeEntity.GetAttributeValue<bool>("whb_validatedataretentionperiod") : false;
                            tracingService.Trace(dataRetentionPeriodFlag.ToString());
                            int resolutionCode = resolutionCodeEntity.Attributes.Contains("whb_resolutioncode_fp") ? resolutionCodeEntity.GetAttributeValue<OptionSetValue>("whb_resolutioncode_fp").Value : -1;
                            tracingService.Trace(resolutionCode.ToString());

                            if (stateCode == 1 && dataRetentionPeriodFlag)
                            {
                                if (entity.Attributes.Contains("whb_closeddatetime") && (DateTime)entity.Attributes["whb_closeddatetime"] != DateTime.MinValue && (DateTime)entity.Attributes["whb_closeddatetime"] != null)
                                {
                                    caseClosedDate = (DateTime)entity.Attributes["whb_closeddatetime"];

                                    var exactmonth = (currentDateTime.Year - caseClosedDate.Year) * 12 + currentDateTime.Month - caseClosedDate.Month + (currentDateTime.Day >= caseClosedDate.Day ? 0 : -1);
                                    tracingService.Trace(exactmonth.ToString());
                                    //int dataRetentionPeriod = _helper.getdataRetentionperiod(service); // keep this outside the loop sinse it is called only once 
                                    //if (exactmonth >= 13)
                                    //if (exactmonth >= dataRetentionPeriod)
                                    //{
                                        //write logic to tick the cases for data erasure, these cases will be picked up by the custom workflow for data erasure - whb_enablefordataerasure
                                        _helper.ReactivatorCloseCase(service, 0, 1, entity.Id);
                                        _helper.updateCaseErasureFlag(service, entity.Id);
                                        _helper.closeCase(service,entity.Id);
                                    //}
                                }
                            }
                            else if (stateCode == 1) // Case is closed and any other resolution code apart from above mentioned one's erase data immediatly
                            {
                                tracingService.Trace("case is not greater than 13 months old and its does not have resolution code is any of these Refund-GNG -- 2, Refund - To Be Processed by Hotel -- 4, Refund - Holiday Extra GNG -- 5, Refund - BOA GNG -- 6, BART Issue GNG -- 20");
                                tracingService.Trace(entity.Id.ToString());
                                _helper.CallMultipleMethods(service, stateCode, statusCode, entity.Id,tracingService);
                            }
                        }
                        tracingService.Trace("Code Successfuly executed");
                    }
                    tracingService.Trace("Outside if");
                }
            }
            catch (Exception ex)
            {
                // Get stack trace for the exception with source file information
                var st = new StackTrace(ex, true);
                // Get the top stack frame
                var frame = st.GetFrame(0);
                // Get the line number from the stack frame
                var line = frame.GetFileLineNumber();
                throw new InvalidPluginExecutionException("Error Line number: " + line +  " Erase Case data : " + ex.Message);
            }
        }
    }
}