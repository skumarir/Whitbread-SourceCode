﻿///Created By muthu for Creating Q&A records
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace QualityAssurance
{
    public class Class1:IPlugin
    {
        IOrganizationService _service;
        ITracingService _tracer;
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext _context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory _serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                _service = _serviceFactory.CreateOrganizationService(_context.UserId);
                _tracer = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                Entity entity = (Entity)_context.InputParameters["Target"];
                if (_context.MessageName.ToLower() == "create")
                {
                    int contacttype = entity.Attributes.Contains("whb_type") ? entity.GetAttributeValue<OptionSetValue>("whb_type").Value : -1;
                   
                    // Query Expression for retrieving Question from Question entity.
                    QueryExpression query = new QueryExpression();
                    query.EntityName = "whb_qualitymonitoringquestions";
                    query.ColumnSet = new ColumnSet("whb_type", "whb_name", "whb_qmcategory", "whb_weightage");
                    query.Criteria.AddCondition("whb_type", ConditionOperator.Equal, contacttype);
                    query.Criteria.AddCondition("statuscode", ConditionOperator.Equal, 1);
                    EntityCollection enc = _service.RetrieveMultiple(query);
                    if (enc.Entities.Count > 0)
                    {

                        foreach (var qa in enc.Entities)
                        {
                            Entity qans = new Entity("whb_qualitymonitoringqa");
                            string name = qa.Attributes.Contains("whb_name")?qa.GetAttributeValue<string>("whb_name"):string.Empty;
                            decimal questionweigtage = qa.Attributes.Contains("whb_name") ? qa.GetAttributeValue<decimal>("whb_weightage") : 0;
                            int qacontacttype = qa.Attributes.Contains("whb_type") ?qa.GetAttributeValue<OptionSetValue>("whb_type").Value:-1;
                            
                            EntityReference category = qa.Attributes.Contains("whb_qmcategory") ?qa.GetAttributeValue<EntityReference>("whb_qmcategory"):null;
                            int qmcategorytype = GettingCategoryType(category);
                             
                           if(qmcategorytype != -1)
                            {
                                qans.Attributes["whb_categorytype"] = new OptionSetValue(qmcategorytype);
                            }

                           if(name !=string.Empty)
                            qans.Attributes["whb_name"] = name;
                           if(qacontacttype != -1)
                            qans.Attributes["whb_type"] = new OptionSetValue(qacontacttype);                          
                            qans.Attributes["whb_qualitymonitoring"] = new EntityReference(entity.LogicalName, entity.Id);
                            if(category !=null)
                            qans.Attributes["whb_qmcategory"] = new EntityReference(category.LogicalName, category.Id);                         
                            qans.Attributes["whb_questionweightage"] = questionweigtage;
                            _service.Create(qans);

                        }
                   }                   
    }               
            }
            catch (Exception ex) { throw new InvalidPluginExecutionException("Exception in QA" + ex.Message); }
            
        }
        #region Getting Category type from category entity
        private int GettingCategoryType(EntityReference category)
        {
            try
            {
                int qmcategorytype = -1;
                if (category != null)
                {
                    Entity categorytype = _service.Retrieve(category.LogicalName, category.Id, new ColumnSet("whb_categorytype"));

                    if (categorytype.Attributes.Contains("whb_categorytype"))
                    {
                        qmcategorytype = categorytype.GetAttributeValue<OptionSetValue>("whb_categorytype").Value;
                       
                    }
                }
                return qmcategorytype;
            }
            catch(Exception ex) { throw new InvalidPluginExecutionException("Exception in QualityAssurance" + MethodBase.GetCurrentMethod().Name + "-" + ex.Message); }
        }
        #endregion
    }


}
