﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Xml;
using System.Net;
using System.IO;
using System.Globalization;
using System.Reflection;

namespace WHB.CRM.Online.WebForm
{
    public class WebFormAfterCreation : IPlugin
    {
        IOrganizationService _service;
        ITracingService _tracer;
        string globalCurrencyId = string.Empty;
        string globalDummyProperty = string.Empty;
        string globalBusinessArea = string.Empty;
        Entity caseEntity = new Entity("incident");
        //string surname = string.Empty;
        //string firstname = string.Empty;
        //string postalCode = string.Empty;
        //string Phone = string.Empty;
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext _context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory _serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            _service = _serviceFactory.CreateOrganizationService(_context.UserId);
            _tracer = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            if (_context.InputParameters.Contains("Target") && _context.InputParameters["Target"] is Entity)
            {
                try
                {
                    Entity entity = (Entity)_context.InputParameters["Target"];

                    // Retrieve values from case entity and assigne them to the below variables
                    string arrDate = string.Empty;                    
                    string hotelCode = string.Empty;
                    string emailId = string.Empty;
                    string postalCode = string.Empty;
                    string Phone = string.Empty;
                    string surname = string.Empty;
                    string firstname = string.Empty;
                    int contactType = 0;
                    int reasonForContact = 0;
                    string reasonForFeedBack = "";
                    Entity businessarea = null;
                    string source = string.Empty;
                    string sourceId = string.Empty;
                    string propertyId = string.Empty;
                    int businessareavalue = -1;
                    string businessareaname = string.Empty;
                    string typeofVisit = string.Empty;
                    //DateTime arrivalDate = DateTime.MinValue;
                    string checkNumber = string.Empty;
                    string loyaltyCardNumber = string.Empty;
                    // get website details stored in case
                    QueryExpression queryExpression = new QueryExpression
                    {
                        EntityName = "incident",
                        ColumnSet = new ColumnSet(new string[]
                    { "whb_wffirstname", "whb_wflastname", "whb_wfpostcode", "whb_wfhotelname",
                        "whb_wfemailaddress", "whb_wfcontactnumber", "whb_wfbookingrefifapplicable", "whb_wfididntbookthroughpremierinncom",
                        "whb_wfdateofstayifapplicable","whb_contacttype","whb_reasonforcontact","whb_wfreasonforfeedback","whb_businessarea",
                        "whb_wftitle","whb_wfaddressline1","whb_wfaddressline2","whb_wfaddressline3","whb_wftowncity","whb_wfcountry",
                        "whb_wftelephonenumber","whb_wfididntbookthroughpremierinncom","whb_wfbookingrefifapplicable","whb_wfsource",
                        "whb_wftypeofvisit", "whb_wfchecknumber","whb_loyaltycardnumber" })
                    };

                    queryExpression.Criteria.AddCondition("incidentid", ConditionOperator.Equal, entity.Id);
                    //queryExpression.Criteria.AddCondition("whb_businessareavalue", ConditionOperator.Null);

                    caseEntity.Id = entity.Id;
                    EntityCollection resResult = _service.RetrieveMultiple(queryExpression);

                    foreach (var item in resResult.Entities)
                    {
                        if (item.Attributes.Contains("whb_wfdateofstayifapplicable"))
                        {
                            arrDate = item.Attributes["whb_wfdateofstayifapplicable"].ToString();
                        }
                        if (item.Attributes.Contains("whb_wfhotelname"))
                            hotelCode = item.Attributes["whb_wfhotelname"].ToString();
                        if (item.Attributes.Contains("whb_wfemailaddress"))
                            emailId = item.Attributes["whb_wfemailaddress"].ToString();
                        if (item.Attributes.Contains("whb_wfpostcode"))
                            postalCode = item.Attributes["whb_wfpostcode"].ToString();
                        if (item.Attributes.Contains("whb_wfcontactnumber"))
                            Phone = item.Attributes["whb_wfcontactnumber"].ToString();
                        if (item.Attributes.Contains("whb_wflastname"))
                            surname = item.Attributes["whb_wflastname"].ToString();
                        if (item.Attributes.Contains("whb_wffirstname"))
                            firstname = item.Attributes["whb_wffirstname"].ToString();
                        if (item.Attributes.Contains("whb_wfreasonforfeedback"))
                            reasonForFeedBack = item.Attributes["whb_wfreasonforfeedback"].ToString();
                        if (item.Attributes.Contains("whb_contacttype"))
                            contactType = ((Microsoft.Xrm.Sdk.OptionSetValue)(item.Attributes["whb_contacttype"])).Value;
                        if (item.Attributes.Contains("whb_reasonforcontact"))
                            reasonForContact = ((Microsoft.Xrm.Sdk.OptionSetValue)(item.Attributes["whb_reasonforcontact"])).Value;
                        if (item.Attributes.Contains("whb_wftypeofvisit"))
                            typeofVisit = item.Attributes["whb_wftypeofvisit"].ToString();                        
                        if (item.Attributes.Contains("whb_wfchecknumber"))
                            checkNumber = item.Attributes["whb_wfchecknumber"].ToString();
                        if (item.Attributes.Contains("whb_wfchecknumber"))
                            checkNumber = item.Attributes["whb_wfchecknumber"].ToString();
                        if (item.Attributes.Contains("whb_loyaltycardnumber"))
                            loyaltyCardNumber = item.Attributes["whb_loyaltycardnumber"].ToString();
                        // Get business area value
                        if (item.Attributes.Contains("whb_wfhotelname"))
                        {
                            businessarea = GetBusinessArea(_service, hotelCode);
                            if(businessarea!=null)
                            {
                                businessareavalue = businessarea.Attributes.Contains("whb_businessareavalue") ? businessarea.GetAttributeValue<int>("whb_businessareavalue") : -1;
                                businessareaname= businessarea.Attributes.Contains("whb_name") ? businessarea.GetAttributeValue<string>("whb_name") :string.Empty;
                            }
                        }
                           
                        //_tracer.Trace("business area : " + buisnessarea);
                        // Get Source
                        if (item.Attributes.Contains("whb_wfsource"))
                            source = item.Attributes["whb_wfsource"].ToString();
                        if (source == null || source == "" || source == string.Empty)
                            source = "https://www.premierinn.com";
                        _tracer.Trace("Source : " + source);
                    }

                    string teamId = GetTeamId(_service, hotelCode, source, reasonForFeedBack);

                    // No Property selected in the webform
                    if (businessareavalue == -1 && globalDummyProperty != null && globalDummyProperty != "" && globalDummyProperty!=string.Empty)
                    //if(hotelCode==null)
                    {
                        businessarea = GetBusinessAreaByPropetyId(_service, globalDummyProperty);
                        if(businessarea != null)
                        {
                            businessareavalue = businessarea.Attributes.Contains("whb_businessareavalue") ? businessarea.GetAttributeValue<int>("whb_businessareavalue") : -1;
                            businessareaname = businessarea.Attributes.Contains("whb_name") ? businessarea.GetAttributeValue<string>("whb_name") : string.Empty;
                        }
                    }
                        if(businessareavalue !=-1 && businessareaname !=string.Empty)
                    {
                        caseEntity.Attributes["whb_businessareavalue"] = businessareavalue;
                        caseEntity.Attributes["whb_businessarea_fp"] = businessareaname;
                    }

                    int visitCategory = -1;
                    if (!string.IsNullOrEmpty(typeofVisit))
                    {
                        visitCategory = getVisitCategory(_service, typeofVisit);
                    }
                    
                   
                    // checck website contain mandatory fields and contact type is webform
                    if (firstname != "" && surname != "" && postalCode != "" && emailId != "" && Phone != "")
                    {
                        caseEntity.Attributes["whb_date1stcontactreceived"] = Convert.ToDateTime(DateTime.Now.ToString("M/d/yyyy"));

                        if (teamId != null && teamId != string.Empty && teamId!="")
                        {
                            caseEntity["ownerid"] = new EntityReference("team", new Guid(teamId));
                        }

                        //if (source == null || source == "" || source == string.Empty)

                        caseEntity.Attributes["whb_wfsource"] = source;

                        if (visitCategory != -1)
                        {
                            _tracer.Trace("visit Category-" + visitCategory);

                            caseEntity.Attributes["whb_visitcategory"] = new OptionSetValue(visitCategory);
                        }
                        
                        if (!string.IsNullOrEmpty(arrDate))
                        {
                            _tracer.Trace("arrival date-"+ arrDate);
                            caseEntity.Attributes["whb_dateofincident"] = Convert.ToDateTime(arrDate);
                            _tracer.Trace("Date of incident" + Convert.ToDateTime(arrDate));
                            
                        }
                        if (!string.IsNullOrEmpty(checkNumber))
                        {
                            _tracer.Trace("check Number-" + checkNumber);

                            caseEntity.Attributes["whb_checknumber_r"] = checkNumber;
                        }

                        if (!string.IsNullOrEmpty(loyaltyCardNumber))
                        {
                            _tracer.Trace("Loyalty Card Number-" + loyaltyCardNumber);

                            caseEntity.Attributes["whb_loyaltycardnumber2"] = loyaltyCardNumber;
                        }

                        string CurrencyId = string.Empty;
                        if (hotelCode != null && hotelCode != "" && hotelCode != string.Empty)
                        {
                            string propertyname = "";
                            propertyname = GetPropertyId(_service, hotelCode);
                            if (propertyname != null && propertyname != "" && propertyname != string.Empty)
                            {
                                caseEntity.Attributes["whb_webformpropertyname"] = new EntityReference("whb_property", new Guid(propertyname));
                                caseEntity.Attributes["whb_property"] = new EntityReference("whb_property", new Guid(propertyname));
                                CurrencyId = GetCurrcnyFromPropertyId(_service, propertyname);
                            }
                        }
                        else
                        {
                            if (globalDummyProperty != null && globalDummyProperty != "" && globalDummyProperty != string.Empty)
                                caseEntity.Attributes["whb_property"] = new EntityReference("whb_property", new Guid(globalDummyProperty));
                            // Get currecny Id from Property  (Property --> Brand --> Currency)
                            CurrencyId = GetCurrcnyFromPropertyId(_service, globalDummyProperty);
                        }

                        if (reasonForContact == 2)
                        {
                            string resolutionCodes = string.Empty;
                            resolutionCodes = GetProposedResolutinCodeId(_service);

                            if (resolutionCodes != string.Empty)
                                caseEntity.Attributes["whb_proposedresolutioncode_fp"] = new EntityReference("whb_resolutioncode", new Guid(resolutionCodes));
                            caseEntity.Attributes["whb_resolutioncode_fp"] = new EntityReference("whb_resolutioncode", new Guid(resolutionCodes));
                        }

                        if (reasonForFeedBack != "")
                            caseEntity.Attributes["whb_webformcategory"] = reasonForFeedBack;

                        // save case with currency id
                        if (CurrencyId!=null && CurrencyId != string.Empty)
                        {
                            caseEntity["transactioncurrencyid"] = new EntityReference("transactioncurrency", new Guid(CurrencyId));
                        }
                        else
                        {
                            Guid currencyIdForGBP = GetCurrencyId(_service, "GBP");
                            if (currencyIdForGBP != Guid.Empty)
                                caseEntity["transactioncurrencyid"] = new EntityReference("transactioncurrency", currencyIdForGBP);
                        }

                        // Run BART for hotel
                        if (businessareavalue == 1)
                        {
                            Guid contactId = GetDummyContact(_service);

                            if (contactId != Guid.Empty)
                                caseEntity.Attributes["whb_contact"] = new EntityReference("contact", contactId);

                            caseEntity.Attributes["whb_runbart"] = true;
                        }

                        //Contact creation or assigning contact
                        else if (businessareavalue == 2)
                        {
                            if(emailId != string.Empty)
                            {
                                Guid restContact = getRestContact(_service, emailId, postalCode, Phone, firstname, surname);
                                if (restContact != Guid.Empty)
                                    caseEntity.Attributes["whb_contact"] = new EntityReference("contact", restContact);
                                    caseEntity.Attributes["customerid"] = new EntityReference("contact", restContact);
                            }
                            
                        }

                        _service.Update(caseEntity);
                    }
                }
                catch (Exception ex)
                {
                    _tracer.Trace("Exception in Execute Method : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                    throw new InvalidPluginExecutionException("Exception in WebForm Plugin: " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                }
            }
        }



        private int getVisitCategory(IOrganizationService _service, string typeofVisit)
        {
            if (typeofVisit == "")
                return -1;
            else if (typeofVisit.ToLower() == "breakfast")
                return 130570004;
            else if (typeofVisit.ToLower() == "lunch")
                return 130570006;
            else if (typeofVisit.ToLower() == "dinner")
                return 130570003;
            else if (typeofVisit.ToLower() == "other")
                return 130570005;
            else
                return -1;
        }

        public Guid GetDummyContact(IOrganizationService _service)
        {
            _tracer.Trace("Start GetDummyContact Method");
            Guid dummyContactId = Guid.Empty;
            try
            {
                QueryExpression queryExpression = new QueryExpression { EntityName = "contact", ColumnSet = new ColumnSet(new string[] { "contactid" }) };
                queryExpression.Criteria.AddCondition("statecode", ConditionOperator.NotEqual, 1);
                queryExpression.Criteria.AddCondition("fullname", ConditionOperator.Equal, "Dummy Contact");
                EntityCollection result = _service.RetrieveMultiple(queryExpression);
                if (result.Entities.Count == 1)
                {
                    dummyContactId = (Guid)result.Entities[0].Attributes["contactid"];
                    _tracer.Trace("dummy contact GUID : " + dummyContactId);

                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in GetDummyContact Method : " + ex.Message);
                throw;
            }

            return dummyContactId;
        }


        public string GetBrandId(IOrganizationService _service, string hotelCode)
        {
            try
            {
                _tracer.Trace("Start GetBrandId Method");
                QueryExpression queryExpression = new QueryExpression { EntityName = "whb_property", ColumnSet = new ColumnSet(new string[] { "whb_brandid" }) };
                queryExpression.Criteria.AddCondition("whb_propertycode", ConditionOperator.Equal, hotelCode);
                EntityCollection property = _service.RetrieveMultiple(queryExpression);

                foreach (Entity item in property.Entities)
                {
                    _tracer.Trace("Brand Id : " + ((Microsoft.Xrm.Sdk.EntityReference)(item.Attributes["whb_brandid"])).Id.ToString());
                    return ((Microsoft.Xrm.Sdk.EntityReference)(item.Attributes["whb_brandid"])).Id.ToString();
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in GetBrandId Method : " + ex.Message);
                throw;
            }

            return "";
        }

        public string GetProposedResolutinCodeId(IOrganizationService _service)
        {
            try
            {
                _tracer.Trace("Start -- GetProposedResolutinCodeId Method.");
                QueryExpression queryExpression = new QueryExpression { EntityName = "whb_resolutioncode", ColumnSet = new ColumnSet(new string[] { "whb_name" }) };
                queryExpression.Criteria.AddCondition("whb_resolutioncode_fp", ConditionOperator.Equal, 16);
                EntityCollection property = _service.RetrieveMultiple(queryExpression);

                foreach (Entity item in property.Entities)
                {
                    _tracer.Trace("Resolution code id for thankyou : " + item.Id.ToString());
                    return item.Id.ToString();
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in GetProposedResolutinCodeId Method : " + ex.Message);
                throw;
            }

            return "";
        }

        /// <summary>
        /// Get Source Id
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public string GetSourceId(IOrganizationService _service, string name)
        {
            try
            {
                _tracer.Trace("Start -- GetSourceId Method.");
                QueryExpression queryExpression = new QueryExpression { EntityName = "whb_source", ColumnSet = new ColumnSet(new string[] { "whb_name" }) };
                queryExpression.Criteria.AddCondition("whb_name", ConditionOperator.Equal, name);
                EntityCollection property = _service.RetrieveMultiple(queryExpression);

                foreach (Entity item in property.Entities)
                {
                    _tracer.Trace("Source Id : " + item.Id.ToString());
                    return item.Id.ToString();
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in GetSourceId Method : " + ex.Message);
                throw;
            }

            return "";
        }

        public string GetTeamId(IOrganizationService _service, string hotelCode, string source, string reasonForFeedBack)
        {
            _tracer.Trace("Start -- GetTeamId Method.");
            string brandId = string.Empty;
            string sourceId = string.Empty;

            if (hotelCode != string.Empty)
            {
                brandId = GetPropertyBrandId(_service, hotelCode);
                _tracer.Trace("brand Id : " + brandId);
            }

            if (source != string.Empty)
            {
                sourceId = GetSourceId(_service, source);
                _tracer.Trace("Source Id : " + sourceId);
            }

            QueryExpression queryExpression = new QueryExpression { EntityName = "whb_caseassignment", ColumnSet = new ColumnSet(new string[] { "whb_emailcasecreationteam", "whb_privacyteam", "whb_property" }) };

            if (brandId != string.Empty && brandId != "")
                queryExpression.Criteria.AddCondition("whb_brandid", ConditionOperator.Equal, brandId);
            else
                queryExpression.Criteria.AddCondition("whb_brandid", ConditionOperator.Null);

            if (sourceId != string.Empty)
                queryExpression.Criteria.AddCondition("whb_sourceid", ConditionOperator.Equal, sourceId);

            string teamId = string.Empty;

            try
            {
                EntityCollection result = _service.RetrieveMultiple(queryExpression);
                //_tracer.Trace("Retrieve records -- GetTeamId Method.");
                foreach (var item in result.Entities)
                {
                    if (brandId == string.Empty)
                        if (item.Attributes.Contains("whb_property"))
                            globalDummyProperty = ((Microsoft.Xrm.Sdk.EntityReference)(item.Attributes["whb_property"])).Id.ToString();

                    if ((!string.IsNullOrEmpty(reasonForFeedBack) && reasonForFeedBack.ToLower() == "privacy") || (!string.IsNullOrEmpty(reasonForFeedBack) && reasonForFeedBack.ToLower() == "datenschutz"))
                        teamId = ((Microsoft.Xrm.Sdk.EntityReference)(item.Attributes["whb_privacyteam"])).Id.ToString();
                    else
                        teamId = ((Microsoft.Xrm.Sdk.EntityReference)(item.Attributes["whb_emailcasecreationteam"])).Id.ToString();

                    _tracer.Trace("Team Id : " + teamId);
                    return teamId;
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in GetTeamId Method : " + ex.Message);
                throw;
            }

            return string.Empty;
        }

        public string GetPropertyId(IOrganizationService _service, string hotelCode)
        {
            try
            {
                _tracer.Trace("Start GetPropertyId Method");
                QueryExpression queryExpression = new QueryExpression { EntityName = "whb_property", ColumnSet = new ColumnSet(new string[] { "whb_name" }) };
                queryExpression.Criteria.AddCondition("whb_propertycode", ConditionOperator.Equal, hotelCode);
                EntityCollection property = _service.RetrieveMultiple(queryExpression);

                foreach (Entity item in property.Entities)
                {
                    return item.Id.ToString();
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in GetPropertyId Method : " + ex.Message);
                throw;
            }

            return "";
        }

        public string GetPropertyBrandId(IOrganizationService _service, string hotelCode)
        {
            try
            {
                _tracer.Trace("Start GetPropertyBrandId Method");
                QueryExpression queryExpression = new QueryExpression { EntityName = "whb_property", ColumnSet = new ColumnSet(new string[] { "whb_brandid" }) };
                queryExpression.Criteria.AddCondition("whb_propertycode", ConditionOperator.Equal, hotelCode); 
                 EntityCollection property = _service.RetrieveMultiple(queryExpression);

                foreach (Entity item in property.Entities)
                {
                    _tracer.Trace("Property Brand Id : " + ((Microsoft.Xrm.Sdk.EntityReference)(item.Attributes["whb_brandid"])).Id.ToString());
                    return ((Microsoft.Xrm.Sdk.EntityReference)(item.Attributes["whb_brandid"])).Id.ToString();
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in GetPropertyBrandId Method : " + ex.Message);
                throw;
            }

            return "";
        }

        /// <summary>
        /// Get Business Area by Property
        /// </summary>
        /// <param name="_service"></param>
        /// <param name="_tracer"></param>
        /// <param name="BusinessArea"></param>
        /// <returns></returns>
        public Entity GetBusinessArea(IOrganizationService _service, string PropertyCode)
        {
            _tracer.Trace("Start -- GetBusinessArea Method.");
            
            string fetchXML = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                <entity name='whb_businessarea'>
                                <attribute name='whb_businessareaid'/>
                                <attribute name='whb_businessareavalue'/>
                                <order attribute='whb_name' descending='false'/>
                                <link-entity name='whb_brand' from='whb_businessareaid' to='whb_businessareaid' link-type='inner' alias='ae'>
                                <link-entity name='whb_property' from='whb_brandid' to='whb_brandid' link-type='inner' alias='af'>
                                <filter type='and'>
                                <condition attribute='whb_propertycode' operator='eq' value='" + PropertyCode + "'/></filter></link-entity></link-entity></entity></fetch>";
            int businessAreaValue = -1;
            try
            {
                EntityCollection result = _service.RetrieveMultiple(new FetchExpression(fetchXML));
                //_tracer.Trace("Retrieve records -- GetBusinessArea Method.");
                foreach (Entity businessarea in result.Entities)
                {
                    //businessAreaValue = Convert.ToInt16(item["whb_businessareavalue"].ToString());
                    _tracer.Trace("Business Area Value : " + businessAreaValue);
                    return businessarea;
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in GetBusinessArea Method : " + ex.Message);
                throw;
            }

            //_tracer.Trace("Completed Successfully -- GetBusinessArea Method.");
            return null;
        }

        
        public string GetCurrcnyFromPropertyId(IOrganizationService _service, string PropertyId)
        {
            _tracer.Trace("Start -- GetCurrcnyFromPropertyId Method.");
            string fetchXML = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                <entity name='whb_brand'>
                                <attribute name='whb_brandid' />
                                <attribute name='whb_name' />
                                <attribute name='createdon' />
                                <attribute name='whb_currencyid' />
                                <order attribute='whb_name' descending='false' />
                                <link-entity name='whb_property' from='whb_brandid' to='whb_brandid' link-type='inner' alias='ab'>
                                <filter type='and'>
                                <condition attribute='whb_propertyid' operator='eq' value='{" + PropertyId + "}' /></filter></link-entity></entity></fetch>";
            string currencyId = string.Empty;
            try
            {
                EntityCollection result = _service.RetrieveMultiple(new FetchExpression(fetchXML));
                //_tracer.Trace("Retrieve records -- GetBusinessArea Method.");
                foreach (var item in result.Entities)
                {
                    //currencyId = ((Microsoft.Xrm.Sdk.EntityReference)(item.Attributes["whb_currencyid"])).Id.ToString();

                    currencyId = item.Contains("whb_currencyid") ? item.GetAttributeValue<EntityReference>("whb_currencyid").Id.ToString() : null;
                    _tracer.Trace("Currency Id : " + currencyId);
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in GetCurrcnyFromPropertyId Method : " + ex.Message);
                throw;
            }

            //_tracer.Trace("Completed Successfully -- GetBusinessArea Method.");
            return currencyId;
        }

        public Entity GetBusinessAreaByPropetyId(IOrganizationService _service, string PropertyId)
        {
            _tracer.Trace("Start -- GetBusinessAreaByPropetyId Method.");
            string fetchXML = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                <entity name='whb_businessarea'>
                                <attribute name='whb_businessareaid'/>
                                <attribute name='whb_businessareavalue'/>
                                <order attribute='whb_name' descending='false'/>
                                <link-entity name='whb_brand' from='whb_businessareaid' to='whb_businessareaid' link-type='inner' alias='ae'>
                                <link-entity name='whb_property' from='whb_brandid' to='whb_brandid' link-type='inner' alias='af'>
                                <filter type='and'>
                                <condition attribute='whb_propertyid' operator='eq' value='{" + PropertyId + "}'/></filter></link-entity></link-entity></entity></fetch>";

            try
            {
                EntityCollection result = _service.RetrieveMultiple(new FetchExpression(fetchXML));
                //_tracer.Trace("Retrieve records -- GetBusinessArea Method.");
                foreach (Entity businessarea in result.Entities)
                {
                    return businessarea;
                    //businessAreaValue = Convert.ToInt16(item["whb_businessareavalue"].ToString());
                   // _tracer.Trace("Business Area Value :" + businessAreaValue);
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in GetBusinessAreaByPropetyId Method : " + ex.Message);
                throw;
            }


            return null;
        }

        public Guid GetCurrencyId(IOrganizationService _service, string userdCurreny)
        {
            try
            {
                _tracer.Trace("Start GetCurrencyId Method");
                QueryExpression queryExpression = new QueryExpression { EntityName = "transactioncurrency", ColumnSet = new ColumnSet(new string[] { "transactioncurrencyid" }) };
                queryExpression.Criteria.AddCondition("isocurrencycode", ConditionOperator.Equal, userdCurreny);
                EntityCollection currencyId = _service.RetrieveMultiple(queryExpression);

                foreach (var item in currencyId.Entities)
                {
                    _tracer.Trace("Currency Id : " + item.Id);
                    return item.Id;
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in GetCurrencyId Method : " + ex.Message);
                throw;
            }


            return Guid.Empty;
        }

        public Guid getRestContact(IOrganizationService _service, string emailId,string postCode, string phoneNumber, string firstName, string lastName)
        {
            _tracer.Trace("Start getRestContact method");
            Guid restContact = Guid.Empty;
            try
            {
                QueryExpression retrieveContact = new QueryExpression();
                retrieveContact.EntityName = "contact";
                retrieveContact.ColumnSet = new ColumnSet("emailaddress1");
                retrieveContact.Criteria.AddCondition("emailaddress1", ConditionOperator.Equal, emailId);
                EntityCollection ecContact = _service.RetrieveMultiple(retrieveContact);
                _tracer.Trace(ecContact.Entities.Count.ToString());
                if (ecContact.Entities.Count > 0)
                    restContact = ecContact.Entities[0].Id;
                else
                    restContact = createRestContact(_service, emailId, postCode, phoneNumber, firstName, lastName);                
                
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in getRestContact Method : " + ex.Message);
                throw;
            }
            return restContact;
        }

        public Guid createRestContact(IOrganizationService _service, string emailAddress, string postCode, string phoneNumber, string firstName, string lastName)
        {
            _tracer.Trace("Start createRestContact method");
            Guid newContact = Guid.Empty;
            try
            {
                Entity contact = new Entity("contact");
                if (firstName != "")
                    contact.Attributes["firstname"] = firstName;
                if (lastName != "")
                    contact.Attributes["lastname"] = lastName;
                if (postCode != "")
                    contact.Attributes["address1_postalcode"] = postCode;
                if (phoneNumber != "")
                    contact.Attributes["mobilephone"] = phoneNumber;
                if (emailAddress != "")
                    contact.Attributes["emailaddress1"] = emailAddress.Trim();
                newContact = _service.Create(contact);
                return newContact;

            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in createRestContact Method : " + ex.Message);
                throw;
            }
            
        }
    }
}

