﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Query;
using System.Activities;
using System.Reflection;
using System.Xml;
using System.Net;
using System.IO;
using System.Globalization;

namespace WHB.CRM.Online.BARTWorlflowForWebForm
{
    public class RunBART : CodeActivity
    {
        string RoomIdExists = "";
        string APIUserName = "";
        string APIPassword = "";
        string SOAPRequest = "";
        string reservationSearch = "";
        string guestHistoryQuery = "";
        string guestHistorySearch = "";
        string historyRecordDetailQuery = "";
        string feedBackfeedbackRecordQuery = "";
        string arrDate = "";
        string hotelCode = "";
        string thirdPartyReference = "";
        string reservationNumber = "";
        string emailId = "";
        string postalCode = "";
        string Phone = "";
        string surname = "";
        string firstName = "";
        string guestHistoryNumberResult = "";
        string reservatonNumberResult = "";
        string thirdPartyReferenceNumber = ""; // coming from the search result response
        string feedBackData = "";
        string webformcategory = "";
        string addressline1 = "";
        string addressline2 = "";
        string addressline3 = "";
        string title = "";
        string town = "";
        string country = "";
        string telephoneno = "";
        string reservation_whb_paymentdate = "";
        IOrganizationService _service;
        Guid reservationId = Guid.Empty;
        Guid contactId = Guid.Empty;
        Guid guestId = Guid.Empty;
        string contactName = "";
        List<RoomDetails> lstRoomCost = new List<RoomDetails>();
        ITracingService _tracer;
        Guid reservationPropertyId = Guid.Empty;
        Guid GlobalTrasactionCurrencyId = Guid.Empty;
        List<ReservationPayments> resPayments = new List<ReservationPayments>();
        Entity caseEntity = new Entity("incident");
        protected override void Execute(CodeActivityContext executionContext)
        {
            try
            {

                IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
                IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
                _service = serviceFactory.CreateOrganizationService(context.UserId);
                _tracer = executionContext.GetExtension<ITracingService>();

                Guid caseId = context.PrimaryEntityId;

                // Retrieve values from case entity and assigne them to the below variables
                arrDate = "";
                hotelCode = "";
                thirdPartyReference = "";
                reservationNumber = "";
                emailId = "";
                postalCode = "";
                Phone = "";
                surname = "";
                firstName = "";
                int contactType = 0;
                int reasonForContact = 0;
                string reasonForFeedBack = "";
                EntityReference team = null;
                // get website details stored in case
                QueryExpression queryExpression = new QueryExpression
                {
                    EntityName = "incident",
                    ColumnSet = new ColumnSet(new string[]
                { "whb_wffirstname", "whb_wflastname", "whb_wfpostcode", "whb_wfhotelname",
                        "whb_wfemailaddress", "whb_wfcontactnumber", "whb_wfbookingrefifapplicable", "whb_wfididntbookthroughpremierinncom",
                        "whb_wfdateofstayifapplicable","whb_contacttype","whb_reasonforcontact","whb_wfreasonforfeedback","whb_businessarea","whb_wftitle","whb_wfaddressline1","whb_wfaddressline2","whb_wfaddressline3","whb_wftowncity","whb_wfcountry","whb_wftelephonenumber","whb_wfididntbookthroughpremierinncom","whb_wfbookingrefifapplicable" })
                };
                //Guid caseId = new Guid("f9eb92ab-1805-e811-a950-000d3ab0cd3c");
                queryExpression.Criteria.AddCondition("incidentid", ConditionOperator.Equal, caseId);
                //queryExpression.Criteria.AddCondition("incidentid", ConditionOperator.Equal, caseId);

                caseEntity.Id = caseId;
                EntityCollection resResult = _service.RetrieveMultiple(queryExpression);
                _tracer.Trace("Fetch incident");
                foreach (var item in resResult.Entities)
                {
                    _tracer.Trace("Fetch incident1" + caseId.ToString());
                    if (item.Attributes.Contains("whb_wfdateofstayifapplicable"))
                        arrDate = item.Attributes["whb_wfdateofstayifapplicable"].ToString();
                    _tracer.Trace("Fetch incident2");
                    if (item.Attributes.Contains("whb_wfhotelname"))
                        hotelCode = item.Attributes["whb_wfhotelname"].ToString();
                    _tracer.Trace("Fetch incident3");
                    if (item.Attributes.Contains("whb_wfemailaddress"))
                        emailId = item.Attributes["whb_wfemailaddress"].ToString();
                    if (item.Attributes.Contains("whb_wfpostcode"))
                        postalCode = item.Attributes["whb_wfpostcode"].ToString();
                    if (item.Attributes.Contains("whb_wfcontactnumber"))
                        Phone = item.Attributes["whb_wfcontactnumber"].ToString();
                    if (item.Attributes.Contains("whb_wflastname"))
                        surname = item.Attributes["whb_wflastname"].ToString();
                    if (item.Attributes.Contains("whb_wffirstname"))
                        firstName = item.Attributes["whb_wffirstname"].ToString();
                    if (item.Attributes.Contains("whb_wftitle"))
                        title = item.Attributes["whb_wftitle"].ToString();
                    if (item.Attributes.Contains("whb_wfaddressline1"))
                        title = item.Attributes["whb_wfaddressline1"].ToString();
                    if (item.Attributes.Contains("whb_wfaddressline2"))
                        addressline2 = item.Attributes["whb_wfaddressline2"].ToString();
                    if (item.Attributes.Contains("whb_wfaddressline3"))
                        addressline3 = item.Attributes["whb_wfaddressline3"].ToString();
                    if (item.Attributes.Contains("whb_wftowncity"))
                        town = item.Attributes["whb_wftowncity"].ToString();
                    _tracer.Trace("Fetch incident4");
                    if (item.Attributes.Contains("whb_wfcountry"))
                        country = item.Attributes["whb_wfcountry"].ToString();
                    if (item.Attributes.Contains("whb_wftelephonenumber"))
                        telephoneno = item.Attributes["whb_wftelephonenumber"].ToString();
                    _tracer.Trace("Fetch incident 2");
                    if (item.Attributes.Contains("whb_wfididntbookthroughpremierinncom"))
                    {
                        if ((bool)item.Attributes["whb_wfididntbookthroughpremierinncom"] == false)
                        {
                            if (item.Attributes.Contains("whb_wfbookingrefifapplicable"))
                                reservationNumber = item.Attributes["whb_wfbookingrefifapplicable"].ToString().ToUpper();
                        }
                        else
                        {
                            if (item.Attributes.Contains("whb_wfbookingrefifapplicable"))
                            {
                                thirdPartyReference = item.Attributes["whb_wfbookingrefifapplicable"].ToString().ToUpper();
                                thirdPartyReferenceNumber = item.Attributes["whb_wfbookingrefifapplicable"].ToString().ToUpper();
                            }
                        }
                    }
                    _tracer.Trace("Fetch incident 6");
                    if (item.Attributes.Contains("whb_contacttype"))
                        contactType = ((Microsoft.Xrm.Sdk.OptionSetValue)(item.Attributes["whb_contacttype"])).Value;
                    _tracer.Trace("Fetch incident 7");
                    if (item.Attributes.Contains("whb_reasonforcontact"))
                        reasonForContact = ((Microsoft.Xrm.Sdk.OptionSetValue)(item.Attributes["whb_reasonforcontact"])).Value;
                    if (item.Attributes.Contains("whb_wfreasonforfeedback"))
                        reasonForFeedBack = item.Attributes["whb_wfreasonforfeedback"].ToString();
                    _tracer.Trace("Fetch incident 8");

                    GetCustomizations();

                    if (arrDate != "")
                    {
                        DateTime dt = DateTime.Parse(arrDate, new CultureInfo("en-CA"));
                        arrDate = dt.Date.ToString("yyyy-MM-dd");
                    }

                    if (reservationNumber != "")
                    {
                        reservationNumber = reservationNumber.Trim();
                        reservationNumber = reservationNumber.ToUpper();
                    }
                    if (thirdPartyReference != "")
                    {
                        thirdPartyReference = thirdPartyReference.Trim();
                        thirdPartyReference = thirdPartyReference.ToUpper();
                    }

                    // Check from BART
                    ReservationDetails(reservationNumber, thirdPartyReference, hotelCode, arrDate, surname, emailId, postalCode, Phone, firstName);

                    if (reservatonNumberResult != "" && RoomIdExists != "")
                    {
                        XmlDocument webResponse = GetReservationHisotryQueriyDetailsWithRoomId(reservatonNumberResult, RoomIdExists);
                        ReadReservationHistoryQueryDetailsResponse(webResponse);
                    }
                    else if (reservatonNumberResult != "")
                    {
                        XmlDocument webResponse = GetReservationHisotryQueriyDetailsWithRoomId(reservatonNumberResult, RoomIdExists);
                        ReadReservationHistoryQueryDetailsResponse(webResponse);
                    }
                    else if (guestHistoryNumberResult != "")
                    {
                        CreateContact(guestHistoryNumberResult);
                    }

                    if (reservationId != Guid.Empty)
                        caseEntity.Attributes["whb_reservation"] = new EntityReference("whb_reservation", reservationId);

                    if (contactId != Guid.Empty && RoomIdExists != "")
                    {
                        caseEntity.Attributes["whb_contact"] = new EntityReference("contact", contactId);
                        caseEntity.Attributes["customerid"] = new EntityReference("contact", contactId);
                    }
                    else
                    {
                        contactId = GetDummyContact(_service, _tracer);
                        if (contactId != Guid.Empty)
                            caseEntity.Attributes["whb_contact"] = new EntityReference("contact", contactId);
                    }
                    if (guestId != Guid.Empty)
                        caseEntity.Attributes["whb_guestname"] = new EntityReference("whb_stays", guestId);

                    if (hotelCode != "")
                    {
                        string propertyId = "";
                        propertyId = GetPropertyId(hotelCode);
                        if (propertyId != "")
                        {
                            caseEntity.Attributes["whb_webformpropertyname"] = new EntityReference("whb_property", new Guid(propertyId));
                            // caseEntity.Attributes["whb_webformpropertyname"] = new EntityReference("whb_webformpropertyname", new Guid(propertyId));
                        }

                    }

                    if (reservationPropertyId != Guid.Empty)
                    {
                        caseEntity.Attributes["whb_property"] = new EntityReference("whb_property", reservationPropertyId);
                        int valueOfSiteNotification = GetPropertySiteNotification(reservationPropertyId);
                        if (valueOfSiteNotification == 0)// the workflow will be triggered 
                            caseEntity.Attributes["whb_triggerpropertyworkflow"] = true;
                    }

                    if (GlobalTrasactionCurrencyId != Guid.Empty)
                        caseEntity["transactioncurrencyid"] = new EntityReference("transactioncurrency", GlobalTrasactionCurrencyId);
                    else
                    {
                        Guid currencyIdForGBP = GetCurrencyId("GBP");
                        if (currencyIdForGBP != Guid.Empty)
                            caseEntity["transactioncurrencyid"] = new EntityReference("transactioncurrency", currencyIdForGBP);
                    }
                    _service.Update(caseEntity);
                }

            }
            catch (Exception ex)
            {
                throw new InvalidWorkflowException("Error Occured in Auto Reply" + ex.Message);
            }
        }

        // Getting reservation details
        public void ReservationDetails(string reservationNumber, string thirdPartyBookingReference, string hotelName, string dateOfArrival, string surname, string emailAddress, string postalCode, string Phone, string FirstName)
        {
            try
            {
                _tracer.Trace("Start ReservationDetails Method");
                XmlDocument webResponse = null;
                if (reservationNumber != "" || thirdPartyBookingReference != "")
                {
                    webResponse = GetResearvationDetails(surname, reservationNumber, thirdPartyBookingReference, hotelName, dateOfArrival);
                    ReadReservationResponse(webResponse);
                }
                else
                {
                    webResponse = GetContactDetails(surname, emailAddress, postalCode, Phone, FirstName);
                    ReadContactResponse(webResponse);
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }

        }

        public EntityReference GetTeambyAttribute(ref IOrganizationService _service, string entityName, string attributeName, int attributeValue, string[] arrColumns)
        {
            EntityReference entRec = null;
            try
            {
                ConditionExpression condRec = new ConditionExpression(attributeName, ConditionOperator.Equal, attributeValue);
                FilterExpression filtRec = new FilterExpression(LogicalOperator.And);
                filtRec.Conditions.AddRange(condRec);
                QueryExpression queryRec = new QueryExpression(entityName);
                queryRec.Criteria = filtRec;
                queryRec.ColumnSet = new ColumnSet(arrColumns);
                EntityCollection colRec = _service.RetrieveMultiple(queryRec);
                if (colRec != null && colRec.Entities.Count > 0)
                {
                    entRec = colRec.Entities[0].ToEntityReference();
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }
            return entRec;
        }


        // Read reservation response
        public void ReadReservationHistoryQueryDetailsResponse(XmlDocument webResponse)
        {
            try
            {
                string contactIdCreated = "";
                // Create reservation
                CreateReservation();
                string bookerGuestHistoryNumber = GetBookerGuestHistoryNumber(webResponse);
                if (RoomIdExists != "")
                {
                    // booker and guest are same
                    if (bookerGuestHistoryNumber == guestHistoryNumberResult && guestHistoryNumberResult != "" && bookerGuestHistoryNumber != "")
                    {
                        contactIdCreated = CreateContact(guestHistoryNumberResult);
                        if (contactIdCreated != "")
                        {
                            UpdateReservationWithBooker(contactIdCreated);
                            contactId = new Guid(contactIdCreated);
                            CreateGuestDetails(webResponse, guestHistoryNumberResult, contactIdCreated);
                        }
                    }
                    else if (guestHistoryNumberResult != "")
                    {
                        if (bookerGuestHistoryNumber != "")
                        {
                            string bookerId = CreateContact(bookerGuestHistoryNumber);
                            if (bookerId != "")
                                UpdateReservationWithBooker(bookerId);
                        }
                        contactIdCreated = CreateContact(guestHistoryNumberResult);
                        if (contactIdCreated != "")
                        {
                            contactId = new Guid(contactIdCreated);
                            CreateGuestDetails(webResponse, guestHistoryNumberResult, contactIdCreated);
                        }
                    }
                    else if (guestHistoryNumberResult == "")
                    {
                        if (bookerGuestHistoryNumber != "")
                        {
                            string bookerId = CreateContact(bookerGuestHistoryNumber);
                            if (bookerId != "")
                            {
                                UpdateReservationWithBooker(bookerId);
                            }
                        }
                        contactIdCreated = CreateContactForStayer(reservationNumber, RoomIdExists);// create contact and guest details and room details
                        if (contactIdCreated != "")
                            contactId = new Guid(contactIdCreated);
                    }
                }
                else
                {
                    if (bookerGuestHistoryNumber != "")
                    {
                        contactIdCreated = CreateContact(bookerGuestHistoryNumber);
                        if (contactIdCreated != "")
                            UpdateReservationWithBooker(contactIdCreated);
                    }
                    contactId = Guid.Empty;
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Get Dummycontact from contact
        /// </summary>
        /// <param name="_service"></param>
        /// <param name="_tracer"></param>
        /// <returns></returns>
        public Guid GetDummyContact(IOrganizationService _service, ITracingService _tracer)
        {
            Guid dummyContactId = Guid.Empty;
            try
            {
                QueryExpression queryExpression = new QueryExpression { EntityName = "contact", ColumnSet = new ColumnSet(new string[] { "contactid" }) };
                queryExpression.Criteria.AddCondition("statecode", ConditionOperator.NotEqual, 1);
                queryExpression.Criteria.AddCondition("fullname", ConditionOperator.Equal, "Dummy Contact");
                EntityCollection result = _service.RetrieveMultiple(queryExpression);
                if (result.Entities.Count == 1)
                {
                    dummyContactId = (Guid)result.Entities[0].Attributes["contactid"];
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }

            return dummyContactId;
        }

        public void CreateGuestDetailsWithOutGuestHistoryNumber(XmlDocument webResponse)
        {
            try
            {
                var roomType = "";
                var roomNumber = "";
                var adults = "";
                var childeren = "";
                var cot = "";
                var numberOfNights = 0;
                string roomNumberFromGuest = "";


                XmlNodeList booking = webResponse.GetElementsByTagName("Room");
                foreach (XmlNode BookingNode in booking)// Guest Details
                {
                    foreach (XmlNode BookingChildNode in BookingNode.ChildNodes)
                    {
                        if (BookingChildNode.Name == "lettingType")
                            roomType = BookingChildNode.InnerText;
                        if (BookingChildNode.Name == "roomId")
                            roomNumber = BookingChildNode.InnerText;
                        if (BookingChildNode.Name == "roomNumber")
                            roomNumberFromGuest = BookingChildNode.InnerText;
                        if (BookingChildNode.Name == "adults")
                            adults = BookingChildNode.InnerText;
                        if (BookingChildNode.Name == "children")
                            childeren = BookingChildNode.InnerText;
                        if (BookingChildNode.Name == "cot")
                            cot = BookingChildNode.InnerText;
                    }
                }
                string amount = "";
                Guid transactioncurrencyid = Guid.Empty;
                XmlNodeList invoiceAmount = webResponse.GetElementsByTagName("Invoice");
                foreach (XmlNode invoice in invoiceAmount)// 
                {
                    foreach (XmlNode invoiceChild in invoice.ChildNodes)
                    {
                        if (invoiceChild.Name == "amount")
                            amount = invoiceChild.InnerText;

                        if (invoiceChild.Name == "currency")
                        {
                            string userdCurreny = invoiceChild.InnerText;
                            transactioncurrencyid = GetCurrencyId(userdCurreny);

                        }
                    }
                }

                // reservation payments
                XmlNodeList reservationPayments = webResponse.GetElementsByTagName("Payment");
                foreach (XmlNode reservationPaymentsNode in reservationPayments)// Cost Breakdown
                {
                    ReservationPayments rPay = new ReservationPayments();
                    foreach (XmlNode reservationPaymentsChild in reservationPaymentsNode.ChildNodes)// Cost Breakdown
                    {
                        if (reservationPaymentsChild.Name == "paymentAmount")
                            rPay.paymentAmount = reservationPaymentsChild.InnerText;

                        if (reservationPaymentsChild.Name == "currency")
                        {
                            string userdCurreny = reservationPaymentsChild.InnerText;
                            Guid currencyGUID = GetCurrencyId(userdCurreny);
                            rPay.currency = Convert.ToString(currencyGUID);
                        }
                        if (reservationPaymentsChild.Name == "paymentType")
                        {
                            rPay.paymentType = reservationPaymentsChild.InnerText;
                        }
                        if (reservationPaymentsChild.Name == "cardType")
                        {
                            rPay.cardType = reservationPaymentsChild.InnerText;
                        }
                        if (reservationPaymentsChild.Name == "cardNumber")
                        {
                            rPay.cardNumber = reservationPaymentsChild.InnerText;
                        }
                        if (reservationPaymentsChild.Name == "expiryDate")
                        {
                            rPay.expiryDate = reservationPaymentsChild.InnerText;
                        }
                        if (reservationPaymentsChild.Name == "cardHoldersName")
                        {
                            rPay.cardHoldersName = reservationPaymentsChild.InnerText;
                        }
                    }

                    resPayments.Add(rPay);
                }


                XmlNodeList costBreakdowns = webResponse.GetElementsByTagName("CostBreakdown");
                foreach (XmlNode CostBreakdownNode in costBreakdowns)// Cost Breakdown
                {
                    foreach (XmlNode CostBreakdownChildNode in CostBreakdownNode.ChildNodes)
                    {
                        if (CostBreakdownChildNode.Name == "roomCharges")
                        {
                            numberOfNights = CostBreakdownChildNode.ChildNodes.Count;
                            foreach (XmlNode roomChargeNode in CostBreakdownChildNode.ChildNodes)
                            {
                                RoomDetails obj = new RoomDetails();
                                if (roomChargeNode.Name == "RoomCharge")
                                {
                                    foreach (XmlNode roomChargeAmountNode in roomChargeNode.ChildNodes)
                                    {
                                        if (roomChargeAmountNode.Name == "amount")
                                        {
                                            obj.amount = roomChargeAmountNode.InnerText;
                                        }
                                        if (roomChargeAmountNode.Name == "currency")
                                        {
                                            obj.currencyType = roomChargeAmountNode.InnerText;
                                        }
                                        if (roomChargeAmountNode.Name == "date")
                                        {
                                            obj.roomDate = Convert.ToDateTime(roomChargeAmountNode.InnerText);
                                        }
                                    }
                                    lstRoomCost.Add(obj);
                                }
                            }
                        }
                    }
                }

                CreateGuestDetailsInCRM(roomNumberFromGuest, roomType, adults, childeren, cot, numberOfNights.ToString(), amount, transactioncurrencyid);
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }
        }

        // create guest in crm
        public void CreateGuestDetails(XmlDocument webResponse, string guestHistoryNumber, string contactIdCreated)
        {
            try
            {
                var roomType = "";
                var roomId = "";
                var adults = "";
                var childeren = "";
                var cot = "";
                var numberOfNights = 0;
                string roomNumberFromGuest = "";
                string amount = "";
                Guid transactioncurrencyid = Guid.Empty;


                XmlNodeList booking = webResponse.GetElementsByTagName("Room");
                foreach (XmlNode BookingNode in booking)// Guest Details
                {
                    foreach (XmlNode BookingChildNode in BookingNode.ChildNodes)
                    {
                        if (BookingChildNode.Name == "lettingType")
                            roomType = BookingChildNode.InnerText;
                        if (BookingChildNode.Name == "roomId")
                            roomId = BookingChildNode.InnerText;
                        if (BookingChildNode.Name == "roomNumber")
                            roomNumberFromGuest = BookingChildNode.InnerText;
                        if (BookingChildNode.Name == "adults")
                            adults = BookingChildNode.InnerText;
                        if (BookingChildNode.Name == "children")
                            childeren = BookingChildNode.InnerText;
                        if (BookingChildNode.Name == "cot")
                            cot = BookingChildNode.InnerText;
                    }
                }

                XmlNodeList invoiceAmount = webResponse.GetElementsByTagName("Invoice");
                foreach (XmlNode invoice in invoiceAmount)// Cost Breakdown
                {
                    foreach (XmlNode invoiceChild in invoice.ChildNodes)// Cost Breakdown
                    {
                        if (invoiceChild.Name == "amount")
                            amount = invoiceChild.InnerText;

                        if (invoiceChild.Name == "currency")
                        {
                            string userdCurreny = invoiceChild.InnerText;
                            transactioncurrencyid = GetCurrencyId(userdCurreny);
                        }
                    }
                }

                // reservation payments
                XmlNodeList reservationPayments = webResponse.GetElementsByTagName("Payment");
                foreach (XmlNode reservationPaymentsNode in reservationPayments)// Cost Breakdown
                {
                    ReservationPayments rPay = new ReservationPayments();
                    foreach (XmlNode reservationPaymentsChild in reservationPaymentsNode.ChildNodes)// Cost Breakdown
                    {
                        if (reservationPaymentsChild.Name == "paymentAmount")
                            rPay.paymentAmount = reservationPaymentsChild.InnerText;

                        if (reservationPaymentsChild.Name == "currency")
                        {
                            string userdCurreny = reservationPaymentsChild.InnerText;
                            Guid currencyGUID = GetCurrencyId(userdCurreny);
                            rPay.currency = Convert.ToString(currencyGUID);
                        }
                        if (reservationPaymentsChild.Name == "paymentType")
                        {
                            rPay.paymentType = reservationPaymentsChild.InnerText;
                        }
                        if (reservationPaymentsChild.Name == "cardType")
                        {
                            rPay.cardType = reservationPaymentsChild.InnerText;
                        }
                        if (reservationPaymentsChild.Name == "cardNumber")
                        {
                            rPay.cardNumber = reservationPaymentsChild.InnerText;
                        }
                        if (reservationPaymentsChild.Name == "expiryDate")
                        {
                            rPay.expiryDate = reservationPaymentsChild.InnerText;
                        }
                        if (reservationPaymentsChild.Name == "cardHoldersName")
                        {
                            rPay.cardHoldersName = reservationPaymentsChild.InnerText;
                        }
                    }

                    resPayments.Add(rPay);
                }

                XmlNodeList costBreakdowns = webResponse.GetElementsByTagName("CostBreakdown");
                foreach (XmlNode CostBreakdownNode in costBreakdowns)// Cost Breakdown
                {
                    foreach (XmlNode CostBreakdownChildNode in CostBreakdownNode.ChildNodes)
                    {
                        if (CostBreakdownChildNode.Name == "roomCharges")
                        {
                            numberOfNights = CostBreakdownChildNode.ChildNodes.Count;
                            foreach (XmlNode roomChargeNode in CostBreakdownChildNode.ChildNodes)
                            {
                                RoomDetails obj = new RoomDetails();
                                if (roomChargeNode.Name == "RoomCharge")
                                {
                                    foreach (XmlNode roomChargeAmountNode in roomChargeNode.ChildNodes)
                                    {
                                        if (roomChargeAmountNode.Name == "amount")
                                        {
                                            obj.amount = roomChargeAmountNode.InnerText;
                                        }
                                        if (roomChargeAmountNode.Name == "currency")
                                        {
                                            obj.currencyType = roomChargeAmountNode.InnerText;
                                        }
                                        if (roomChargeAmountNode.Name == "date")
                                        {
                                            obj.roomDate = Convert.ToDateTime(roomChargeAmountNode.InnerText);
                                        }
                                    }
                                    lstRoomCost.Add(obj);
                                }
                            }
                        }
                    }
                }

                CreateGuestDetailsInCRM(roomNumberFromGuest, roomType, adults, childeren, cot, numberOfNights.ToString(), amount, transactioncurrencyid);
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }
        }

        // create guest in crm
        public void CreateGuestDetailsInCRM(string roomNumber, string roomType, string adults, string childeren, string cot, string numberOfNights, string amount, Guid trasactionCurrencyId)
        {
            try
            {
                Entity stayees = new Entity("whb_stays");
                if (reservationId != Guid.Empty)
                    stayees.Attributes["whb_reservation"] = new EntityReference("whb_reservation", reservationId);
                stayees.Attributes["whb_roomnumber"] = roomNumber;
                stayees.Attributes["whb_roomtype"] = roomType;
                stayees.Attributes["whb_adultcount"] = adults;
                stayees.Attributes["whb_childrencount"] = childeren;
                stayees.Attributes["whb_cot"] = cot;
                if (numberOfNights != "")
                    stayees.Attributes["whb_numberofnights"] = Convert.ToInt32(numberOfNights);
                stayees.Attributes["whb_name"] = contactName;
                // stayees.Attributes["whb_sitefeedback"] = feedBackData;
                if (contactId != Guid.Empty)
                    stayees.Attributes["whb_contact"] = new EntityReference("contact", contactId);
                if (amount != "")
                {
                    stayees["whb_invoiceamount"] = new Money(Convert.ToDecimal(amount));
                    if (trasactionCurrencyId != Guid.Empty)
                        stayees["transactioncurrencyid"] = new EntityReference("transactioncurrency", trasactionCurrencyId);
                }
                else
                {
                    stayees["whb_invoiceamount"] = new Money(Convert.ToDecimal(0));
                    Guid currencyId = GetCurrencyId("GBP");
                    if (currencyId != Guid.Empty)
                        stayees["transactioncurrencyid"] = new EntityReference("transactioncurrency", currencyId);
                }
                //Guid guestId = Guid.Empty;
                if (reservationId != Guid.Empty && contactId != Guid.Empty)
                {
                    QueryExpression queryExpression = new QueryExpression { EntityName = "whb_stays", ColumnSet = new ColumnSet(new string[] { "whb_name" }) };

                    queryExpression.Criteria.AddCondition("whb_reservation", ConditionOperator.Equal, reservationId);

                    queryExpression.Criteria.AddCondition("whb_contact", ConditionOperator.Equal, contactId);

                    EntityCollection resResult = _service.RetrieveMultiple(queryExpression);

                    if (resResult.Entities.Count > 0)
                    {
                        guestId = resResult.Entities[0].Id;
                        stayees.Id = guestId;
                        _service.Update(stayees);
                    }
                    else
                    {
                        guestId = _service.Create(stayees);
                    }
                }

                // store payment detials of guest in guest payment table
                CreatePaymentDetails(guestId);

                if (lstRoomCost.Count > 0)
                {
                    foreach (var item in lstRoomCost)
                    {
                        Entity roomDetails = new Entity("whb_roomstays");
                        if (reservationId != Guid.Empty)
                            roomDetails.Attributes["whb_reservation"] = new EntityReference("whb_reservation", reservationId);
                        if (guestId != Guid.Empty)
                            roomDetails.Attributes["whb_stay"] = new EntityReference("whb_stays", guestId);
                        if (contactId != Guid.Empty)
                            roomDetails.Attributes["whb_contact"] = new EntityReference("contact", contactId);
                        if (item.amount != "")
                            roomDetails.Attributes["whb_costpernight1"] = new Money(Convert.ToDecimal(item.amount));
                        Guid currencyId = GetCurrencyId(item.currencyType);
                        if (currencyId != Guid.Empty)
                        {
                            roomDetails.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", currencyId);
                        }
                        roomDetails.Attributes["whb_dateofstay"] = item.roomDate;
                        roomDetails.Attributes["whb_name"] = contactName;

                        QueryExpression queryExpression1 = new QueryExpression { EntityName = "whb_roomstays", ColumnSet = new ColumnSet(new string[] { "whb_name" }) };
                        queryExpression1.Criteria.AddCondition("whb_reservation", ConditionOperator.Equal, reservationId);
                        queryExpression1.Criteria.AddCondition("whb_contact", ConditionOperator.Equal, contactId);
                        queryExpression1.Criteria.AddCondition("whb_stay", ConditionOperator.Equal, guestId);
                        queryExpression1.Criteria.AddCondition("whb_dateofstay", ConditionOperator.Equal, item.roomDate);
                        EntityCollection resResult1 = _service.RetrieveMultiple(queryExpression1);

                        if (resResult1.Entities.Count > 0)
                        {
                            Guid stayId = resResult1.Entities[0].Id;
                            roomDetails.Id = stayId;
                            _service.Update(roomDetails);
                        }
                        else
                            _service.Create(roomDetails);
                    }
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }

        }

        // create payment card information
        public void CreatePaymentDetails(Guid guestId)
        {
            try
            {
                QueryExpression queryExpression = new QueryExpression { EntityName = "whb_guestpayments", ColumnSet = new ColumnSet(new string[] { "whb_name" }) };
                queryExpression.Criteria.AddCondition("whb_guestname", ConditionOperator.Equal, guestId);
                EntityCollection resResult = _service.RetrieveMultiple(queryExpression);

                if (resResult.Entities.Count > 0)
                {
                    foreach (Entity item in resResult.Entities)
                    {
                        _service.Delete("whb_guestpayments", item.Id);
                    }
                }
                foreach (ReservationPayments item in resPayments)
                {
                    Entity guestPayments = new Entity("whb_guestpayments");
                    guestPayments["whb_name"] = item.paymentType;
                    guestPayments["whb_cardtype"] = item.cardType;
                    guestPayments["whb_cardnumber"] = item.cardNumber;
                    guestPayments["whb_expirydate"] = item.expiryDate;
                    guestPayments["whb_paymentamount"] = item.paymentAmount;
                    if (item.paymentAmount != "")
                    {
                        guestPayments["whb_paymentamount"] = new Money(Convert.ToDecimal(item.paymentAmount));
                        if (item.currency != "")
                            guestPayments["transactioncurrencyid"] = new EntityReference("transactioncurrency", new Guid(item.currency));
                    }
                    else
                    {
                        guestPayments["whb_paymentamount"] = new Money(Convert.ToDecimal(0));
                        Guid currencyId = GetCurrencyId("GBP");
                        if (currencyId != Guid.Empty)
                            guestPayments["transactioncurrencyid"] = new EntityReference("transactioncurrency", currencyId);
                    }

                    guestPayments["whb_cardholdersname"] = item.cardHoldersName;
                    guestPayments["whb_guestname"] = new EntityReference("whb_stays", guestId);

                    _service.Create(guestPayments);
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }
        }

        // contact create
        public string CreateContactForStayer(string reservationNumber, string roomId)
        {
            try
            {
                string firstName = "";
                string lastName = "";
                string title = "";

                XmlDocument webResponse = GetReservationHisotryQueriyDetailsWithRoomId(reservationNumber, roomId);

                XmlNodeList booking = webResponse.GetElementsByTagName("Room");
                foreach (XmlNode BookingNode in booking)// Guest Details
                {
                    foreach (XmlNode BookingChildNode in BookingNode.ChildNodes)
                    {
                        if (BookingChildNode.Name == "guestName")
                        {
                            foreach (XmlNode guestNameChildNode in BookingChildNode.ChildNodes)
                            {
                                if (guestNameChildNode.Name == "title")
                                {
                                    title = guestNameChildNode.InnerText;
                                }
                                if (guestNameChildNode.Name == "firstName")
                                {
                                    firstName = guestNameChildNode.InnerText;
                                }
                                if (guestNameChildNode.Name == "lastName")
                                {
                                    lastName = guestNameChildNode.InnerText;
                                }
                            }
                        }
                    }
                }
                string createdContactId = "";
                if (firstName != "" && lastName != "")
                    createdContactId = CrateContactEntityWithOutGuestHistoryNumber(title, firstName, lastName, roomId);
                if (createdContactId != "")
                {
                    contactId = new Guid(createdContactId);
                    CreateGuestDetailsWithOutGuestHistoryNumber(webResponse);
                }
                return createdContactId;
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }
            return "";
        }

        // create contact in crm
        public string CrateContactEntityWithOutGuestHistoryNumber(string title, string firstname, string lastname, string roomId)
        {
            try
            {
                if (firstname != "" && lastname != "")
                    return "";

                Entity contact = new Entity("contact");
                int titleValue = ContactTitle(title);
                if (titleValue != 12)
                    contact.Attributes["whb_title1"] = new OptionSetValue(titleValue);
                contact.Attributes["whb_guesthistorynumber"] = guestHistoryNumberResult;
                contact.Attributes["firstname"] = firstname;
                contact.Attributes["lastname"] = lastname;
                contact.Attributes["whb_reservationnumber"] = reservationNumber;
                contact.Attributes["whb_roomid"] = roomId;

                contactName = firstname + " " + lastname;

                QueryExpression queryExpression = new QueryExpression { EntityName = "contact", ColumnSet = new ColumnSet(new string[] { "firstname" }) };
                queryExpression.Criteria.AddCondition("whb_reservationnumber", ConditionOperator.Equal, reservationNumber);
                queryExpression.Criteria.AddCondition("whb_roomid", ConditionOperator.Equal, roomId);
                if (firstname != "")
                    queryExpression.Criteria.AddCondition("firstname", ConditionOperator.Equal, firstname);
                EntityCollection resResult = _service.RetrieveMultiple(queryExpression);

                if (resResult.Entities.Count > 0)
                {
                    contactId = resResult.Entities[0].Id;
                    contact.Id = contactId;
                    _service.Update(contact);
                }
                else
                {
                    contactId = _service.Create(contact);

                    EntityReference associateEntityContact = new EntityReference("contact", contactId);
                    AssociateContactAndReservation(associateEntityContact, reservationId, _service);

                }
                return contactId.ToString();
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }

            return "";
        }

        // contact create
        public string CreateContact(string guestHistoryNumber)
        {
            try
            {
                string firstname = "";
                string lastname = "";
                string address1_line1 = "";
                string address1_line2 = "";
                string address1_line3 = "";
                string address1_country = "";
                string address1_postalcode = "";
                string mobilephone = "";
                string telephone1 = "";
                string emailaddress1 = "";

                string addressType = "";

                string parentcustomerid_account = "";// account id to pass

                string companyName = "";
                string companyCode = "";

                bool homeAddress = false;
                bool businessAddress = false;

                string postalCode1 = "";

                var mobile = "";
                var telephone = "";
                string title = "";

                XmlDocument webResponse = GetGuestHisotryQueriyDetails(guestHistoryNumber);

                XmlNodeList guestHistoryQueryResult = webResponse.GetElementsByTagName("guestDetails");
                foreach (XmlNode guestHistory in guestHistoryQueryResult)
                {
                    foreach (XmlNode guestHistoryChildNodes in guestHistory.ChildNodes)
                    {
                        if (guestHistoryChildNodes.Name == "title")
                            title = guestHistoryChildNodes.InnerText;
                        if (guestHistoryChildNodes.Name == "firstName")
                            firstname = guestHistoryChildNodes.InnerText;
                        if (guestHistoryChildNodes.Name == "lastName")
                            lastname = guestHistoryChildNodes.InnerText;
                        if (guestHistoryChildNodes.Name == "homeAddress")
                        {
                            foreach (XmlNode homeAddressNode in guestHistoryChildNodes.ChildNodes)
                            {
                                if (homeAddressNode.Name != "postCode")
                                    if (homeAddressNode.InnerText != "" && postalCode != "")
                                        if (homeAddressNode.InnerText.ToLower() == postalCode.ToLower())
                                            homeAddress = true;
                            }
                        }

                        if (guestHistoryChildNodes.Name == "businessAddress")
                        {
                            foreach (XmlNode homeAddressNode in guestHistoryChildNodes.ChildNodes)
                            {
                                if (homeAddressNode.Name == "postCode")
                                    if (homeAddressNode.InnerText != "" && postalCode != "")
                                        if (homeAddressNode.InnerText == postalCode)
                                            businessAddress = true;
                            }
                        }
                    }
                }

                if (homeAddress == false && businessAddress == false)
                    homeAddress = true;


                if (homeAddress == true)
                {
                    addressType = "1";
                    foreach (XmlNode guestHistory in guestHistoryQueryResult)
                    {
                        foreach (XmlNode guestHistoryChildNodes in guestHistory.ChildNodes)
                        {
                            if (guestHistoryChildNodes.Name == "homeAddress")
                            {
                                foreach (XmlNode businessAddressNode in guestHistoryChildNodes.ChildNodes)
                                {
                                    if (businessAddressNode.Name == "addressLine1")
                                        address1_line1 = businessAddressNode.InnerText;
                                    if (businessAddressNode.Name == "addressLine2")
                                        address1_line2 = businessAddressNode.InnerText;
                                    if (businessAddressNode.Name == "addressLine3")
                                        address1_line3 = businessAddressNode.InnerText;
                                    if (businessAddressNode.Name == "countryCode")
                                        address1_country = businessAddressNode.InnerText;
                                    if (businessAddressNode.Name == "postCode")
                                        address1_postalcode = businessAddressNode.InnerText;
                                    if (businessAddressNode.Name == "emailId")
                                        emailaddress1 = businessAddressNode.InnerText;

                                    if (businessAddressNode.Name == "telephoneNumbers")
                                    {
                                        foreach (XmlNode telephoneNumbers in businessAddressNode.ChildNodes)
                                        {
                                            foreach (XmlNode telephoneNode in telephoneNumbers.ChildNodes)
                                            {
                                                if (telephoneNode.Name == "telephoneNumber" && telephoneNumbers.FirstChild.InnerText == "MOBILE")
                                                    mobilephone = telephoneNode.InnerText;
                                            }

                                            foreach (XmlNode telephoneNode in telephoneNumbers.ChildNodes)
                                            {
                                                if (telephoneNode.Name == "telephoneNumber" && telephoneNumbers.FirstChild.InnerText == "TELEPHONE")
                                                    telephone1 = telephoneNode.InnerText;
                                            }
                                        }
                                    }

                                    if (businessAddressNode.Name == "companyName")
                                        companyName = businessAddressNode.InnerText;
                                    if (businessAddressNode.Name == "companyId")
                                        companyCode = businessAddressNode.InnerText;
                                }
                            }
                        }
                    }
                }

                else
                {
                    addressType = "2";
                    foreach (XmlNode guestHistory in guestHistoryQueryResult)
                    {
                        foreach (XmlNode guestHistoryChildNodes in guestHistory.ChildNodes)
                        {
                            if (guestHistoryChildNodes.Name == "businessAddress")
                            {
                                foreach (XmlNode businessAddressNode in guestHistoryChildNodes.ChildNodes)
                                {
                                    if (businessAddressNode.Name == "addressLine1")
                                        address1_line1 = businessAddressNode.InnerText;
                                    if (businessAddressNode.Name == "addressLine2")
                                        address1_line2 = businessAddressNode.InnerText;
                                    if (businessAddressNode.Name == "addressLine3")
                                        address1_line3 = businessAddressNode.InnerText;
                                    if (businessAddressNode.Name == "countryCode")
                                        address1_country = businessAddressNode.InnerText;
                                    if (businessAddressNode.Name == "postCode")
                                        address1_postalcode = businessAddressNode.InnerText;
                                    if (businessAddressNode.Name == "emailId")
                                        emailaddress1 = businessAddressNode.InnerText;

                                    if (businessAddressNode.Name == "telephoneNumbers")
                                    {
                                        foreach (XmlNode telephoneNumbers in businessAddressNode.ChildNodes)
                                        {
                                            foreach (XmlNode telephoneNode in telephoneNumbers.ChildNodes)
                                            {
                                                if (telephoneNode.Name == "telephoneNumber" && telephoneNumbers.FirstChild.InnerText == "MOBILE")
                                                    mobilephone = telephoneNode.InnerText;
                                            }

                                            foreach (XmlNode telephoneNode in telephoneNumbers.ChildNodes)
                                            {
                                                if (telephoneNode.Name == "telephoneNumber" && telephoneNumbers.FirstChild.InnerText == "TELEPHONE")
                                                    telephone1 = telephoneNode.InnerText;
                                            }
                                        }
                                    }

                                    if (businessAddressNode.Name == "companyName")
                                        companyName = businessAddressNode.InnerText;
                                    if (businessAddressNode.Name == "companyId")
                                        companyCode = businessAddressNode.InnerText;
                                }
                            }
                        }
                    }
                }

                // get feedback details
                XmlNodeList getFeedBack = webResponse.GetElementsByTagName("QueryGuestFeedback");
                foreach (XmlNode guestHistory in getFeedBack)
                {
                    bool reservationNumbserExistsInFeedBack = false;
                    foreach (XmlNode guestHistoryChildNodes in guestHistory.ChildNodes)
                    {
                        if (guestHistoryChildNodes.Name == "reservationNumber")
                            if (guestHistoryChildNodes.InnerText == reservatonNumberResult)
                                reservationNumbserExistsInFeedBack = true;
                    }

                    if (reservationNumbserExistsInFeedBack == true)
                    {
                        foreach (XmlNode guestHistoryChildNodes in guestHistory.ChildNodes)
                        {
                            if (guestHistoryChildNodes.Name == "refNumber")
                                GetFeedBackDetails(guestHistoryNumber, guestHistoryChildNodes.InnerText);
                        }
                    }
                }

                contactName = firstname + " " + lastname;
                // guestHistoryNumberResult = guestHistoryNumber;
                string createdContactId = CrateContactEntity(guestHistoryNumber, title, firstname, lastname, address1_line1, address1_line2, address1_line3, address1_country,
                    address1_postalcode, mobilephone, telephone1, emailaddress1, addressType, companyName, companyCode);

                return createdContactId;

            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }

            return "";

        }

        public int ContactTitle(string title)
        {


            if (title == "")
                return 12;

            if ("mr" == title.ToLower())
                return 0;
            else if ("mrs" == title.ToLower())
                return 1;
            else if ("ms" == title.ToLower())
                return 2;
            else if ("miss" == title.ToLower())
                return 3;
            else if ("master" == title.ToLower())
                return 4;
            else if ("dr" == title.ToLower())
                return 5;
            else if ("lord" == title.ToLower())
                return 6;
            else if ("lady" == title.ToLower())
                return 7;
            else if ("sir" == title.ToLower())
                return 8;
            else if ("col" == title.ToLower())
                return 9;
            else if ("prof" == title.ToLower())
                return 10;
            else if ("rev" == title.ToLower())
                return 11;
            else
                return 12;



        }

        // create contact in crm
        public string CrateContactEntity(string guestHistoryNumber, string title, string firstname, string lastname, string addressLine1, string addressLine2, string addressLine3, string countryCode,
            string postCode, string mobileNumber, string telephoneNumber, string emailAddress, string addressType, string companyName, string companyCode)
        {
            try
            {
                if (firstname == "" && lastname == "")
                    return "";

                Entity contact = new Entity("contact");
                int titleValue = ContactTitle(title);
                if (titleValue != 12)
                    contact.Attributes["whb_title1"] = new OptionSetValue(titleValue);
                contact.Attributes["whb_guesthistorynumber"] = guestHistoryNumber;
                if (firstname != "")
                    contact.Attributes["firstname"] = firstname;
                if (lastname != "")
                    contact.Attributes["lastname"] = lastname;
                if (addressLine1 != "")
                    contact.Attributes["address1_line1"] = addressLine1;
                if (addressLine2 != "")
                    contact.Attributes["address1_line2"] = addressLine2;
                contact.Attributes["address1_line3"] = addressLine3;
                contact.Attributes["address1_country"] = countryCode;
                if (postCode != "")
                    contact.Attributes["address1_postalcode"] = postCode;
                contact.Attributes["mobilephone"] = mobileNumber;
                contact.Attributes["telephone1"] = telephoneNumber;
                if (emailAddress != "")
                    contact.Attributes["emailaddress1"] = emailAddress;
                contact.Attributes["whb_addresstype"] = new OptionSetValue(Convert.ToInt32(addressType));
                //if (reservationId != Guid.Empty)
                //    contact.Attributes["whb_hotelreservation"] = new EntityReference("whb_reservation", reservationId);
                if (companyCode != "" && companyName != "")
                {
                    string companyId = CreateCompany(companyName, companyCode);
                    if (companyId != "")
                        contact.Attributes["parentcustomerid"] = new EntityReference("account", new Guid(companyId));
                }

                QueryExpression queryExpression = new QueryExpression { EntityName = "contact", ColumnSet = new ColumnSet(new string[] { "firstname" }) };
                queryExpression.Criteria.AddCondition("whb_guesthistorynumber", ConditionOperator.Equal, guestHistoryNumber);
                EntityCollection resResult = _service.RetrieveMultiple(queryExpression);

                if (resResult.Entities.Count > 0)
                {
                    contactId = resResult.Entities[0].Id;
                    contact.Id = contactId;
                    _service.Update(contact);
                }
                else
                {
                    contactId = _service.Create(contact);

                    EntityReference associateEntityContact = new EntityReference("contact", contactId);
                    if (reservationId != Guid.Empty)
                        AssociateContactAndReservation(associateEntityContact, reservationId, _service);

                }
                return contactId.ToString();
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }

            return "";

        }

        public void AssociateContactAndReservation(EntityReference contact, Guid reservationId, IOrganizationService service)
        {
            try
            {


                // Creating EntityReferenceCollection for the Contact
                EntityReferenceCollection relatedEntities = new EntityReferenceCollection();
                // Add the related entity contact
                relatedEntities.Add(contact);
                // Add the Account Contact relationship schema name
                Relationship relationship = new Relationship("whb_contact_whb_reservation");
                // Associate the contact record to Account
                service.Associate("whb_reservation", reservationId, relationship, relatedEntities);
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }
        }

        // update reservation 
        public void UpdateReservationWithBooker(string contactId)
        {
            try
            {
                Entity reservation = new Entity("whb_reservation");
                reservation.Id = reservationId;
                reservation.Attributes["whb_contact"] = new EntityReference("contact", new Guid(contactId));

                _service.Update(reservation);
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }

        }

        public string CreateCompany(string companyName, string companyCode)
        {
            try
            {
                QueryExpression queryExpression = new QueryExpression { EntityName = "account", ColumnSet = new ColumnSet(new string[] { "name" }) };
                queryExpression.Criteria.AddCondition("accountnumber", ConditionOperator.Equal, companyCode);
                EntityCollection accountCollection = _service.RetrieveMultiple(queryExpression);
                if (accountCollection.Entities.Count > 0)
                {
                    return accountCollection.Entities[0].Id.ToString();
                }

                Entity account = new Entity("account");
                account.Attributes["accountnumber"] = companyCode;
                account.Attributes["name"] = companyName;
                Guid accountId = _service.Create(account);
                return accountId.ToString();
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }
            return "";
        }

        public string GetBookerGuestHistoryNumber(XmlDocument webResponse)
        {
            string bookerGuestHistoryNumber = "";
            try
            {
                XmlNodeList booking = webResponse.GetElementsByTagName("booking");
                foreach (XmlNode BookingNode in booking)// Guest Details
                {
                    foreach (XmlNode BookingChildNode in BookingNode.ChildNodes)
                    {
                        if (BookingChildNode.Name == "booker")
                        {
                            foreach (XmlNode booker in BookingChildNode.ChildNodes)
                            {
                                if (booker.Name == "guestHistoryNumber")
                                    bookerGuestHistoryNumber = booker.InnerText;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }
            return bookerGuestHistoryNumber;
        }

        public void CreateReservation()
        {
            try
            {
                string reservation_whb_arrivaldate = "";
                string reservation_whb_departuredate = "";
                string reservation_whb_paymentdate = "";
                string reservation_whb_Hotelcode = ""; // reference number
                string reservation_whb_promotion = "";
                string reservation_whb_bookingmethods = "";
                string reservation_whb_cardholdername = "";
                string reservation_whb_creditcardnumber = "";
                string reservation_whb_expirydateoncard = "";
                string reservation_whb_totalinvoiceamount = "";
                string reservation_whb_numberofnights = "";
                int reservation_whb_numberofrooms = 0;
                Guid reservation_whb_trasactionCurrencyId = Guid.Empty;
                string promotionCode = "";
                string promotionDescription = "";
                string bookingMethodCode = "";
                string bookingMethodDescription = "";

                XmlDocument webResponseReservation = GetReservationHisotryQueriyDetails(reservatonNumberResult, "");

                XmlNodeList booking = webResponseReservation.GetElementsByTagName("booking");
                foreach (XmlNode BookingNode in booking)// Guest Details
                {
                    foreach (XmlNode BookingChildNode in BookingNode.ChildNodes)
                    {
                        if (BookingChildNode.Name == "arrivalDate")
                            reservation_whb_arrivaldate = BookingChildNode.InnerText;

                        if (BookingChildNode.Name == "departureDate")
                            reservation_whb_departuredate = BookingChildNode.InnerText;

                        // if (BookingChildNode.Name == "bookingDate")
                        //  reservation_whb_paymentdate = BookingChildNode.InnerText;
                        if (BookingChildNode.Name == "paymentDate")
                            reservation_whb_paymentdate = BookingChildNode.InnerText;

                        if (BookingChildNode.Name == "hotelCode")
                        {
                            reservation_whb_Hotelcode = GetPropertyId(BookingChildNode.InnerText);

                        }

                        if (BookingChildNode.Name == "bookingMethod")
                        {
                            foreach (XmlNode BookingTotal in BookingChildNode.ChildNodes)
                            {
                                if (BookingTotal.Name == "code")
                                    bookingMethodCode = BookingTotal.InnerText;

                                if (BookingTotal.Name == "description")
                                    bookingMethodDescription = BookingTotal.InnerText;
                            }
                        }

                        if (BookingChildNode.Name == "promotion")
                        {
                            foreach (XmlNode BookingTotal in BookingChildNode.ChildNodes)
                            {
                                if (BookingTotal.Name == "code")
                                    promotionCode = BookingTotal.InnerText;

                                if (BookingTotal.Name == "description")
                                    promotionDescription = BookingTotal.InnerText;
                            }
                        }


                        if (BookingChildNode.Name == "rooms")
                        {
                            reservation_whb_numberofrooms = BookingChildNode.ChildNodes.Count;
                        }
                    }
                }

                reservation_whb_bookingmethods = bookingMethodCode + " " + bookingMethodDescription;
                reservation_whb_promotion = promotionCode + " " + promotionDescription;

                int numberOfDays = NumberOfNights(Convert.ToDateTime(reservation_whb_departuredate), Convert.ToDateTime(reservation_whb_arrivaldate));
                reservation_whb_numberofnights = numberOfDays.ToString();

                CreateReservationEntity(reservation_whb_Hotelcode, reservation_whb_arrivaldate, reservation_whb_departuredate, thirdPartyReferenceNumber, reservation_whb_promotion, reservation_whb_cardholdername, reservation_whb_creditcardnumber, reservation_whb_expirydateoncard, reservation_whb_totalinvoiceamount, reservation_whb_numberofnights, reservation_whb_numberofrooms.ToString(), reservation_whb_bookingmethods, reservation_whb_trasactionCurrencyId, reservation_whb_paymentdate);

            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }
        }

        public void CreateReservationEntity(string whb_HotelName, string whb_arrivaldate, string whb_departuredate, string whb_thirdpartybookingref,
            string whb_promotion, string whb_cardholdername, string whb_creditcardnumber, string whb_expirydateoncard, string whb_totalinvoiceamount,
            string whb_numberofnights, string numberofrooms, string whb_bookingmethods, Guid transactionCurrencyId, string whb_paymentdate)
        {
            try
            {
                Entity reservationEntity = new Entity("whb_reservation");
                if (whb_HotelName != "")
                {
                    reservationEntity["whb_hotelname"] = new EntityReference("whb_property", new Guid(whb_HotelName));// pass property id
                    reservationPropertyId = new Guid(whb_HotelName);
                }
                if (whb_arrivaldate != "")
                    reservationEntity["whb_arrivaldate"] = Convert.ToDateTime(whb_arrivaldate);
                if (whb_departuredate != "")
                    reservationEntity["whb_departuredate"] = Convert.ToDateTime(whb_departuredate);
                if (!string.IsNullOrEmpty(whb_paymentdate))
                {
                    reservationEntity["whb_paymentdate"] = Convert.ToDateTime(whb_paymentdate);
                }
                //if (whb_paymentdate != "")
                // reservationEntity["whb_paymentdate"] = Convert.ToDateTime(whb_paymentdate);
                reservationEntity["whb_thirdpartybookingref"] = whb_thirdpartybookingref;
                reservationEntity["whb_promotion"] = whb_promotion;
                reservationEntity["whb_bookingmethods"] = whb_bookingmethods;
                reservationEntity["whb_cardholdername"] = whb_cardholdername;
                reservationEntity["whb_creditcardnumber"] = whb_creditcardnumber;
                reservationEntity["whb_expirydateoncard"] = whb_expirydateoncard;
                //reservationEntity["whb_totalinvoiceamount"] = new Money(Convert.ToDecimal(whb_totalinvoiceamount));
                reservationEntity["whb_numberofnights"] = Convert.ToInt32(whb_numberofnights);
                reservationEntity["whb_numberofrooms"] = Convert.ToInt32(numberofrooms);
                reservationEntity["whb_name"] = reservatonNumberResult.Trim();
                //if (transactionCurrencyId != Guid.Empty)
                //reservationEntity["transactioncurrencyid"] = new EntityReference("transactioncurrency", transactionCurrencyId);

                QueryExpression queryExpression = new QueryExpression { EntityName = "whb_reservation", ColumnSet = new ColumnSet(new string[] { "whb_name" }) };
                queryExpression.Criteria.AddCondition("whb_name", ConditionOperator.Equal, reservatonNumberResult.Trim());
                EntityCollection resResult = _service.RetrieveMultiple(queryExpression);

                if (resResult.Entities.Count > 0)
                {
                    reservationId = resResult.Entities[0].Id;
                    reservationEntity.Id = reservationId;
                    _service.Update(reservationEntity);
                }
                else
                    reservationId = _service.Create(reservationEntity);

            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }

        }

        public int GetPropertySiteNotification(Guid PropertyId)
        {
            try
            {
                QueryExpression queryExpression = new QueryExpression { EntityName = "whb_property", ColumnSet = new ColumnSet(new string[] { "whb_sitenotification" }) };
                queryExpression.Criteria.AddCondition("whb_propertyid", ConditionOperator.Equal, PropertyId);
                EntityCollection property = _service.RetrieveMultiple(queryExpression);

                foreach (Entity item in property.Entities)
                {
                    if (item.Attributes.Contains("whb_sitenotification"))
                        if ((bool)item.Attributes["whb_sitenotification"] == true)
                            return 1;
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }

            return 0;
        }


        public string GetPropertyId(string hotelCode)
        {
            try
            {
                QueryExpression queryExpression = new QueryExpression { EntityName = "whb_property", ColumnSet = new ColumnSet(new string[] { "whb_name" }) };
                queryExpression.Criteria.AddCondition("whb_propertycode", ConditionOperator.Equal, hotelCode);
                EntityCollection property = _service.RetrieveMultiple(queryExpression);

                foreach (Entity item in property.Entities)
                {
                    return item.Id.ToString();
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }

            return "";
        }

        public void ReadContactResponse(XmlDocument xmlResponse)
        {
            try
            {
                XmlNodeList guestHistorySearchResult = xmlResponse.GetElementsByTagName("guest");

                // If we get only one guest for the search, get the guest hisoty number
                // If we get more guests, stop processing next steps
                if (guestHistorySearchResult.Count == 1)
                {
                    foreach (XmlNode guestNodeList in guestHistorySearchResult)// Guest Details
                    {
                        // we can creat a guest here 
                        foreach (XmlNode guestNodeItems in guestNodeList.ChildNodes)// Guest Details
                        {
                            if (guestNodeItems.Name == "historyNumber")
                                guestHistoryNumberResult = guestNodeItems.InnerText;
                        }
                    }
                }

                if (guestHistoryNumberResult != "")
                {
                    XmlDocument webResponse = GetGuestHisotryQueriyDetails(guestHistoryNumberResult);
                    XmlNodeList stayInformation = webResponse.GetElementsByTagName("Stay");
                    // checkc only one reservation is present for this user
                    // If multiple is present, we are not consider any reservation , issue here is which reservation we will consider
                    if (stayInformation.Count == 1)
                    {
                        foreach (XmlNode stayNode in stayInformation)
                        {
                            foreach (XmlNode stayChildNdes in stayNode.ChildNodes)
                            {
                                if (stayChildNdes.Name == "reservationNumber")
                                {
                                    reservatonNumberResult = stayChildNdes.InnerText;
                                    ReservationDetails(reservatonNumberResult, "", "", "", "", "", "", "", "");
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }
        }

        public void ReadFeedBackData(XmlDocument webResponse)
        {

            try
            {

                XmlNodeList incidentLines = webResponse.GetElementsByTagName("incidentLines");
                foreach (XmlNode node in incidentLines) // for each <testcase> node
                {
                    foreach (XmlNode item in node.ChildNodes) // for each <testcase> node
                    {
                        if (item.Name == "incidentLinesItem")
                            feedBackData += item.InnerText + "\r\n";
                    }
                }

                XmlNodeList resolutionLines = webResponse.GetElementsByTagName("resolutionLines");
                foreach (XmlNode node in resolutionLines) // for each <testcase> node
                {
                    foreach (XmlNode item in node.ChildNodes) // for each <testcase> node
                    {
                        if (item.Name == "resolutionLinesItem")
                            feedBackData += item.InnerText + "\r\n";
                    }
                }

                XmlNodeList causeLines = webResponse.GetElementsByTagName("causeLines");
                foreach (XmlNode node in causeLines) // for each <testcase> node
                {
                    foreach (XmlNode item in node.ChildNodes) // for each <testcase> node
                    {
                        if (item.Name == "causeLinesItem")
                            feedBackData += item.InnerText + "\r\n";
                    }
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }

        }

        // read reservtion reservation
        public void ReadReservationResponse(XmlDocument xmlResponse)
        {
            try
            {

                XmlNodeList reservationResponse = xmlResponse.GetElementsByTagName("resSearchResults");

                foreach (XmlNode node in reservationResponse) // for each <testcase> node
                {
                    XmlNodeList ReservationSearchResult = node.ChildNodes;
                    foreach (XmlNode item in ReservationSearchResult)
                    {
                        string reservationNumberRes = "";
                        string thirdPartyReferenceRes = "";
                        foreach (XmlNode childNodeReservationSearchResult in item.ChildNodes) //ReservationSearchResult
                        {
                            if (childNodeReservationSearchResult.Name == "resNumber")
                                reservationNumberRes = childNodeReservationSearchResult.InnerText;
                            if (childNodeReservationSearchResult.Name == "thirdPartyReference")
                                thirdPartyReferenceRes = childNodeReservationSearchResult.InnerText;
                        }
                        reservatonNumberResult = reservationNumberRes;
                        thirdPartyReferenceNumber = thirdPartyReferenceRes;
                        foreach (XmlNode childNodeReservationSearchResult in item.ChildNodes) //ReservationSearchResult
                        {
                            if (reservationNumberRes == reservationNumber || thirdPartyReferenceRes == thirdPartyReference)
                            {
                                if (childNodeReservationSearchResult.Name == "roomsbooked")
                                {
                                    foreach (XmlNode roomsbooked in childNodeReservationSearchResult.ChildNodes)
                                    {
                                        var roomIdForStayer = "";
                                        foreach (XmlNode RoomDetailsNode in roomsbooked.ChildNodes)
                                        {

                                            if (RoomDetailsNode.Name == "roomId")
                                                roomIdForStayer = RoomDetailsNode.InnerText;

                                            if (RoomDetailsNode.Name == "stayer")
                                            {
                                                var stayerLastName = "";
                                                var stayerFirstName = "";
                                                foreach (XmlNode stayer in RoomDetailsNode.ChildNodes)
                                                {
                                                    if (stayer.Name == "lastName")
                                                        stayerLastName = stayer.InnerText;

                                                    if (stayer.Name == "firstName")
                                                        stayerFirstName = stayer.InnerText;
                                                }

                                                foreach (XmlNode stayer in RoomDetailsNode.ChildNodes)
                                                {
                                                    if (stayer.Name == "guestHistoryNumber")
                                                    {
                                                        if (stayerLastName.ToLower() == surname.ToLower() || stayerFirstName.ToLower() == firstName.ToLower())
                                                        {
                                                            guestHistoryNumberResult = stayer.InnerText; // getting particular guest history number 
                                                            RoomIdExists = roomIdForStayer;// get room id of the stayer
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }

        }
        // Request SOAP service
        public XmlDocument FormRequest(string SOAPRequest, string SOAPAction, string requestedData)
        {
            try
            {
                HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(SOAPRequest);
                webRequest.Headers.Add("SOAPAction", SOAPAction);
                webRequest.ContentType = "text/xml;charset=\"utf-8\"";
                webRequest.Accept = "text/xml";
                webRequest.Method = "POST";
                webRequest.Timeout = System.Threading.Timeout.Infinite;
                var bytes = System.Text.Encoding.ASCII.GetBytes(requestedData);
                webRequest.ContentLength = bytes.Length;
                Stream str = webRequest.GetRequestStream();
                StreamWriter strwriter = new StreamWriter(str, Encoding.ASCII);
                strwriter.Write(requestedData.ToString());
                strwriter.Close();

                HttpWebResponse res = (HttpWebResponse)webRequest.GetResponse();
                StreamReader rdr = new StreamReader(res.GetResponseStream());
                string result = rdr.ReadToEnd();

                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(result);

                return xmlDoc;
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }

            return null;
        }

        // Get reservation details
        public XmlDocument GetResearvationDetails(string surname, string reservationId, string bookingRef, string hotelname, string DOA)
        {
            try
            {
                string requestData = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:cas=\"http://caseman.oracle.com\"><soapenv:Header><Login><username>" + APIUserName + "</username><password>" + APIPassword + "</password></Login></soapenv:Header><soapenv:Body><cas:reservationSearch><cas:request>";
                if (reservationId != "")
                    requestData += "<cas:reservationNumber>" + reservationId.ToUpper() + "</cas:reservationNumber>";
                requestData += "<cas:guestLastName>" + surname + "</cas:guestLastName>";
                requestData += "<cas:hotelCode>" + hotelname + "</cas:hotelCode>";
                requestData += "<cas:arrivalDate>" + DOA + "</cas:arrivalDate>";
                requestData += "<cas:daysEitherSide></cas:daysEitherSide>";
                if (bookingRef != "")
                    requestData += "<cas:thirdPartyReference>" + bookingRef.ToUpper() + "</cas:thirdPartyReference>";
                requestData += "</cas:request></cas:reservationSearch></soapenv:Body></soapenv:Envelope>";

                XmlDocument webResponse = FormRequest(SOAPRequest, reservationSearch, requestData);
                return webResponse;

            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }

            return null;
        }

        // Get contact details
        public XmlDocument GetContactDetails(string surname, string emailAddress, string postalCode, string telephone, string FirstName)
        {
            try
            {
                var requestData = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:cas=\"http://caseman.oracle.com\"><soapenv:Header><Login><username>" + APIUserName + "</username><password>" + APIPassword + "</password></Login></soapenv:Header><soapenv:Body>";
                requestData += "<cas:guestHistorySearch><cas:request>";
                requestData += "<cas:surname>" + surname + "</cas:surname>";
                requestData += "<cas:firstName>" + FirstName + "</cas:firstName>";
                requestData += "<cas:postcode>" + postalCode + "</cas:postcode>";
                requestData += "<cas:addressLine1></cas:addressLine1>";
                requestData += "<cas:telephone>" + telephone + "</cas:telephone>";
                requestData += "<cas:companyName></cas:companyName>";
                requestData += "<cas:guestHistoryNumber></cas:guestHistoryNumber>";
                requestData += "<cas:email>" + emailAddress + "</cas:email>";
                requestData += "</cas:request></cas:guestHistorySearch>";
                requestData += "</soapenv:Body></soapenv:Envelope>";

                XmlDocument webResponse = FormRequest(SOAPRequest, guestHistorySearch, requestData);

                return webResponse;
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }

            return null;
        }



        // Reservation history query details
        public XmlDocument GetReservationHisotryQueriyDetails(string reservatinNumber, string guestHistoryNumber)
        {
            try
            {
                var requestData = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:cas=\"http://caseman.oracle.com\"><soapenv:Header><Login><username>" + APIUserName + "</username><password>" + APIPassword + "</password></Login></soapenv:Header><soapenv:Body>";
                requestData += "<cas:historyRecordDetailQuery><cas:request>";
                if (reservatinNumber != "")
                    requestData += "<cas:reservationNumber>" + reservatinNumber.ToUpper() + "</cas:reservationNumber>";
                if (guestHistoryNumber != "")
                    requestData += "<cas:historyRecord><cas:guestHistoryNumber>" + guestHistoryNumber.ToUpper() + "</cas:guestHistoryNumber></cas:historyRecord>";
                requestData += "</cas:request></cas:historyRecordDetailQuery>";
                requestData += "</soapenv:Body></soapenv:Envelope>";

                XmlDocument webResponse = FormRequest(SOAPRequest, historyRecordDetailQuery, requestData);
                return webResponse;

            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }

            return null;

        }

        // Reservation history query details
        public XmlDocument GetReservationHisotryQueriyDetailsWithRoomId(string reservatinNumber, string roomId)
        {
            try
            {
                var requestData = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:cas=\"http://caseman.oracle.com\"><soapenv:Header><Login><username>" + APIUserName + "</username><password>" + APIPassword + "</password></Login></soapenv:Header><soapenv:Body>";
                requestData += "<cas:historyRecordDetailQuery><cas:request>";
                requestData += "<cas:reservationNumber>" + reservatinNumber.ToUpper() + "</cas:reservationNumber>";
                requestData += "<cas:roomID>" + roomId + "</cas:roomID>";
                //requestData += "<cas:historyRecord><cas:guestHistoryNumber>" + guestHistoryNumber + "</cas:guestHistoryNumber></cas:historyRecord>";
                requestData += "</cas:request></cas:historyRecordDetailQuery>";
                requestData += "</soapenv:Body></soapenv:Envelope>";

                XmlDocument webResponse = FormRequest(SOAPRequest, historyRecordDetailQuery, requestData);
                return webResponse;

            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }

            return null;

        }

        // Get feedback details
        public void GetFeedBackDetails(string guestNumber, string HistoryNumber)
        {
            try
            {
                var requestData = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:cas=\"http://caseman.oracle.com\"><soapenv:Header><Login><username>" + APIUserName + "</username><password>" + APIPassword + "</password></Login></soapenv:Header><soapenv:Body>";
                requestData += "<cas:feedbackRecordQuery><cas:request>";
                requestData += "<cas:guestHistoryNumber>" + guestNumber + "</cas:guestHistoryNumber>";
                requestData += "<cas:feedbackNumber>" + HistoryNumber + "</cas:feedbackNumber>";
                requestData += "</cas:request></cas:feedbackRecordQuery>";
                requestData += "</soapenv:Body></soapenv:Envelope>";
                XmlDocument webResponse = FormRequest(SOAPRequest, feedBackfeedbackRecordQuery, requestData);
                ReadFeedBackData(webResponse);
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }
        }

        // Get History query details
        public XmlDocument GetGuestHisotryQueriyDetails(string guestHistoryNumber)
        {
            try
            {
                var requestData = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:cas=\"http://caseman.oracle.com\"><soapenv:Header><Login><username>" + APIUserName + "</username><password>" + APIPassword + "</password></Login></soapenv:Header><soapenv:Body>";
                requestData += "<cas:guestHistoryQuery><cas:request>";
                requestData += "<cas:guestHistoryNumber>" + guestHistoryNumber + "</cas:guestHistoryNumber>";
                requestData += "</cas:request></cas:guestHistoryQuery>";
                requestData += "</soapenv:Body></soapenv:Envelope>";

                XmlDocument webResponse = FormRequest(SOAPRequest, guestHistoryQuery, requestData);
                return webResponse;

            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }

            return null;
        }

        // calculate number of nights
        public int NumberOfNights(DateTime date1, DateTime date2)
        {
            //feel free to make here better
            var frm = date1 < date2 ? date1 : date2;
            var to = date1 < date2 ? date2 : date1;
            var totalDays = (int)(to - frm).TotalDays;
            return totalDays > 1 ? totalDays : 1;
        }

        // get curreny
        public Guid GetCurrencyId(string userdCurreny)
        {
            try
            {
                QueryExpression queryExpression = new QueryExpression { EntityName = "transactioncurrency", ColumnSet = new ColumnSet(new string[] { "transactioncurrencyid" }) };
                queryExpression.Criteria.AddCondition("isocurrencycode", ConditionOperator.Equal, userdCurreny);
                EntityCollection currencyId = _service.RetrieveMultiple(queryExpression);

                foreach (var item in currencyId.Entities)
                {
                    GlobalTrasactionCurrencyId = item.Id;
                    return item.Id;
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }


            return Guid.Empty;
        }
        // Get customization
        public void GetCustomizations()
        {
            try
            {
                QueryExpression queryExpression = new QueryExpression { EntityName = "whb_customizations", ColumnSet = new ColumnSet(new string[] { "whb_description", "whb_name" }) };

                object lstValues = new object[] { "APIPassword", "APIUserName", "GuestHistoryQuery", "GuestHistorySearch", "HistoryRecordDetailQuery", "ReservationSearch", "WSDLService", "FeedBackSearch" };
                queryExpression.Criteria.AddCondition("whb_name", ConditionOperator.In, new object[] { "APIPassword", "APIUserName", "GuestHistoryQuery", "GuestHistorySearch", "HistoryRecordDetailQuery", "ReservationSearch", "WSDLService", "FeedBackSearch" });
                EntityCollection customizations = _service.RetrieveMultiple(queryExpression);
                if (customizations.Entities.Count > 0)
                {
                    foreach (Entity item in customizations.Entities)
                    {
                        string configDescription = item.Attributes["whb_description"].ToString(); // results.value[i]["whb_description"];
                        string configName = item.Attributes["whb_name"].ToString(); ;// results.value[i]["whb_name"];

                        if (configName == "APIPassword")
                        {
                            APIPassword = configDescription;
                        }

                        if (configName == "APIUserName")
                        {
                            APIUserName = configDescription;
                        }

                        if (configName == "GuestHistoryQuery")
                        {
                            guestHistoryQuery = configDescription;
                        }

                        if (configName == "GuestHistorySearch")
                        {
                            guestHistorySearch = configDescription;
                        }

                        if (configName == "HistoryRecordDetailQuery")
                        {
                            historyRecordDetailQuery = configDescription;
                        }

                        if (configName == "ReservationSearch")
                        {
                            reservationSearch = configDescription;
                        }

                        if (configName == "WSDLService")
                        {
                            SOAPRequest = configDescription;
                        }

                        if (configName == "FeedBackSearch")
                        {
                            feedBackfeedbackRecordQuery = configDescription;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }
        }

        // Get Property codes
        public string GetPropertyCode(string hotelName)
        {
            try
            {
                QueryExpression queryExpression = new QueryExpression { EntityName = "whb_property", ColumnSet = new ColumnSet(new string[] { "whb_propertycode" }) };
                queryExpression.Criteria.AddCondition("whb_name", ConditionOperator.Equal, hotelName);
                EntityCollection property = _service.RetrieveMultiple(queryExpression);

                foreach (Entity item in property.Entities)
                {
                    if (item.Attributes.Contains("whb_propertycode"))
                        return item.Attributes["whb_propertycode"].ToString();
                }
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }

            return "";
        }

        //Creating contact for Restaurants
        public Guid createcontactres(string title, string firstname, string lastname, string addressLine1, string addressLine2, string addressLine3, string countryCode,
            string postCode, string mobileNumber, string telephoneNumber, string emailAddress, string town)
        {
            try
            {
                _tracer.Trace("new contact");
                Entity contact = new Entity("contact");
                int titleValue = ContactTitle(title);
                contact.Attributes["whb_title1"] = new OptionSetValue(titleValue);
                if (firstname != "")
                    contact.Attributes["firstname"] = firstname;
                if (lastname != "")
                    contact.Attributes["lastname"] = lastname;
                if (addressLine1 != "")
                    contact.Attributes["address1_line1"] = addressLine1;
                if (addressLine2 != "")
                    contact.Attributes["address1_line2"] = addressLine2;
                contact.Attributes["address1_line3"] = addressLine3;
                contact.Attributes["address1_country"] = countryCode;
                if (postCode != "")
                    contact.Attributes["address1_postalcode"] = postCode;
                contact.Attributes["mobilephone"] = mobileNumber;
                if (telephoneNumber != "")
                    contact.Attributes["telephone1"] = telephoneNumber;
                if (town != "")
                    contact.Attributes["address1_city"] = town;

                if (emailAddress != "")
                    contact.Attributes["emailaddress1"] = emailAddress;
                contactId = _service.Create(contact);
                return contactId;
            }
            catch (Exception ex)
            {
                _tracer.Trace("Exception in BART Workflow : " + MethodBase.GetCurrentMethod().Name + "-" + ex.Message);
                throw;
            }
            return Guid.Empty;
        }

    }

    class RoomDetails
    {
        public string amount { get; set; }
        public string currencyType { get; set; }

        public DateTime roomDate { get; set; }
    }

    class ReservationPayments
    {
        public string paymentType { get; set; }
        public string cardType { get; set; }
        public string cardNumber { get; set; }
        public string expiryDate { get; set; }
        public string paymentAmount { get; set; }
        public string cardHoldersName { get; set; }
        public string currency { get; set; }
    }
}

